"""
Dynamic Heuristic Analysis System for Anti-Ransomware
Monitors behavioral patterns during execution for ransomware detection
"""

import os
import sys
import json
import time
import threading
import logging
import subprocess
import psutil
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import queue
import tempfile
import shutil

class DynamicHeuristicAnalyzer:
    def __init__(self, base_dir=None):
        """Initialize the dynamic heuristic analyzer."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'dynamic_heuristic_{datetime.now().strftime("%Y%m%d")}.log', encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("DynamicHeuristicAnalyzer")
        
        # Analysis components
        self.behavior_monitor = BehaviorMonitor()
        self.api_monitor = APIMonitor()
        self.file_monitor = FileMonitor()
        self.network_monitor = NetworkMonitor()
        self.process_monitor = ProcessMonitor()
        
        # Analysis state
        self.active_analyses = {}
        self.analysis_queue = queue.Queue()
        self.results = {}
        
        # Heuristic rules
        self.behavioral_rules = self._load_behavioral_rules()
        
        # Statistics
        self.analysis_stats = {
            'files_analyzed': 0,
            'suspicious_behaviors': 0,
            'ransomware_detected': 0,
            'false_positives': 0
        }
    
    def _load_behavioral_rules(self) -> List[Dict]:
        """Load behavioral analysis rules."""
        return [
            {
                'name': 'mass_file_encryption',
                'weight': 0.9,
                'description': 'Process encrypts many files rapidly',
                'indicators': ['high_file_operations', 'crypto_apis', 'file_extension_changes']
            },
            {
                'name': 'ransom_note_creation',
                'weight': 0.8,
                'description': 'Process creates ransom note files',
                'indicators': ['text_file_creation', 'suspicious_strings', 'html_file_creation']
            },
            {
                'name': 'network_communication',
                'weight': 0.6,
                'description': 'Process communicates with external servers',
                'indicators': ['network_connections', 'dns_queries', 'http_requests']
            },
            {
                'name': 'process_manipulation',
                'weight': 0.7,
                'description': 'Process manipulates other processes',
                'indicators': ['process_creation', 'process_termination', 'process_injection']
            },
            {
                'name': 'registry_modification',
                'weight': 0.5,
                'description': 'Process modifies system registry',
                'indicators': ['registry_writes', 'registry_deletes', 'startup_entries']
            },
            {
                'name': 'anti_analysis',
                'weight': 0.8,
                'description': 'Process exhibits anti-analysis behavior',
                'indicators': ['debugger_detection', 'vm_detection', 'sandbox_evasion']
            },
            {
                'name': 'persistence_mechanism',
                'weight': 0.6,
                'description': 'Process establishes persistence',
                'indicators': ['startup_entries', 'service_creation', 'scheduled_tasks']
            }
        ]
    
    def analyze_file(self, filepath: str, timeout: int = 60) -> Dict[str, Any]:
        """Perform dynamic analysis on a file."""
        self.analysis_stats['files_analyzed'] += 1
        
        result = {
            'file': filepath,
            'timestamp': datetime.now().isoformat(),
            'analysis_type': 'dynamic_heuristic',
            'suspicious_score': 0.0,
            'risk_level': 'LOW',
            'behaviors_detected': [],
            'detailed_analysis': {},
            'recommendations': []
        }
        
        file_path = Path(filepath)
        if not file_path.exists():
            result['error'] = 'File not found'
            return result
        
        try:
            # Create sandbox environment
            sandbox_dir = self._create_sandbox()
            
            # Start monitoring
            monitoring_threads = self._start_monitoring(sandbox_dir)
            
            # Execute file in sandbox
            execution_result = self._execute_in_sandbox(file_path, sandbox_dir, timeout)
            
            # Stop monitoring
            self._stop_monitoring(monitoring_threads)
            
            # Analyze collected data
            behavioral_analysis = self._analyze_behavior(execution_result)
            result['detailed_analysis'] = behavioral_analysis
            
            # Calculate suspicious score
            result['suspicious_score'] = self._calculate_behavioral_score(behavioral_analysis)
            
            # Determine risk level
            result['risk_level'] = self._determine_risk_level(result['suspicious_score'])
            
            # Generate behaviors detected
            result['behaviors_detected'] = self._generate_behaviors_detected(behavioral_analysis)
            
            # Generate recommendations
            result['recommendations'] = self._generate_recommendations(result)
            
            # Cleanup sandbox
            self._cleanup_sandbox(sandbox_dir)
            
            # Update statistics
            if result['suspicious_score'] > 0.5:
                self.analysis_stats['suspicious_behaviors'] += 1
            
            if result['risk_level'] in ['CRITICAL', 'HIGH']:
                self.analysis_stats['ransomware_detected'] += 1
            
        except Exception as e:
            self.logger.error(f"Error in dynamic analysis: {e}")
            result['error'] = str(e)
        
        return result
    
    def _create_sandbox(self) -> Path:
        """Create a sandbox environment for safe execution."""
        sandbox_dir = Path(tempfile.mkdtemp(prefix="antiransomware_sandbox_"))
        
        # Create directory structure
        (sandbox_dir / "Documents").mkdir()
        (sandbox_dir / "Pictures").mkdir()
        (sandbox_dir / "Downloads").mkdir()
        (sandbox_dir / "Desktop").mkdir()
        
        # Create test files
        test_files = [
            "test_document.txt",
            "test_image.jpg",
            "test_spreadsheet.xlsx",
            "important_file.pdf"
        ]
        
        for test_file in test_files:
            (sandbox_dir / test_file).write_text(f"Test content for {test_file}")
        
        return sandbox_dir
    
    def _start_monitoring(self, sandbox_dir: Path) -> List[threading.Thread]:
        """Start monitoring threads."""
        threads = []
        
        # Start behavior monitoring
        behavior_thread = threading.Thread(
            target=self.behavior_monitor.start_monitoring,
            args=(sandbox_dir,)
        )
        behavior_thread.start()
        threads.append(behavior_thread)
        
        # Start API monitoring
        api_thread = threading.Thread(
            target=self.api_monitor.start_monitoring
        )
        api_thread.start()
        threads.append(api_thread)
        
        # Start file monitoring
        file_thread = threading.Thread(
            target=self.file_monitor.start_monitoring,
            args=(sandbox_dir,)
        )
        file_thread.start()
        threads.append(file_thread)
        
        # Start network monitoring
        network_thread = threading.Thread(
            target=self.network_monitor.start_monitoring
        )
        network_thread.start()
        threads.append(network_thread)
        
        # Start process monitoring
        process_thread = threading.Thread(
            target=self.process_monitor.start_monitoring
        )
        process_thread.start()
        threads.append(process_thread)
        
        return threads
    
    def _stop_monitoring(self, threads: List[threading.Thread]):
        """Stop monitoring threads."""
        # Signal all monitors to stop
        self.behavior_monitor.stop_monitoring()
        self.api_monitor.stop_monitoring()
        self.file_monitor.stop_monitoring()
        self.network_monitor.stop_monitoring()
        self.process_monitor.stop_monitoring()
        
        # Wait for threads to finish
        for thread in threads:
            thread.join(timeout=5)
    
    def _execute_in_sandbox(self, file_path: Path, sandbox_dir: Path, timeout: int) -> Dict[str, Any]:
        """Execute file in sandbox environment."""
        execution_result = {
            'execution_successful': False,
            'execution_time': 0,
            'exit_code': None,
            'error': None,
            'processes_created': [],
            'files_modified': [],
            'network_connections': [],
            'api_calls': []
        }
        
        try:
            start_time = time.time()
            
            # Change to sandbox directory
            original_cwd = os.getcwd()
            os.chdir(sandbox_dir)
            
            # Execute the file
            if file_path.suffix.lower() in ['.exe', '.bat', '.cmd']:
                # Execute directly
                process = subprocess.Popen(
                    [str(file_path)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=str(sandbox_dir)
                )
            else:
                # Try to execute with appropriate program
                if file_path.suffix.lower() == '.py':
                    process = subprocess.Popen(
                        [sys.executable, str(file_path)],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        cwd=str(sandbox_dir)
                    )
                else:
                    # Try to open with default program
                    process = subprocess.Popen(
                        ['start', str(file_path)],
                        shell=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        cwd=str(sandbox_dir)
                    )
            
            # Wait for execution with timeout
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                execution_result['execution_successful'] = True
                execution_result['exit_code'] = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                execution_result['error'] = 'Execution timeout'
            
            execution_result['execution_time'] = time.time() - start_time
            
            # Restore original directory
            os.chdir(original_cwd)
            
        except Exception as e:
            execution_result['error'] = str(e)
            self.logger.error(f"Execution error: {e}")
        
        return execution_result
    
    def _analyze_behavior(self, execution_result: Dict) -> Dict[str, Any]:
        """Analyze collected behavioral data."""
        analysis = {
            'file_operations': self.file_monitor.get_analysis(),
            'api_calls': self.api_monitor.get_analysis(),
            'network_activity': self.network_monitor.get_analysis(),
            'process_activity': self.process_monitor.get_analysis(),
            'behavioral_patterns': self.behavior_monitor.get_analysis()
        }
        
        return analysis
    
    def _calculate_behavioral_score(self, analysis: Dict) -> float:
        """Calculate behavioral suspicious score."""
        score = 0.0
        total_weight = 0.0
        
        for rule in self.behavioral_rules:
            rule_name = rule['name']
            weight = rule['weight']
            
            # Check if rule indicators are present
            indicators_present = 0
            total_indicators = len(rule['indicators'])
            
            for indicator in rule['indicators']:
                if self._check_indicator_present(analysis, indicator):
                    indicators_present += 1
            
            # Calculate rule score
            if indicators_present > 0:
                rule_score = indicators_present / total_indicators
                score += weight * rule_score
                total_weight += weight
        
        if total_weight > 0:
            return min(score / total_weight, 1.0)
        return 0.0
    
    def _check_indicator_present(self, analysis: Dict, indicator: str) -> bool:
        """Check if a specific indicator is present in analysis."""
        # This is a simplified check - in reality, you'd have more sophisticated logic
        if indicator == 'high_file_operations':
            file_ops = analysis.get('file_operations', {})
            return file_ops.get('files_modified', 0) > 10
        
        elif indicator == 'crypto_apis':
            api_calls = analysis.get('api_calls', {})
            return len(api_calls.get('crypto_functions', [])) > 0
        
        elif indicator == 'file_extension_changes':
            file_ops = analysis.get('file_operations', {})
            return file_ops.get('extension_changes', 0) > 0
        
        elif indicator == 'text_file_creation':
            file_ops = analysis.get('file_operations', {})
            return file_ops.get('text_files_created', 0) > 0
        
        elif indicator == 'suspicious_strings':
            behavior = analysis.get('behavioral_patterns', {})
            return len(behavior.get('suspicious_strings', [])) > 0
        
        elif indicator == 'html_file_creation':
            file_ops = analysis.get('file_operations', {})
            return file_ops.get('html_files_created', 0) > 0
        
        elif indicator == 'network_connections':
            network = analysis.get('network_activity', {})
            return len(network.get('connections', [])) > 0
        
        elif indicator == 'dns_queries':
            network = analysis.get('network_activity', {})
            return len(network.get('dns_queries', [])) > 0
        
        elif indicator == 'http_requests':
            network = analysis.get('network_activity', {})
            return len(network.get('http_requests', [])) > 0
        
        elif indicator == 'process_creation':
            process = analysis.get('process_activity', {})
            return process.get('processes_created', 0) > 0
        
        elif indicator == 'process_termination':
            process = analysis.get('process_activity', {})
            return process.get('processes_terminated', 0) > 0
        
        elif indicator == 'process_injection':
            process = analysis.get('process_activity', {})
            return process.get('process_injections', 0) > 0
        
        elif indicator == 'registry_writes':
            api_calls = analysis.get('api_calls', {})
            return api_calls.get('registry_writes', 0) > 0
        
        elif indicator == 'registry_deletes':
            api_calls = analysis.get('api_calls', {})
            return api_calls.get('registry_deletes', 0) > 0
        
        elif indicator == 'startup_entries':
            api_calls = analysis.get('api_calls', {})
            return api_calls.get('startup_entries_created', 0) > 0
        
        elif indicator == 'debugger_detection':
            behavior = analysis.get('behavioral_patterns', {})
            return behavior.get('debugger_detection', False)
        
        elif indicator == 'vm_detection':
            behavior = analysis.get('behavioral_patterns', {})
            return behavior.get('vm_detection', False)
        
        elif indicator == 'sandbox_evasion':
            behavior = analysis.get('behavioral_patterns', {})
            return behavior.get('sandbox_evasion', False)
        
        elif indicator == 'service_creation':
            api_calls = analysis.get('api_calls', {})
            return api_calls.get('services_created', 0) > 0
        
        elif indicator == 'scheduled_tasks':
            api_calls = analysis.get('api_calls', {})
            return api_calls.get('scheduled_tasks_created', 0) > 0
        
        return False
    
    def _determine_risk_level(self, score: float) -> str:
        """Determine risk level based on behavioral score."""
        if score >= 0.8:
            return 'CRITICAL'
        elif score >= 0.6:
            return 'HIGH'
        elif score >= 0.4:
            return 'MEDIUM'
        elif score >= 0.2:
            return 'LOW'
        else:
            return 'MINIMAL'
    
    def _generate_behaviors_detected(self, analysis: Dict) -> List[Dict]:
        """Generate list of detected behaviors."""
        behaviors = []
        
        # Check for mass file encryption
        file_ops = analysis.get('file_operations', {})
        if file_ops.get('files_modified', 0) > 10:
            behaviors.append({
                'type': 'mass_file_encryption',
                'severity': 'HIGH',
                'description': f'Modified {file_ops["files_modified"]} files rapidly'
            })
        
        # Check for ransom note creation
        if file_ops.get('text_files_created', 0) > 0:
            behaviors.append({
                'type': 'ransom_note_creation',
                'severity': 'HIGH',
                'description': f'Created {file_ops["text_files_created"]} text files'
            })
        
        # Check for network communication
        network = analysis.get('network_activity', {})
        if network.get('connections', []):
            behaviors.append({
                'type': 'network_communication',
                'severity': 'MEDIUM',
                'description': f'Established {len(network["connections"])} network connections'
            })
        
        # Check for process manipulation
        process = analysis.get('process_activity', {})
        if process.get('processes_created', 0) > 0:
            behaviors.append({
                'type': 'process_manipulation',
                'severity': 'MEDIUM',
                'description': f'Created {process["processes_created"]} new processes'
            })
        
        # Check for anti-analysis behavior
        behavior = analysis.get('behavioral_patterns', {})
        if behavior.get('debugger_detection', False):
            behaviors.append({
                'type': 'anti_analysis',
                'severity': 'HIGH',
                'description': 'Detected debugger detection behavior'
            })
        
        return behaviors
    
    def _generate_recommendations(self, result: Dict) -> List[str]:
        """Generate recommendations based on analysis results."""
        recommendations = []
        
        score = result['suspicious_score']
        risk_level = result['risk_level']
        
        if risk_level in ['CRITICAL', 'HIGH']:
            recommendations.append('IMMEDIATE_QUARANTINE: File exhibits high-risk behavior')
            recommendations.append('DEEP_ANALYSIS: Perform additional static analysis')
        
        if score > 0.6:
            recommendations.append('MONITOR_CLOSELY: Monitor system for additional activity')
        
        behaviors = result.get('behaviors_detected', [])
        for behavior in behaviors:
            if behavior['type'] == 'mass_file_encryption':
                recommendations.append('FILE_RECOVERY: Check for file encryption and attempt recovery')
            elif behavior['type'] == 'ransom_note_creation':
                recommendations.append('RANSOM_NOTE_ANALYSIS: Analyze ransom note for payment details')
            elif behavior['type'] == 'network_communication':
                recommendations.append('NETWORK_ANALYSIS: Analyze network traffic for C&C communication')
        
        return recommendations
    
    def _cleanup_sandbox(self, sandbox_dir: Path):
        """Clean up sandbox environment."""
        try:
            shutil.rmtree(sandbox_dir)
        except Exception as e:
            self.logger.error(f"Failed to cleanup sandbox: {e}")
    
    def get_analysis_stats(self) -> Dict[str, Any]:
        """Get analysis statistics."""
        return {
            'statistics': self.analysis_stats,
            'behavioral_rules': len(self.behavioral_rules),
            'monitoring_components': [
                'behavior_monitor', 'api_monitor', 'file_monitor',
                'network_monitor', 'process_monitor'
            ]
        }


class BehaviorMonitor:
    """Monitor general behavioral patterns."""
    
    def __init__(self):
        self.monitoring = False
        self.behaviors = []
        self.suspicious_strings = []
        self.debugger_detection = False
        self.vm_detection = False
        self.sandbox_evasion = False
    
    def start_monitoring(self, sandbox_dir: Path):
        """Start behavior monitoring."""
        self.monitoring = True
        self.behaviors = []
        self.suspicious_strings = []
        self.debugger_detection = False
        self.vm_detection = False
        self.sandbox_evasion = False
        
        # Monitor for suspicious patterns
        while self.monitoring:
            time.sleep(1)
            # In a real implementation, this would monitor system events
            # For now, we'll simulate some detection logic
    
    def stop_monitoring(self):
        """Stop behavior monitoring."""
        self.monitoring = False
    
    def get_analysis(self) -> Dict[str, Any]:
        """Get behavior analysis results."""
        return {
            'behaviors': self.behaviors,
            'suspicious_strings': self.suspicious_strings,
            'debugger_detection': self.debugger_detection,
            'vm_detection': self.vm_detection,
            'sandbox_evasion': self.sandbox_evasion
        }


class APIMonitor:
    """Monitor API calls for suspicious behavior."""
    
    def __init__(self):
        self.monitoring = False
        self.api_calls = []
        self.crypto_functions = []
        self.registry_writes = 0
        self.registry_deletes = 0
        self.startup_entries_created = 0
        self.services_created = 0
        self.scheduled_tasks_created = 0
    
    def start_monitoring(self):
        """Start API monitoring."""
        self.monitoring = True
        self.api_calls = []
        self.crypto_functions = []
        self.registry_writes = 0
        self.registry_deletes = 0
        self.startup_entries_created = 0
        self.services_created = 0
        self.scheduled_tasks_created = 0
        
        # In a real implementation, this would hook into API calls
        while self.monitoring:
            time.sleep(1)
    
    def stop_monitoring(self):
        """Stop API monitoring."""
        self.monitoring = False
    
    def get_analysis(self) -> Dict[str, Any]:
        """Get API analysis results."""
        return {
            'api_calls': self.api_calls,
            'crypto_functions': self.crypto_functions,
            'registry_writes': self.registry_writes,
            'registry_deletes': self.registry_deletes,
            'startup_entries_created': self.startup_entries_created,
            'services_created': self.services_created,
            'scheduled_tasks_created': self.scheduled_tasks_created
        }


class FileMonitor:
    """Monitor file operations for suspicious behavior."""
    
    def __init__(self):
        self.monitoring = False
        self.files_modified = 0
        self.files_created = 0
        self.files_deleted = 0
        self.extension_changes = 0
        self.text_files_created = 0
        self.html_files_created = 0
        self.encrypted_files = 0
    
    def start_monitoring(self, sandbox_dir: Path):
        """Start file monitoring."""
        self.monitoring = True
        self.files_modified = 0
        self.files_created = 0
        self.files_deleted = 0
        self.extension_changes = 0
        self.text_files_created = 0
        self.html_files_created = 0
        self.encrypted_files = 0
        
        # Monitor file system changes
        while self.monitoring:
            time.sleep(1)
            # In a real implementation, this would use file system watchers
    
    def stop_monitoring(self):
        """Stop file monitoring."""
        self.monitoring = False
    
    def get_analysis(self) -> Dict[str, Any]:
        """Get file analysis results."""
        return {
            'files_modified': self.files_modified,
            'files_created': self.files_created,
            'files_deleted': self.files_deleted,
            'extension_changes': self.extension_changes,
            'text_files_created': self.text_files_created,
            'html_files_created': self.html_files_created,
            'encrypted_files': self.encrypted_files
        }


class NetworkMonitor:
    """Monitor network activity for suspicious behavior."""
    
    def __init__(self):
        self.monitoring = False
        self.connections = []
        self.dns_queries = []
        self.http_requests = []
        self.suspicious_ips = []
    
    def start_monitoring(self):
        """Start network monitoring."""
        self.monitoring = True
        self.connections = []
        self.dns_queries = []
        self.http_requests = []
        self.suspicious_ips = []
        
        # Monitor network activity
        while self.monitoring:
            time.sleep(1)
            # In a real implementation, this would monitor network traffic
    
    def stop_monitoring(self):
        """Stop network monitoring."""
        self.monitoring = False
    
    def get_analysis(self) -> Dict[str, Any]:
        """Get network analysis results."""
        return {
            'connections': self.connections,
            'dns_queries': self.dns_queries,
            'http_requests': self.http_requests,
            'suspicious_ips': self.suspicious_ips
        }


class ProcessMonitor:
    """Monitor process activity for suspicious behavior."""
    
    def __init__(self):
        self.monitoring = False
        self.processes_created = 0
        self.processes_terminated = 0
        self.process_injections = 0
        self.suspicious_processes = []
    
    def start_monitoring(self):
        """Start process monitoring."""
        self.monitoring = True
        self.processes_created = 0
        self.processes_terminated = 0
        self.process_injections = 0
        self.suspicious_processes = []
        
        # Monitor process activity
        while self.monitoring:
            time.sleep(1)
            # In a real implementation, this would monitor process events
    
    def stop_monitoring(self):
        """Stop process monitoring."""
        self.monitoring = False
    
    def get_analysis(self) -> Dict[str, Any]:
        """Get process analysis results."""
        return {
            'processes_created': self.processes_created,
            'processes_terminated': self.processes_terminated,
            'process_injections': self.process_injections,
            'suspicious_processes': self.suspicious_processes
        }


def main():
    """Test the dynamic heuristic analyzer."""
    print("=== Dynamic Heuristic Analysis System ===\n")
    
    analyzer = DynamicHeuristicAnalyzer()
    
    while True:
        print("\n1. Analyze File")
        print("2. Show Analysis Stats")
        print("3. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            filepath = input("Enter file path: ")
            timeout = input("Enter timeout in seconds (default 60): ")
            timeout = int(timeout) if timeout else 60
            
            result = analyzer.analyze_file(filepath, timeout)
            
            print(f"\n=== Analysis Results ===")
            print(f"File: {result['file']}")
            print(f"Suspicious Score: {result['suspicious_score']:.2f}")
            print(f"Risk Level: {result['risk_level']}")
            
            if result['behaviors_detected']:
                print(f"\nBehaviors Detected ({len(result['behaviors_detected'])}):")
                for behavior in result['behaviors_detected']:
                    print(f"  - {behavior['description']} [{behavior['severity']}]")
            
            if result['recommendations']:
                print(f"\nRecommendations:")
                for rec in result['recommendations']:
                    print(f"  - {rec}")
        
        elif choice == "2":
            stats = analyzer.get_analysis_stats()
            print(f"\n=== Analysis Statistics ===")
            for key, value in stats['statistics'].items():
                print(f"{key}: {value}")
        
        elif choice == "3":
            break


if __name__ == "__main__":
    main()
