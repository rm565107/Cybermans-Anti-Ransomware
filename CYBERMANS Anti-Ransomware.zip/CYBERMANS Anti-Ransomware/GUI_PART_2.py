import threading
import queue
import os
import sys
import time
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

import tkinter as tk
from tkinter import filedialog, messagebox

try:
	import ttkbootstrap as tb
	from ttkbootstrap.constants import PRIMARY, SUCCESS, DANGER, INFO, WARNING
except Exception:  # Fallback to ttk if ttkbootstrap missing
	import tkinter.ttk as tb  # type: ignore
	PRIMARY = SUCCESS = DANGER = INFO = WARNING = None  # placeholders

# Ensure local imports work when run directly
CURRENT_DIR = Path(__file__).parent
if str(CURRENT_DIR) not in sys.path:
	sys.path.insert(0, str(CURRENT_DIR))

from antiransomware import AntiRansomwareCore  # noqa: E402


class QueueLogHandler(logging.Handler):
	"""Manipulador de log que encaminha registros de log para uma fila para a GUI."""
	def __init__(self, log_queue: "queue.Queue[str]"):
		super().__init__()
		self.log_queue = log_queue

	def emit(self, record: logging.LogRecord) -> None:
		try:
			msg = self.format(record)
			self.log_queue.put_nowait(msg)
		except Exception:
			pass


class AntiRansomwareService:
	"""Fachada thread-safe em torno do AntiRansomwareCore para uso na GUI."""
	def __init__(self, log_queue: "queue.Queue[str]"):
		self.core = AntiRansomwareCore()
		self.lock = threading.RLock()
		self.log_queue = log_queue
		self._attach_logger()

	def _attach_logger(self) -> None:
		# Anexar um manipulador de fila ao logger principal para exibir logs na GUI
		handler = QueueLogHandler(self.log_queue)
		formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
		handler.setFormatter(formatter)
		self.core.logger.addHandler(handler)
		# Reduzir ruído duplicado do console na GUI diminuindo o nível do manipulador de stream
		for h in list(self.core.logger.handlers):
			if isinstance(h, logging.StreamHandler) and not isinstance(h, QueueLogHandler):
				try:
					h.setLevel(logging.WARNING)
				except Exception:
					pass

	def start(self) -> bool:
		with self.lock:
			return self.core.start_protection()

	def stop(self) -> bool:
		with self.lock:
			return self.core.stop_protection()

	def get_status(self) -> Dict[str, Any]:
		with self.lock:
			return self.core.get_status()

	def manual_scan(self, path: str, analysis_types: List[str] = None) -> Dict[str, Any]:
		with self.lock:
			return self.core.perform_manual_scan(path, analysis_types)

	def regenerate_honeypots(self) -> int:
		with self.lock:
			return self.core.regenerate_honeypots()

	def create_backup(self) -> Optional[str]:
		with self.lock:
			try:
				return self.core.vss_manager.create_shadow_copy_powershell()
			except Exception as e:
				self.logger.error(f"Backup creation failed: {e}")
				return None

	def emergency_kill(self) -> Dict[str, Any]:
		with self.lock:
			return self.core.ransomware_killer.emergency_kill_all_suspects()
	
	def configure_automatic_response(self, config: Dict[str, Any]) -> bool:
		with self.lock:
			return self.core.configure_automatic_response(config)
	
	def get_automatic_response_stats(self) -> Dict[str, Any]:
		with self.lock:
			return self.core.get_automatic_response_stats()
	
	def get_windows_compatibility_info(self) -> Dict[str, Any]:
		with self.lock:
			return self.core.compatibility_manager.get_compatibility_report()


class AntiRansomwareGUI:
	REFRESH_MS = 1000

	def __init__(self, root: tk.Tk):
		self.root = root
		self.root.title("CYBERMANS Anti-Ransomware")
		self.root.protocol("WM_DELETE_WINDOW", self.on_close)

		self.log_queue: "queue.Queue[str]" = queue.Queue()
		self.service = AntiRansomwareService(self.log_queue)

		self._build_ui()
		self._start_pollers()

	def _build_ui(self) -> None:
		style_kwargs = {}
		if hasattr(tb, 'Window'):
			# If using ttkbootstrap, the passed root is already a themed window
			pass

		main = tb.Frame(self.root)
		main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

		# Top controls
		controls = tb.Frame(main)
		controls.pack(fill=tk.X, pady=(0, 10))

		self.start_btn = tb.Button(controls, text="Iniciar Proteção", command=self.on_start, bootstyle=SUCCESS or None)
		self.start_btn.pack(side=tk.LEFT)

		self.stop_btn = tb.Button(controls, text="Parar", command=self.on_stop, bootstyle=DANGER or None)
		self.stop_btn.pack(side=tk.LEFT, padx=(8, 0))

		self.backup_btn = tb.Button(controls, text="Criar Backup", command=self.on_backup, bootstyle=INFO or None)
		self.backup_btn.pack(side=tk.LEFT, padx=(8, 0))

		self.kill_btn = tb.Button(controls, text="Eliminação de Emergência", command=self.on_emergency_kill, bootstyle=WARNING or None)
		self.kill_btn.pack(side=tk.LEFT, padx=(8, 0))

		self.regen_btn = tb.Button(controls, text="🔄 Regenerar Honeypots", command=self.on_regenerate, bootstyle=WARNING or None)
		self.regen_btn.pack(side=tk.LEFT, padx=(8, 0))
		
		# Lethal Response Button
		self.lethal_btn = tb.Button(controls, text="💀 MODO LETAL", command=self.on_lethal_mode, bootstyle=DANGER or None)
		self.lethal_btn.pack(side=tk.LEFT, padx=(8, 0))

		# Automatic Response Configuration
		auto_response = tb.LabelFrame(main, text="Configurações de Resposta Automática")
		auto_response.pack(fill=tk.X, pady=(8, 0))
		
		# Auto-response checkboxes
		response_frame = tb.Frame(auto_response)
		response_frame.pack(fill=tk.X, padx=8, pady=6)
		
		self.auto_kill_var = tk.BooleanVar(value=True)
		self.auto_delete_var = tk.BooleanVar(value=True)
		self.auto_quarantine_var = tk.BooleanVar(value=True)
		
		tb.Checkbutton(response_frame, text="Auto-Eliminar Processos", variable=self.auto_kill_var, 
		              command=self._update_auto_response_config).pack(side=tk.LEFT, padx=(0, 8))
		tb.Checkbutton(response_frame, text="Auto-Excluir Arquivos", variable=self.auto_delete_var,
		              command=self._update_auto_response_config).pack(side=tk.LEFT, padx=(0, 8))
		tb.Checkbutton(response_frame, text="Auto-Quarentena", variable=self.auto_quarantine_var,
		              command=self._update_auto_response_config).pack(side=tk.LEFT, padx=(0, 8))

		# Windows Compatibility Panel
		compatibility = tb.LabelFrame(main, text="Status de Compatibilidade Windows")
		compatibility.pack(fill=tk.X, pady=(8, 0))
		
		# Compatibility info display
		compat_frame = tb.Frame(compatibility)
		compat_frame.pack(fill=tk.X, padx=8, pady=6)
		
		self.compat_status_var = tk.StringVar(value="Verificando...")
		self.compat_score_var = tk.StringVar(value="0%")
		self.compat_admin_var = tk.StringVar(value="Desconhecido")
		
		# Status labels
		status_row = tb.Frame(compat_frame)
		status_row.pack(fill=tk.X)
		
		tb.Label(status_row, text="Status:").pack(side=tk.LEFT)
		tb.Label(status_row, textvariable=self.compat_status_var, bootstyle=INFO or None).pack(side=tk.LEFT, padx=(8, 0))
		
		score_row = tb.Frame(compat_frame)
		score_row.pack(fill=tk.X)
		
		tb.Label(score_row, text="Compatibilidade:").pack(side=tk.LEFT)
		tb.Label(score_row, textvariable=self.compat_score_var, bootstyle=SUCCESS or None).pack(side=tk.LEFT, padx=(8, 0))
		
		admin_row = tb.Frame(compat_frame)
		admin_row.pack(fill=tk.X)
		
		tb.Label(admin_row, text="Admin:").pack(side=tk.LEFT)
		tb.Label(admin_row, textvariable=self.compat_admin_var, bootstyle=WARNING or None).pack(side=tk.LEFT, padx=(8, 0))
		
		# Compatibility button
		tb.Button(compat_frame, text="🔍 Verificar Compatibilidade", command=self.on_check_compatibility, bootstyle=INFO or None).pack(pady=(4, 0))

		# Status panel
		status_frame = tb.LabelFrame(main, text="Status")
		status_frame.pack(fill=tk.X)

		self.status_var = tk.StringVar(value="Parado")
		self.level_var = tk.StringVar(value="NORMAL")
		self.uptime_var = tk.StringVar(value="-")

		row = tb.Frame(status_frame)
		row.pack(fill=tk.X, padx=8, pady=4)
		tb.Label(row, text="Proteção:", width=16, anchor=tk.W).pack(side=tk.LEFT)
		tb.Label(row, textvariable=self.status_var, anchor=tk.W).pack(side=tk.LEFT)

		row2 = tb.Frame(status_frame)
		row2.pack(fill=tk.X, padx=8, pady=4)
		tb.Label(row2, text="Nível:", width=16, anchor=tk.W).pack(side=tk.LEFT)
		tb.Label(row2, textvariable=self.level_var, anchor=tk.W).pack(side=tk.LEFT)

		row3 = tb.Frame(status_frame)
		row3.pack(fill=tk.X, padx=8, pady=4)
		tb.Label(row3, text="Tempo Ativo:", width=16, anchor=tk.W).pack(side=tk.LEFT)
		tb.Label(row3, textvariable=self.uptime_var, anchor=tk.W).pack(side=tk.LEFT)

		# Stats
		stats_frame = tb.LabelFrame(main, text="Estatísticas")
		stats_frame.pack(fill=tk.X, pady=(8, 0))
		self.threats_var = tk.StringVar(value="0")
		self.killed_var = tk.StringVar(value="0")
		self.restored_var = tk.StringVar(value="0")
		self.honeypot_events_var = tk.StringVar(value="0")
		self.backups_var = tk.StringVar(value="0")

		def stat_row(parent, name, var):
			row = tb.Frame(parent)
			row.pack(fill=tk.X, padx=8, pady=2)
			tb.Label(row, text=name + ":", width=24, anchor=tk.W).pack(side=tk.LEFT)
			tb.Label(row, textvariable=var, anchor=tk.W).pack(side=tk.LEFT)

		stat_row(stats_frame, "Ameaças detectadas", self.threats_var)
		stat_row(stats_frame, "Processos eliminados", self.killed_var)
		stat_row(stats_frame, "Arquivos restaurados", self.restored_var)
		stat_row(stats_frame, "Ativações de honeypot", self.honeypot_events_var)
		stat_row(stats_frame, "Backups criados", self.backups_var)

		# Actions: Manual scan
		actions = tb.LabelFrame(main, text="Análise Avançada de Ameaças")
		actions.pack(fill=tk.X, pady=(8, 0))
		
		# Scan path input
		self.scan_path_var = tk.StringVar()
		path_row = tb.Frame(actions)
		path_row.pack(fill=tk.X, padx=8, pady=6)
		entry = tb.Entry(path_row, textvariable=self.scan_path_var)
		entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
		tb.Button(path_row, text="Procurar...", command=self.on_browse).pack(side=tk.LEFT, padx=(8, 0))
		
		# Analysis type selection
		analysis_frame = tb.Frame(actions)
		analysis_frame.pack(fill=tk.X, padx=8, pady=4)
		
		self.signature_var = tk.BooleanVar(value=True)
		self.static_var = tk.BooleanVar(value=True)
		self.dynamic_var = tk.BooleanVar(value=False)
		
		tb.Checkbutton(analysis_frame, text="Assinatura", variable=self.signature_var).pack(side=tk.LEFT, padx=(0, 8))
		tb.Checkbutton(analysis_frame, text="Estático", variable=self.static_var).pack(side=tk.LEFT, padx=(0, 8))
		tb.Checkbutton(analysis_frame, text="Dinâmico", variable=self.dynamic_var).pack(side=tk.LEFT, padx=(0, 8))
		
		# Scan buttons
		button_frame = tb.Frame(actions)
		button_frame.pack(fill=tk.X, padx=8, pady=(0, 8))
		tb.Button(button_frame, text="Verificação Rápida", command=self.on_quick_scan, bootstyle=INFO or None).pack(side=tk.LEFT, padx=(0, 8))
		tb.Button(button_frame, text="Análise Completa", command=self.on_full_scan, bootstyle=PRIMARY or None).pack(side=tk.LEFT, padx=(0, 8))
		tb.Button(button_frame, text="Verificação Profunda", command=self.on_deep_scan, bootstyle=DANGER or None).pack(side=tk.LEFT)

		# Logs
		logs_frame = tb.LabelFrame(main, text="Logs")
		logs_frame.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
		self.log_text = tk.Text(logs_frame, height=14, wrap=tk.WORD, state=tk.DISABLED)
		self.log_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

	def _start_pollers(self) -> None:
		self.root.after(self.REFRESH_MS, self._poll_status)
		self.root.after(200, self._poll_logs)

	def _poll_status(self) -> None:
		def work():
			try:
				status = self.service.get_status()
				self._update_status(status)
			except Exception as e:
				self._append_log(f"Erro de status: {e}")
		self.root.after(self.REFRESH_MS, self._poll_status)

		threading.Thread(target=work, daemon=True).start()

	def _poll_logs(self) -> None:
		try:
			while True:
				msg = self.log_queue.get_nowait()
				self._append_log(msg)
		except queue.Empty:
			pass
		self.root.after(200, self._poll_logs)

	def _update_status(self, status: Dict[str, Any]) -> None:
		is_running = status.get('is_running', False)
		self.status_var.set("Executando" if is_running else "Parado")
		self.level_var.set(status.get('protection_level') or '-')
		self.uptime_var.set(status.get('uptime') or '-')

		stats = status.get('statistics', {}) or {}
		self.threats_var.set(str(stats.get('threats_detected', 0)))
		self.killed_var.set(str(stats.get('processes_killed', 0)))
		self.restored_var.set(str(stats.get('files_restored', 0)))
		self.honeypot_events_var.set(str(stats.get('honeypots_triggered', 0)))
		self.backups_var.set(str(stats.get('backups_created', 0)))

		# Toggle buttons
		self.start_btn.configure(state=tk.DISABLED if is_running else tk.NORMAL)
		self.stop_btn.configure(state=tk.NORMAL if is_running else tk.DISABLED)

	def _append_log(self, text: str) -> None:
		self.log_text.configure(state=tk.NORMAL)
		self.log_text.insert(tk.END, text + "\n")
		self.log_text.see(tk.END)
		self.log_text.configure(state=tk.DISABLED)

	def _update_auto_response_config(self) -> None:
		"""Atualizar configuração de resposta automática."""
		config = {
			'auto_kill_processes': self.auto_kill_var.get(),
			'auto_delete_files': self.auto_delete_var.get(),
			'auto_quarantine': self.auto_quarantine_var.get()
		}
		
		def work():
			success = self.service.configure_automatic_response(config)
			if success:
				self._append_log(f"Configuração de resposta automática atualizada: {config}")
			else:
				self._append_log("Falha ao atualizar configuração de resposta automática")
		
		threading.Thread(target=work, daemon=True).start()

	def on_start(self) -> None:
		def work():
			ok = self.service.start()
			self._append_log("Proteção iniciada" if ok else "Proteção já em execução ou falhou")
		threading.Thread(target=work, daemon=True).start()

	def on_stop(self) -> None:
		def work():
			ok = self.service.stop()
			self._append_log("Proteção parada" if ok else "Proteção não está executando")
		threading.Thread(target=work, daemon=True).start()

	def on_backup(self) -> None:
		def work():
			shadow_id = self.service.create_backup()
			if shadow_id:
				self._append_log(f"Backup criado: {shadow_id}")
			else:
				self._append_log("Falha ao criar backup")
		threading.Thread(target=work, daemon=True).start()

	def on_emergency_kill(self) -> None:
		if not messagebox.askyesno("Confirmar", "Eliminar todos os processos suspeitos de ransomware?"):
			return
		def work():
			res = self.service.emergency_kill()
			self._append_log(f"Terminated: {res.get('terminated')} | Failed: {res.get('failed')}")
		threading.Thread(target=work, daemon=True).start()

	def on_regenerate(self) -> None:
		if not messagebox.askyesno("Confirmar", "🔄 Regenerar todos os honeypots? A proteção será reiniciada se estiver executando."):
			return
		def work():
			count = self.service.regenerate_honeypots()
			self._append_log(f"🔄 Regenerados {count} honeypots")
		threading.Thread(target=work, daemon=True).start()
	
	def on_lethal_mode(self) -> None:
		"""Ativar MODO LETAL para máxima agressividade contra ransomware."""
		if not messagebox.askyesno("⚠️ MODO LETAL", 
			"💀 ATIVAR MODO LETAL?\n\n"
			"Isso irá:\n"
			"• Eliminar TODOS os processos suspeitos imediatamente\n"
			"• Excluir TODOS os arquivos suspeitos\n"
			"• Ativar proteção máxima\n"
			"• Verificar a cada 1 segundo\n\n"
			"Tem certeza?"):
			return
		
		def work():
			self._append_log("💀 ATIVANDO MODO LETAL - MÁXIMA AGRESSIVIDADE")
			
			# Configure lethal response settings
			lethal_config = {
				'auto_kill_processes': True,
				'auto_delete_files': True,
				'auto_quarantine': True,
				'kill_threshold': 30,  # Very low threshold
				'delete_threshold': 40,  # Very low threshold
				'quarantine_threshold': 20  # Very low threshold
			}
			
			success = self.service.configure_automatic_response(lethal_config)
			if success:
				self._append_log("🔥 MODO LETAL ATIVADO - RANSOMWARE SERÁ DESTRUÍDO")
				self._append_log("⚡ Frequência de monitoramento aumentada ao máximo")
				self._append_log("💀 Todos os processos suspeitos serão terminados imediatamente")
				self._append_log("🗑️ Todos os arquivos suspeitos serão excluídos imediatamente")
			else:
				self._append_log("❌ Falha ao ativar modo letal")
		
		threading.Thread(target=work, daemon=True).start()

	def on_check_compatibility(self) -> None:
		"""Verificar compatibilidade Windows e exibir resultados."""
		def work():
			try:
				self._append_log("🔍 Verificando compatibilidade Windows...")
				
				compat_info = self.service.get_windows_compatibility_info()
				
				# Update compatibility display
				system_info = compat_info.get('system_info', {})
				compat_status = compat_info.get('compatibility_status', {})
				
				# Update status
				platform = system_info.get('platform', 'Unknown')
				self.compat_status_var.set(platform)
				
				# Update compatibility score
				score = compat_status.get('compatibility_score', 0)
				self.compat_score_var.set(f"{score}%")
				
				# Update admin status
				is_admin = system_info.get('is_admin', False)
				admin_text = "✅ Sim" if is_admin else "❌ Não"
				self.compat_admin_var.set(admin_text)
				
				# Log detailed information
				self._append_log(f"Platform: {platform}")
				self._append_log(f"Compatibility Score: {score}%")
				self._append_log(f"Admin Privileges: {admin_text}")
				
				# Log available features
				features = system_info.get('available_features', {})
				self._append_log("Recursos Disponíveis:")
				for feature, available in features.items():
					status = "✅" if available else "❌"
					self._append_log(f"  {status} {feature}")
				
				# Log recommendations
				recommendations = compat_info.get('recommendations', [])
				if recommendations:
					self._append_log("Recomendações:")
					for rec in recommendations:
						self._append_log(f"  • {rec}")
				
				# Log optimizations
				optimizations = compat_info.get('optimizations', {})
				if optimizations:
					self._append_log("Otimizações do Sistema:")
					self._append_log(f"  Honeypot Count: {optimizations.get('honeypot_count', 'N/A')}")
					self._append_log(f"  Scan Interval: {optimizations.get('scan_interval', 'N/A')} seconds")
					self._append_log(f"  Enabled Features: {', '.join(optimizations.get('enabled_features', []))}")
				
					self._append_log("✅ Verificação de compatibilidade Windows concluída")
				
			except Exception as e:
				self._append_log(f"❌ Falha na verificação de compatibilidade: {e}")
		
		threading.Thread(target=work, daemon=True).start()

	def on_browse(self) -> None:
		# Ask user for file or directory
		path_file = filedialog.askopenfilename(title="Selecionar arquivo para verificar")
		if path_file:
			self.scan_path_var.set(path_file)
			return
		path_dir = filedialog.askdirectory(title="Ou selecionar diretório para verificar")
		if path_dir:
			self.scan_path_var.set(path_dir)

	def on_quick_scan(self) -> None:
		"""Verificação rápida apenas com detecção de assinatura."""
		self._perform_scan(['signature'])
	
	def on_full_scan(self) -> None:
		"""Verificação completa com assinatura e análise estática."""
		self._perform_scan(['signature', 'static'])
	
	def on_deep_scan(self) -> None:
		"""Verificação profunda com todos os tipos de análise."""
		self._perform_scan(['signature', 'static', 'dynamic'])
	
	def _perform_scan(self, analysis_types: List[str]) -> None:
		"""Executar verificação com tipos de análise especificados."""
		path = self.scan_path_var.get().strip()
		if not path:
			messagebox.showwarning("Análise de Ameaças", "Por favor, selecione um arquivo ou diretório")
			return
		
		def work():
			self._append_log(f"Iniciando análise {'/'.join(analysis_types)} de: {path}")
			res = self.service.manual_scan(path, analysis_types)
			
			if 'error' in res:
				self._append_log(f"Erro na análise: {res['error']}")
				return
			
			# Display unified analysis results
			if 'unified_score' in res:
				self._append_log(f"=== ANÁLISE UNIFICADA DE AMEAÇAS ===")
				self._append_log(f"Arquivo: {res['file']}")
				self._append_log(f"Pontuação Unificada: {res['unified_score']:.2f}")
				self._append_log(f"Nível de Ameaça: {res['threat_level']}")
				self._append_log(f"Família de Ameaça: {res.get('threat_family', 'Desconhecida')}")
				self._append_log(f"Confiança: {res.get('confidence', 0.0):.2f}")
				self._append_log(f"Métodos de Detecção: {', '.join(res.get('detection_methods', []))}")
				
				# Display unified indicators
				indicators = res.get('unified_indicators', [])
				if indicators:
					self._append_log(f"\nIndicadores de Ameaça ({len(indicators)}):")
					for indicator in indicators:
						self._append_log(f"  - {indicator['description']} [{indicator['severity']}]")
				
				# Display recommended actions
				actions = res.get('recommended_actions', [])
				if actions:
					self._append_log(f"\nAções Recomendadas:")
					for action in actions:
						self._append_log(f"  - {action}")
				
				# Display individual analysis results
				individual = res.get('individual_results', {})
				if individual:
					self._append_log(f"\nResultados de Análise Individual:")
					for method, result in individual.items():
						if method == 'signature':
							threats = result.get('threats_found', [])
							self._append_log(f"  Assinatura: {len(threats)} ameaças encontradas")
						elif method in ['static', 'dynamic']:
							score = result.get('suspicious_score', 0.0)
							self._append_log(f"  {method.title()}: {score:.2f} pontuação suspeita")
			
			# Handle directory scan results
			elif 'total_files' in res:
				self._append_log(f"=== ANÁLISE DE DIRETÓRIO ===")
				self._append_log(f"Diretório: {res['directory']}")
				self._append_log(f"Total de Arquivos: {res['total_files']}")
				self._append_log(f"Ameaças Encontradas: {res['threats_found']}")
				
				summary = res.get('summary', {})
				if summary:
					self._append_log(f"Nível Geral de Ameaça: {summary.get('threat_level', 'Desconhecido')}")
					families = summary.get('families', [])
					if families:
						self._append_log(f"Famílias de Ameaça: {', '.join(families)}")
			
			else:
				# Fallback for old format
				threats = res.get('threats_found') or []
				if threats:
					self._append_log(f"Ameaças no arquivo: {len(threats)}")
					for t in threats:
						desc = t.get('description') or str(t)
						self._append_log(f" - {desc}")
				else:
					self._append_log("Nenhuma ameaça encontrada")
		
		threading.Thread(target=work, daemon=True).start()

	def on_close(self) -> None:
		def shutdown_and_quit():
			try:
				self.service.stop()
			except Exception:
				pass
			self.root.after(100, self.root.destroy)
		threading.Thread(target=shutdown_and_quit, daemon=True).start()


def main() -> None:
	# Prefer ttkbootstrap themed window if available
	try:
		app = tb.Window(title="CYBERMANS Anti-Ransomware", themename="superhero")  # type: ignore
	except Exception:
		app = tk.Tk()
	gui = AntiRansomwareGUI(app)
	app.mainloop()


if __name__ == "__main__":
	main()
