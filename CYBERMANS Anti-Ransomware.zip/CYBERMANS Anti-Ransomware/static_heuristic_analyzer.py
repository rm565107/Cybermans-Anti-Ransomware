"""
Static Heuristic Analysis System for Anti-Ransomware
Analyzes file characteristics, entropy, and patterns without execution
"""

import os
import sys
import json
import hashlib
import struct
import logging
import math
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

class StaticHeuristicAnalyzer:
    def __init__(self, base_dir=None):
        """Initialize the static heuristic analyzer."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'static_heuristic_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("StaticHeuristicAnalyzer")
        
        # Analysis components
        self.entropy_analyzer = EntropyAnalyzer()
        self.string_analyzer = StringAnalyzer()
        self.crypto_analyzer = CryptoAnalyzer()
        self.packer_analyzer = PackerAnalyzer()
        
        # Heuristic rules and weights
        self.heuristic_rules = self._load_heuristic_rules()
        self.analysis_stats = {
            'files_analyzed': 0,
            'suspicious_files': 0,
            'high_entropy_files': 0,
            'packed_files': 0,
            'crypto_files': 0
        }
    
    def _load_heuristic_rules(self) -> List[Dict]:
        """Load heuristic analysis rules."""
        return [
            {
                'name': 'high_entropy',
                'weight': 0.3,
                'threshold': 7.5,
                'description': 'File has high entropy indicating encryption or packing'
            },
            {
                'name': 'suspicious_strings',
                'weight': 0.4,
                'description': 'File contains suspicious strings'
            },
            {
                'name': 'crypto_functions',
                'weight': 0.5,
                'description': 'File contains cryptographic functions'
            },
            {
                'name': 'packed_content',
                'weight': 0.3,
                'description': 'File appears to be packed or obfuscated'
            },
            {
                'name': 'suspicious_extensions',
                'weight': 0.4,
                'description': 'File has suspicious extension'
            }
        ]
    
    def analyze_file(self, filepath: str) -> Dict[str, Any]:
        """Perform comprehensive static heuristic analysis."""
        self.analysis_stats['files_analyzed'] += 1
        
        result = {
            'file': filepath,
            'timestamp': datetime.now().isoformat(),
            'analysis_type': 'static_heuristic',
            'suspicious_score': 0.0,
            'risk_level': 'LOW',
            'indicators': [],
            'detailed_analysis': {},
            'recommendations': []
        }
        
        file_path = Path(filepath)
        if not file_path.exists():
            result['error'] = 'File not found'
            return result
        
        try:
            # Perform various analyses
            entropy_analysis = self.entropy_analyzer.analyze(file_path)
            result['detailed_analysis']['entropy'] = entropy_analysis
            
            # String analysis
            string_analysis = self.string_analyzer.analyze(file_path)
            result['detailed_analysis']['strings'] = string_analysis
            
            # Crypto analysis
            crypto_analysis = self.crypto_analyzer.analyze(file_path)
            result['detailed_analysis']['crypto'] = crypto_analysis
            
            # Packer analysis
            packer_analysis = self.packer_analyzer.analyze(file_path)
            result['detailed_analysis']['packer'] = packer_analysis
            
            # Extension analysis
            extension_analysis = self._analyze_extension(file_path)
            result['detailed_analysis']['extension'] = extension_analysis
            
            # Calculate suspicious score
            result['suspicious_score'] = self._calculate_suspicious_score(result['detailed_analysis'])
            
            # Determine risk level
            result['risk_level'] = self._determine_risk_level(result['suspicious_score'])
            
            # Generate indicators
            result['indicators'] = self._generate_indicators(result['detailed_analysis'])
            
            # Generate recommendations
            result['recommendations'] = self._generate_recommendations(result)
            
            # Update statistics
            if result['suspicious_score'] > 0.5:
                self.analysis_stats['suspicious_files'] += 1
            
            if entropy_analysis.get('entropy', 0) > 7.5:
                self.analysis_stats['high_entropy_files'] += 1
            
            if packer_analysis.get('is_packed', False):
                self.analysis_stats['packed_files'] += 1
            
            if crypto_analysis.get('crypto_functions', []):
                self.analysis_stats['crypto_files'] += 1
            
        except Exception as e:
            self.logger.error(f"Error in static analysis: {e}")
            result['error'] = str(e)
        
        return result
    
    def _analyze_extension(self, file_path: Path) -> Dict[str, Any]:
        """Analyze file extension for suspicious patterns."""
        extension = file_path.suffix.lower()
        
        suspicious_extensions = [
            '.locked', '.encrypted', '.crypto', '.enc', '.lock',
            '.cerber', '.locky', '.zepto', '.odin', '.shit', '.thor',
            '.zzzzz', '.micro', '.cryptolocker', '.vault', '.petya',
            '.gwdata', '.cerber3', '.cerber2', '.crypt', '.WNCRY',
            '.WCRY', '.wncrypt', '.wncryt', '.teslacrypt', '.vvv',
            '.ccc', '.zzz', '.aaa'
        ]
        
        is_suspicious = extension in suspicious_extensions
        
        return {
            'extension': extension,
            'is_suspicious': is_suspicious,
            'description': f'Extension {extension} is {"suspicious" if is_suspicious else "normal"}'
        }
    
    def _calculate_suspicious_score(self, analysis: Dict) -> float:
        """Calculate overall suspicious score based on analysis results."""
        score = 0.0
        total_weight = 0.0
        
        for rule in self.heuristic_rules:
            rule_name = rule['name']
            weight = rule['weight']
            
            if rule_name == 'high_entropy':
                entropy = analysis.get('entropy', {}).get('entropy', 0)
                if entropy > rule['threshold']:
                    score += weight * min(entropy / 8.0, 1.0)  # Normalize to 0-1
                total_weight += weight
            
            elif rule_name == 'suspicious_strings':
                string_analysis = analysis.get('strings', {})
                suspicious_strings = string_analysis.get('suspicious_strings', [])
                if suspicious_strings:
                    score += weight * min(len(suspicious_strings) / 10.0, 1.0)
                total_weight += weight
            
            elif rule_name == 'crypto_functions':
                crypto_analysis = analysis.get('crypto', {})
                crypto_functions = crypto_analysis.get('crypto_functions', [])
                if crypto_functions:
                    score += weight * min(len(crypto_functions) / 5.0, 1.0)
                total_weight += weight
            
            elif rule_name == 'packed_content':
                packer_analysis = analysis.get('packer', {})
                if packer_analysis.get('is_packed', False):
                    score += weight
                total_weight += weight
            
            elif rule_name == 'suspicious_extensions':
                extension_analysis = analysis.get('extension', {})
                if extension_analysis.get('is_suspicious', False):
                    score += weight
                total_weight += weight
        
        if total_weight > 0:
            return min(score / total_weight, 1.0)
        return 0.0
    
    def _determine_risk_level(self, score: float) -> str:
        """Determine risk level based on suspicious score."""
        if score >= 0.8:
            return 'CRITICAL'
        elif score >= 0.6:
            return 'HIGH'
        elif score >= 0.4:
            return 'MEDIUM'
        elif score >= 0.2:
            return 'LOW'
        else:
            return 'MINIMAL'
    
    def _generate_indicators(self, analysis: Dict) -> List[Dict]:
        """Generate indicators based on analysis results."""
        indicators = []
        
        # Entropy indicators
        entropy = analysis.get('entropy', {})
        if entropy.get('entropy', 0) > 7.5:
            indicators.append({
                'type': 'high_entropy',
                'severity': 'HIGH',
                'description': f'File has high entropy ({entropy["entropy"]:.2f}) indicating encryption or packing'
            })
        
        # String indicators
        string_analysis = analysis.get('strings', {})
        if string_analysis.get('suspicious_strings'):
            indicators.append({
                'type': 'suspicious_strings',
                'severity': 'MEDIUM',
                'description': f'File contains {len(string_analysis["suspicious_strings"])} suspicious strings'
            })
        
        # Crypto indicators
        crypto_analysis = analysis.get('crypto', {})
        if crypto_analysis.get('crypto_functions'):
            indicators.append({
                'type': 'crypto_functions',
                'severity': 'HIGH',
                'description': f'File contains {len(crypto_analysis["crypto_functions"])} cryptographic functions'
            })
        
        # Packer indicators
        packer_analysis = analysis.get('packer', {})
        if packer_analysis.get('is_packed'):
            indicators.append({
                'type': 'packed_file',
                'severity': 'MEDIUM',
                'description': 'File appears to be packed or obfuscated'
            })
        
        # Extension indicators
        extension_analysis = analysis.get('extension', {})
        if extension_analysis.get('is_suspicious'):
            indicators.append({
                'type': 'suspicious_extension',
                'severity': 'HIGH',
                'description': f'File has suspicious extension: {extension_analysis["extension"]}'
            })
        
        return indicators
    
    def _generate_recommendations(self, result: Dict) -> List[str]:
        """Generate recommendations based on analysis results."""
        recommendations = []
        
        score = result['suspicious_score']
        risk_level = result['risk_level']
        
        if risk_level in ['CRITICAL', 'HIGH']:
            recommendations.append('IMMEDIATE_QUARANTINE: File should be quarantined immediately')
            recommendations.append('DEEP_ANALYSIS: Perform dynamic analysis in sandbox')
        
        if score > 0.6:
            recommendations.append('MONITOR_CLOSELY: Monitor file behavior closely')
        
        if result['detailed_analysis'].get('crypto', {}).get('crypto_functions'):
            recommendations.append('CRYPTO_ANALYSIS: Analyze cryptographic functions for ransomware behavior')
        
        if result['detailed_analysis'].get('packer', {}).get('is_packed'):
            recommendations.append('UNPACK_ANALYSIS: Unpack file for deeper analysis')
        
        if result['detailed_analysis'].get('extension', {}).get('is_suspicious'):
            recommendations.append('EXTENSION_ANALYSIS: File extension suggests ransomware activity')
        
        return recommendations
    
    def get_analysis_stats(self) -> Dict[str, Any]:
        """Get analysis statistics."""
        return {
            'statistics': self.analysis_stats,
            'heuristic_rules': len(self.heuristic_rules),
            'analysis_components': [
                'entropy_analyzer', 'string_analyzer',
                'crypto_analyzer', 'packer_analyzer'
            ]
        }


class EntropyAnalyzer:
    """Analyze file entropy for encryption and packing detection."""
    
    def analyze(self, file_path: Path) -> Dict[str, Any]:
        """Analyze file entropy."""
        try:
            with open(file_path, 'rb') as f:
                data = f.read(1024 * 1024)  # Read first 1MB
            
            if not data:
                return {'entropy': 0.0, 'analysis': 'empty_file'}
            
            # Calculate overall entropy
            entropy = self._calculate_entropy(data)
            
            # Calculate entropy by chunks
            chunk_size = 1024
            chunk_entropies = []
            for i in range(0, len(data), chunk_size):
                chunk = data[i:i + chunk_size]
                chunk_entropy = self._calculate_entropy(chunk)
                chunk_entropies.append(chunk_entropy)
            
            # Analyze entropy distribution
            avg_entropy = sum(chunk_entropies) / len(chunk_entropies)
            max_entropy = max(chunk_entropies)
            min_entropy = min(chunk_entropies)
            entropy_variance = self._calculate_variance(chunk_entropies)
            
            # Determine characteristics
            characteristics = []
            if entropy > 7.5:
                characteristics.append('high_entropy')
            if entropy > 7.8:
                characteristics.append('very_high_entropy')
            if entropy_variance < 0.1:
                characteristics.append('uniform_entropy')
            if max_entropy - min_entropy > 2.0:
                characteristics.append('variable_entropy')
            
            return {
                'entropy': entropy,
                'avg_entropy': avg_entropy,
                'max_entropy': max_entropy,
                'min_entropy': min_entropy,
                'entropy_variance': entropy_variance,
                'characteristics': characteristics,
                'analysis': self._interpret_entropy(entropy, characteristics)
            }
            
        except Exception as e:
            return {'error': str(e), 'entropy': 0.0}
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        
        frequency = {}
        for byte in data:
            frequency[byte] = frequency.get(byte, 0) + 1
        
        entropy = 0.0
        data_len = len(data)
        for freq in frequency.values():
            if freq > 0:
                probability = freq / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of values."""
        if len(values) < 2:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance
    
    def _interpret_entropy(self, entropy: float, characteristics: List[str]) -> str:
        """Interpret entropy analysis results."""
        if 'very_high_entropy' in characteristics:
            return 'File likely encrypted or heavily packed'
        elif 'high_entropy' in characteristics:
            return 'File may be encrypted or packed'
        elif 'uniform_entropy' in characteristics:
            return 'File has uniform entropy distribution'
        elif 'variable_entropy' in characteristics:
            return 'File has variable entropy distribution'
        else:
            return 'File has normal entropy distribution'


class StringAnalyzer:
    """Analyze strings in files for suspicious content."""
    
    def __init__(self):
        self.suspicious_patterns = self._load_suspicious_patterns()
        self.ransomware_strings = self._load_ransomware_strings()
    
    def analyze(self, file_path: Path) -> Dict[str, Any]:
        """Analyze strings in file."""
        try:
            with open(file_path, 'rb') as f:
                data = f.read(1024 * 1024)  # Read first 1MB
            
            # Extract strings
            strings = self._extract_strings(data)
            
            # Analyze strings
            suspicious_strings = self._find_suspicious_strings(strings)
            ransomware_strings = self._find_ransomware_strings(strings)
            crypto_strings = self._find_crypto_strings(strings)
            network_strings = self._find_network_strings(strings)
            
            return {
                'total_strings': len(strings),
                'suspicious_strings': suspicious_strings,
                'ransomware_strings': ransomware_strings,
                'crypto_strings': crypto_strings,
                'network_strings': network_strings,
                'analysis': self._interpret_strings(suspicious_strings, ransomware_strings)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _extract_strings(self, data: bytes, min_length: int = 4) -> List[str]:
        """Extract ASCII strings from binary data."""
        strings = []
        current_string = ""
        
        for byte in data:
            if 32 <= byte <= 126:  # Printable ASCII
                current_string += chr(byte)
            else:
                if len(current_string) >= min_length:
                    strings.append(current_string)
                current_string = ""
        
        if len(current_string) >= min_length:
            strings.append(current_string)
        
        return strings
    
    def _find_suspicious_strings(self, strings: List[str]) -> List[str]:
        """Find suspicious strings."""
        suspicious = []
        for string in strings:
            string_lower = string.lower()
            for pattern in self.suspicious_patterns:
                if pattern.lower() in string_lower:
                    suspicious.append(string)
                    break
        return suspicious
    
    def _find_ransomware_strings(self, strings: List[str]) -> List[str]:
        """Find ransomware-specific strings."""
        ransomware = []
        for string in strings:
            string_lower = string.lower()
            for pattern in self.ransomware_strings:
                if pattern.lower() in string_lower:
                    ransomware.append(string)
                    break
        return ransomware
    
    def _find_crypto_strings(self, strings: List[str]) -> List[str]:
        """Find cryptographic-related strings."""
        crypto_patterns = [
            'aes', 'des', 'rc4', 'rsa', 'md5', 'sha1', 'sha256',
            'encrypt', 'decrypt', 'cipher', 'hash', 'key', 'password'
        ]
        
        crypto = []
        for string in strings:
            string_lower = string.lower()
            for pattern in crypto_patterns:
                if pattern in string_lower:
                    crypto.append(string)
                    break
        return crypto
    
    def _find_network_strings(self, strings: List[str]) -> List[str]:
        """Find network-related strings."""
        network_patterns = [
            'http://', 'https://', 'ftp://', 'tcp://', 'udp://',
            'socket', 'connect', 'send', 'recv', 'bind', 'listen',
            'winsock', 'inet_addr', 'gethostbyname'
        ]
        
        network = []
        for string in strings:
            string_lower = string.lower()
            for pattern in network_patterns:
                if pattern in string_lower:
                    network.append(string)
                    break
        return network
    
    def _interpret_strings(self, suspicious: List[str], ransomware: List[str]) -> str:
        """Interpret string analysis results."""
        if ransomware:
            return f'Found {len(ransomware)} ransomware-specific strings'
        elif suspicious:
            return f'Found {len(suspicious)} suspicious strings'
        else:
            return 'No suspicious strings found'
    
    def _load_suspicious_patterns(self) -> List[str]:
        """Load suspicious string patterns."""
        return [
            'encrypt', 'decrypt', 'password', 'key', 'cipher',
            'bitcoin', 'btc', 'wallet', 'payment', 'ransom',
            'tor', 'onion', 'hidden', 'stealth', 'backdoor',
            'trojan', 'virus', 'malware', 'exploit', 'payload'
        ]
    
    def _load_ransomware_strings(self) -> List[str]:
        """Load ransomware-specific strings."""
        return [
            'your files have been encrypted',
            'all your files have been encrypted',
            'pay the ransom',
            'bitcoin address',
            'decrypt your files',
            'tor browser',
            'recover your files',
            'attention!',
            'your personal id',
            'how to decrypt files'
        ]


class CryptoAnalyzer:
    """Analyze cryptographic functions and patterns."""
    
    def analyze(self, file_path: Path) -> Dict[str, Any]:
        """Analyze cryptographic aspects of file."""
        try:
            with open(file_path, 'rb') as f:
                data = f.read(1024 * 1024)  # Read first 1MB
            
            # Look for crypto constants
            crypto_constants = self._find_crypto_constants(data)
            
            # Look for crypto algorithms
            crypto_algorithms = self._find_crypto_algorithms(data)
            
            # Look for key patterns
            key_patterns = self._find_key_patterns(data)
            
            return {
                'crypto_constants': crypto_constants,
                'crypto_algorithms': crypto_algorithms,
                'key_patterns': key_patterns,
                'crypto_functions': self._extract_crypto_functions(data),
                'analysis': self._interpret_crypto(crypto_constants, crypto_algorithms)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _find_crypto_constants(self, data: bytes) -> List[str]:
        """Find cryptographic constants."""
        constants = []
        
        # Common crypto constants
        crypto_consts = [
            b'AES', b'DES', b'RSA', b'MD5', b'SHA1', b'SHA256',
            b'RC4', b'Blowfish', b'Twofish', b'Serpent'
        ]
        
        for const in crypto_consts:
            if const in data:
                constants.append(const.decode('utf-8', errors='ignore'))
        
        return constants
    
    def _find_crypto_algorithms(self, data: bytes) -> List[str]:
        """Find cryptographic algorithm references."""
        algorithms = []
        
        # Look for algorithm names in strings
        algorithm_patterns = [
            b'AES-128', b'AES-256', b'DES-3', b'RSA-1024', b'RSA-2048',
            b'MD5', b'SHA-1', b'SHA-256', b'SHA-512', b'RC4'
        ]
        
        for pattern in algorithm_patterns:
            if pattern in data:
                algorithms.append(pattern.decode('utf-8', errors='ignore'))
        
        return algorithms
    
    def _find_key_patterns(self, data: bytes) -> List[str]:
        """Find cryptographic key patterns."""
        patterns = []
        
        # Look for common key patterns
        key_patterns = [
            b'-----BEGIN', b'-----END',  # PEM format
            b'0x',  # Hex keys
            b'key', b'Key', b'KEY',
            b'password', b'Password', b'PASSWORD'
        ]
        
        for pattern in key_patterns:
            if pattern in data:
                patterns.append(pattern.decode('utf-8', errors='ignore'))
        
        return patterns
    
    def _extract_crypto_functions(self, data: bytes) -> List[str]:
        """Extract cryptographic function names."""
        functions = []
        
        # Common crypto function names
        crypto_functions = [
            b'CryptEncrypt', b'CryptDecrypt', b'CryptCreateHash',
            b'CryptHashData', b'CryptDeriveKey', b'CryptGenKey',
            b'CryptImportKey', b'CryptExportKey', b'CryptDestroyKey',
            b'AES_encrypt', b'AES_decrypt', b'DES_encrypt', b'DES_decrypt',
            b'RSA_encrypt', b'RSA_decrypt', b'MD5_Init', b'MD5_Update',
            b'SHA1_Init', b'SHA1_Update', b'SHA256_Init', b'SHA256_Update'
        ]
        
        for func in crypto_functions:
            if func in data:
                functions.append(func.decode('utf-8', errors='ignore'))
        
        return functions
    
    def _interpret_crypto(self, constants: List[str], algorithms: List[str]) -> str:
        """Interpret cryptographic analysis results."""
        if algorithms:
            return f'File contains {len(algorithms)} cryptographic algorithms'
        elif constants:
            return f'File contains {len(constants)} cryptographic constants'
        else:
            return 'No cryptographic indicators found'


class PackerAnalyzer:
    """Analyze files for packing and obfuscation."""
    
    def __init__(self):
        self.packer_signatures = self._load_packer_signatures()
    
    def analyze(self, file_path: Path) -> Dict[str, Any]:
        """Analyze file for packing."""
        try:
            with open(file_path, 'rb') as f:
                data = f.read(8192)  # Read first 8KB
            
            # Check for packer signatures
            detected_packers = self._detect_packer_signatures(data)
            
            # Analyze entropy
            entropy = self._calculate_entropy(data)
            
            # Check for suspicious patterns
            suspicious_patterns = self._check_suspicious_patterns(data)
            
            # Determine if packed
            is_packed = self._determine_if_packed(detected_packers, entropy, suspicious_patterns)
            
            return {
                'is_packed': is_packed,
                'detected_packers': detected_packers,
                'entropy': entropy,
                'suspicious_patterns': suspicious_patterns,
                'analysis': self._interpret_packing(is_packed, detected_packers)
            }
            
        except Exception as e:
            return {'error': str(e), 'is_packed': False}
    
    def _detect_packer_signatures(self, data: bytes) -> List[str]:
        """Detect packer signatures."""
        detected = []
        
        for signature, packer_name in self.packer_signatures.items():
            if signature in data:
                detected.append(packer_name)
        
        return detected
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate entropy of data."""
        if not data:
            return 0.0
        
        frequency = {}
        for byte in data:
            frequency[byte] = frequency.get(byte, 0) + 1
        
        entropy = 0.0
        data_len = len(data)
        for freq in frequency.values():
            if freq > 0:
                probability = freq / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _check_suspicious_patterns(self, data: bytes) -> List[str]:
        """Check for suspicious patterns that might indicate packing."""
        patterns = []
        
        # Check for high entropy
        entropy = self._calculate_entropy(data)
        if entropy > 7.8:
            patterns.append('very_high_entropy')
        
        # Check for suspicious byte patterns
        if b'\x00' * 16 in data:
            patterns.append('null_padding')
        
        if b'\xFF' * 16 in data:
            patterns.append('ones_padding')
        
        # Check for compressed data patterns
        if data.startswith(b'PK\x03\x04'):  # ZIP
            patterns.append('zip_header')
        
        if data.startswith(b'Rar!'):
            patterns.append('rar_header')
        
        return patterns
    
    def _determine_if_packed(self, packers: List[str], entropy: float, patterns: List[str]) -> bool:
        """Determine if file is packed based on analysis."""
        if packers:
            return True
        
        if entropy > 7.8 and len(patterns) > 1:
            return True
        
        if 'very_high_entropy' in patterns and 'null_padding' in patterns:
            return True
        
        return False
    
    def _interpret_packing(self, is_packed: bool, packers: List[str]) -> str:
        """Interpret packing analysis results."""
        if packers:
            return f'File is packed with: {", ".join(packers)}'
        elif is_packed:
            return 'File appears to be packed or obfuscated'
        else:
            return 'File does not appear to be packed'
    
    def _load_packer_signatures(self) -> Dict[bytes, str]:
        """Load packer signatures."""
        return {
            b'UPX!': 'UPX',
            b'PECompact': 'PECompact',
            b'FSG!': 'FSG',
            b'MEW': 'MEW',
            b'ASPack': 'ASPack',
            b'Petite': 'Petite',
            b'WWPACK': 'WWPACK',
            b'PKLITE': 'PKLITE',
            b'LZEXE': 'LZEXE',
            b'DIET': 'DIET'
        }


def main():
    """Test the static heuristic analyzer."""
    print("=== Static Heuristic Analysis System ===\n")
    
    analyzer = StaticHeuristicAnalyzer()
    
    while True:
        print("\n1. Analyze File")
        print("2. Show Analysis Stats")
        print("3. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            filepath = input("Enter file path: ")
            result = analyzer.analyze_file(filepath)
            
            print(f"\n=== Analysis Results ===")
            print(f"File: {result['file']}")
            print(f"Suspicious Score: {result['suspicious_score']:.2f}")
            print(f"Risk Level: {result['risk_level']}")
            
            if result['indicators']:
                print(f"\nIndicators ({len(result['indicators'])}):")
                for indicator in result['indicators']:
                    print(f"  - {indicator['description']} [{indicator['severity']}]")
            
            if result['recommendations']:
                print(f"\nRecommendations:")
                for rec in result['recommendations']:
                    print(f"  - {rec}")
        
        elif choice == "2":
            stats = analyzer.get_analysis_stats()
            print(f"\n=== Analysis Statistics ===")
            for key, value in stats['statistics'].items():
                print(f"{key}: {value}")
        
        elif choice == "3":
            break


if __name__ == "__main__":
    main()
