#!/usr/bin/env python3
"""
CYBERMANS Anti-Ransomware Executable Builder
Creates a standalone executable using PyInstaller
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

class ExecutableBuilder:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.dist_dir = self.base_dir / "dist"
        self.build_dir = self.base_dir / "build"
        
    def _install_pyinstaller(self) -> bool:
        """Install PyInstaller if not available."""
        try:
            import PyInstaller
            print("✅ PyInstaller já está instalado")
            return True
        except ImportError:
            print("📦 Instalando PyInstaller...")
            try:
                subprocess.run([
                    sys.executable, "-m", "pip", "install", "pyinstaller"
                ], check=True)
                print("✅ PyInstaller instalado com sucesso")
                return True
            except subprocess.CalledProcessError as e:
                print(f"❌ Falha ao instalar PyInstaller: {e}")
                return False
    
    def _create_spec_file(self) -> bool:
        """Create PyInstaller spec file."""
        spec_content = '''# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

# Data files to include
datas = [
    ('rules', 'rules'),
    ('yara', 'yara'),
    ('requirements.txt', '.'),
]

# Hidden imports
hiddenimports = [
    'tkinter',
    'ttkbootstrap',
    'PIL',
    'watchdog',
    'psutil',
    'numpy',
    'schedule',
    'yara',
    'pefile',
    'requests',
    'win10toast',
    'colorama',
    'python-dateutil',
    'winshell',
    'win32com.client',
    'pythoncom',
    'pywintypes'
]

a = Analysis(
    ['launcher.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='CYBERMANS_AntiRansomware',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
    version_file=None,
    uac_admin=True,  # Request admin privileges
)
'''
        
        spec_file = self.base_dir / "CYBERMANS_AntiRansomware.spec"
        with open(spec_file, 'w') as f:
            f.write(spec_content)
        
        print("✅ Arquivo spec do PyInstaller criado")
        return True
    
    def _build_executable(self) -> bool:
        """Build the executable using PyInstaller."""
        print("🔨 Construindo executável...")
        
        try:
            # Clean previous builds
            if self.dist_dir.exists():
                shutil.rmtree(self.dist_dir)
            if self.build_dir.exists():
                shutil.rmtree(self.build_dir)
            
            # Build the executable
            cmd = [
                sys.executable, "-m", "PyInstaller",
                "--clean",
                "--noconfirm",
                "CYBERMANS_AntiRansomware.spec"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Executável construído com sucesso")
                return True
            else:
                print(f"❌ Construção falhou:")
                print(result.stderr)
                return False
                
        except Exception as e:
            print(f"❌ Erro ao construir executável: {e}")
            return False
    
    def _create_installer_package(self) -> bool:
        """Create a complete installer package."""
        print("📦 Criando pacote de instalação...")
        
        try:
            # Create package directory
            package_dir = self.base_dir / "CYBERMANS_Package"
            if package_dir.exists():
                shutil.rmtree(package_dir)
            package_dir.mkdir()
            
            # Copy executable
            exe_src = self.dist_dir / "CYBERMANS_AntiRansomware.exe"
            exe_dst = package_dir / "CYBERMANS_AntiRansomware.exe"
            if exe_src.exists():
                shutil.copy2(exe_src, exe_dst)
                print("  ✅ Copiado executável")
            
            # Copy additional files
            additional_files = [
                "requirements.txt",
                "README.md" if (self.base_dir / "README.md").exists() else None
            ]
            
            for file_name in additional_files:
                if file_name and (self.base_dir / file_name).exists():
                    shutil.copy2(self.base_dir / file_name, package_dir / file_name)
                    print(f"  ✅ Copiado {file_name}")
            
            # Create run script
            run_script = package_dir / "Run_CYBERMANS.bat"
            with open(run_script, 'w') as f:
                f.write('''@echo off
title CYBERMANS Anti-Ransomware
echo Starting CYBERMANS Anti-Ransomware...
echo.
CYBERMANS_AntiRansomware.exe
pause''')
            print("  ✅ Criado script de execução")
            
            # Create README
            readme_content = '''# CYBERMANS Anti-Ransomware

## Quick Start
1. Double-click "Run_CYBERMANS.bat" to start the application
2. The application will automatically request administrator privileges
3. Dependencies will be installed automatically on first run

## Manual Installation
1. Run "installer.py" as administrator for full installation
2. This will create desktop shortcuts and proper installation

## Requirements
- Windows 10/11
- Python 3.8+ (if running from source)
- Administrator privileges

## Features
- Real-time ransomware detection
- Honeypot monitoring
- Automatic threat response
- VSS backup integration
- YARA signature scanning
- WannaCry detection
- Windows compatibility optimization

## Support
For issues or questions, check the logs in the application directory.
'''
            
            readme_file = package_dir / "README.txt"
            with open(readme_file, 'w') as f:
                f.write(readme_content)
            print("  ✅ Criado README")
            
            print("✅ Pacote de instalação criado com sucesso")
            print(f"📁 Package location: {package_dir}")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao criar pacote de instalação: {e}")
            return False
    
    def build(self) -> bool:
        """Main build function."""
        print("=" * 60)
        print("    CONSTRUTOR DE EXECUTÁVEL CYBERMANS ANTI-RANSOMWARE")
        print("=" * 60)
        print()
        
        # Install PyInstaller
        if not self._install_pyinstaller():
            return False
        
        # Create spec file
        if not self._create_spec_file():
            return False
        
        # Build executable
        if not self._build_executable():
            return False
        
        # Create installer package
        if not self._create_installer_package():
            return False
        
        print()
        print("=" * 60)
        print("    CONSTRUÇÃO CONCLUÍDA!")
        print("=" * 60)
        print()
        print("✅ Executável criado com sucesso!")
        print()
        print("📁 Locais de saída:")
        print(f"   Executable: {self.dist_dir / 'CYBERMANS_AntiRansomware.exe'}")
        print(f"   Package: {self.base_dir / 'CYBERMANS_Package'}")
        print()
        print("🚀 Você pode agora distribuir a pasta CYBERMANS_Package")
        print("   Usuários podem executar 'Run_CYBERMANS.bat' para iniciar a aplicação")
        print()
        
        return True

def main():
    """Main entry point."""
    builder = ExecutableBuilder()
    
    try:
        success = builder.build()
        if not success:
            print("❌ Construção falhou")
        input("Pressione Enter para sair...")
    except KeyboardInterrupt:
        print("\n👋 Construção interrompida pelo usuário")
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()
