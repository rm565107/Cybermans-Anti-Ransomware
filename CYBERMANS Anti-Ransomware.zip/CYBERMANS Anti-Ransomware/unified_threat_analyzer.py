"""
Unified Threat Analysis System for Anti-Ransomware
Integrates Signature-Based, Static Heuristic, and Dynamic Heuristic Analysis
"""

import os
import sys
import json
import logging
import threading
import time
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import queue

# Import detection modules
from enhanced_signature_detector import EnhancedSignatureDetector
from static_heuristic_analyzer import StaticHeuristicAnalyzer
from dynamic_heuristic_analyzer import DynamicHeuristicAnalyzer

class UnifiedThreatAnalyzer:
    def __init__(self, base_dir=None):
        """Initialize the unified threat analyzer."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'unified_threat_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("UnifiedThreatAnalyzer")
        
        # Initialize detection modules
        self.signature_detector = EnhancedSignatureDetector(base_dir)
        self.static_analyzer = StaticHeuristicAnalyzer(base_dir)
        self.dynamic_analyzer = DynamicHeuristicAnalyzer(base_dir)
        
        # Threat classification system
        self.threat_classifier = ThreatClassifier()
        
        # Analysis queue and results
        self.analysis_queue = queue.Queue()
        self.results = {}
        
        # Statistics
        self.analysis_stats = {
            'total_analyses': 0,
            'threats_detected': 0,
            'false_positives': 0,
            'signature_detections': 0,
            'static_detections': 0,
            'dynamic_detections': 0,
            'unified_detections': 0
        }
    
    def analyze_file(self, filepath: str, analysis_types: List[str] = None) -> Dict[str, Any]:
        """Perform unified threat analysis on a file."""
        if analysis_types is None:
            analysis_types = ['signature', 'static', 'dynamic']
        
        self.analysis_stats['total_analyses'] += 1
        
        result = {
            'file': filepath,
            'timestamp': datetime.now().isoformat(),
            'analysis_types': analysis_types,
            'unified_score': 0.0,
            'threat_level': 'LOW',
            'threat_family': None,
            'detection_methods': [],
            'individual_results': {},
            'unified_indicators': [],
            'recommended_actions': [],
            'confidence': 0.0
        }
        
        file_path = Path(filepath)
        if not file_path.exists():
            result['error'] = 'File not found'
            return result
        
        try:
            # Perform individual analyses
            individual_results = {}
            
            if 'signature' in analysis_types:
                self.logger.info(f"Performing signature analysis on {filepath}")
                signature_result = self.signature_detector.comprehensive_scan(filepath)
                individual_results['signature'] = signature_result
                if signature_result.get('threats_found'):
                    self.analysis_stats['signature_detections'] += 1
            
            if 'static' in analysis_types:
                self.logger.info(f"Performing static analysis on {filepath}")
                static_result = self.static_analyzer.analyze_file(filepath)
                individual_results['static'] = static_result
                if static_result.get('suspicious_score', 0) > 0.5:
                    self.analysis_stats['static_detections'] += 1
            
            if 'dynamic' in analysis_types:
                self.logger.info(f"Performing dynamic analysis on {filepath}")
                dynamic_result = self.dynamic_analyzer.analyze_file(filepath)
                individual_results['dynamic'] = dynamic_result
                if dynamic_result.get('suspicious_score', 0) > 0.5:
                    self.analysis_stats['dynamic_detections'] += 1
            
            result['individual_results'] = individual_results
            
            # Perform unified analysis
            unified_analysis = self._perform_unified_analysis(individual_results)
            result.update(unified_analysis)
            
            # Update statistics
            if result['unified_score'] > 0.5:
                self.analysis_stats['threats_detected'] += 1
                self.analysis_stats['unified_detections'] += 1
            
        except Exception as e:
            self.logger.error(f"Error in unified analysis: {e}")
            result['error'] = str(e)
        
        return result
    
    def _perform_unified_analysis(self, individual_results: Dict) -> Dict[str, Any]:
        """Perform unified analysis combining all detection methods."""
        # Extract scores from individual analyses
        signature_score = 0.0
        static_score = 0.0
        dynamic_score = 0.0
        
        if 'signature' in individual_results:
            signature_result = individual_results['signature']
            signature_score = signature_result.get('confidence_score', 0.0)
        
        if 'static' in individual_results:
            static_result = individual_results['static']
            static_score = static_result.get('suspicious_score', 0.0)
        
        if 'dynamic' in individual_results:
            dynamic_result = individual_results['dynamic']
            dynamic_score = dynamic_result.get('suspicious_score', 0.0)
        
        # Calculate unified score using weighted combination
        weights = {'signature': 0.4, 'static': 0.3, 'dynamic': 0.3}
        total_weight = 0.0
        weighted_score = 0.0
        
        if 'signature' in individual_results:
            weighted_score += weights['signature'] * signature_score
            total_weight += weights['signature']
        
        if 'static' in individual_results:
            weighted_score += weights['static'] * static_score
            total_weight += weights['static']
        
        if 'dynamic' in individual_results:
            weighted_score += weights['dynamic'] * dynamic_score
            total_weight += weights['dynamic']
        
        unified_score = weighted_score / total_weight if total_weight > 0 else 0.0
        
        # Determine threat level
        threat_level = self._determine_threat_level(unified_score)
        
        # Identify threat family
        threat_family = self._identify_threat_family(individual_results)
        
        # Generate unified indicators
        unified_indicators = self._generate_unified_indicators(individual_results)
        
        # Generate recommended actions
        recommended_actions = self._generate_recommended_actions(unified_score, threat_level, unified_indicators)
        
        # Calculate confidence
        confidence = self._calculate_confidence(individual_results, unified_score)
        
        # Determine detection methods used
        detection_methods = []
        if 'signature' in individual_results and individual_results['signature'].get('threats_found'):
            detection_methods.append('signature')
        if 'static' in individual_results and individual_results['static'].get('suspicious_score', 0) > 0.5:
            detection_methods.append('static')
        if 'dynamic' in individual_results and individual_results['dynamic'].get('suspicious_score', 0) > 0.5:
            detection_methods.append('dynamic')
        
        return {
            'unified_score': unified_score,
            'threat_level': threat_level,
            'threat_family': threat_family,
            'detection_methods': detection_methods,
            'unified_indicators': unified_indicators,
            'recommended_actions': recommended_actions,
            'confidence': confidence
        }
    
    def _determine_threat_level(self, unified_score: float) -> str:
        """Determine threat level based on unified score."""
        if unified_score >= 0.9:
            return 'CRITICAL'
        elif unified_score >= 0.7:
            return 'HIGH'
        elif unified_score >= 0.5:
            return 'MEDIUM'
        elif unified_score >= 0.3:
            return 'LOW'
        else:
            return 'MINIMAL'
    
    def _identify_threat_family(self, individual_results: Dict) -> Optional[str]:
        """Identify threat family from individual analyses."""
        # Check signature analysis for family identification
        if 'signature' in individual_results:
            signature_result = individual_results['signature']
            if signature_result.get('threat_family'):
                return signature_result['threat_family']
        
        # Check for family indicators in other analyses
        family_indicators = []
        
        if 'static' in individual_results:
            static_result = individual_results['static']
            indicators = static_result.get('indicators', [])
            for indicator in indicators:
                if indicator.get('type') == 'suspicious_extension':
                    # Extract family from extension
                    ext = indicator.get('description', '').split(':')[-1].strip()
                    family = self._extension_to_family(ext)
                    if family:
                        family_indicators.append(family)
        
        if 'dynamic' in individual_results:
            dynamic_result = individual_results['dynamic']
            behaviors = dynamic_result.get('behaviors_detected', [])
            for behavior in behaviors:
                if behavior.get('type') == 'mass_file_encryption':
                    family_indicators.append('Generic_Ransomware')
        
        # Return most common family or first if tied
        if family_indicators:
            return max(set(family_indicators), key=family_indicators.count)
        
        return None
    
    def _extension_to_family(self, extension: str) -> Optional[str]:
        """Map file extension to ransomware family."""
        extension_families = {
            '.locky': 'Locky',
            '.zepto': 'Locky',
            '.odin': 'Locky',
            '.cerber': 'Cerber',
            '.cerber2': 'Cerber',
            '.cerber3': 'Cerber',
            '.wncry': 'WannaCry',
            '.wncrypt': 'WannaCry',
            '.petya': 'Petya',
            '.teslacrypt': 'TeslaCrypt',
            '.vvv': 'TeslaCrypt',
            '.cryptolocker': 'CryptoLocker'
        }
        
        return extension_families.get(extension.lower())
    
    def _generate_unified_indicators(self, individual_results: Dict) -> List[Dict]:
        """Generate unified indicators from all analyses."""
        indicators = []
        
        # Signature indicators
        if 'signature' in individual_results:
            signature_result = individual_results['signature']
            threats = signature_result.get('threats_found', [])
            for threat in threats:
                indicators.append({
                    'type': 'signature',
                    'severity': threat.get('severity', 'MEDIUM'),
                    'description': threat.get('description', 'Signature match'),
                    'method': 'signature_detection'
                })
        
        # Static indicators
        if 'static' in individual_results:
            static_result = individual_results['static']
            static_indicators = static_result.get('indicators', [])
            for indicator in static_indicators:
                indicators.append({
                    'type': 'static',
                    'severity': indicator.get('severity', 'MEDIUM'),
                    'description': indicator.get('description', 'Static analysis indicator'),
                    'method': 'static_analysis'
                })
        
        # Dynamic indicators
        if 'dynamic' in individual_results:
            dynamic_result = individual_results['dynamic']
            behaviors = dynamic_result.get('behaviors_detected', [])
            for behavior in behaviors:
                indicators.append({
                    'type': 'dynamic',
                    'severity': behavior.get('severity', 'MEDIUM'),
                    'description': behavior.get('description', 'Behavioral indicator'),
                    'method': 'dynamic_analysis'
                })
        
        return indicators
    
    def _generate_recommended_actions(self, unified_score: float, threat_level: str, indicators: List[Dict]) -> List[str]:
        """Generate recommended actions based on unified analysis."""
        actions = []
        
        if threat_level == 'CRITICAL':
            actions.append('IMMEDIATE_QUARANTINE: File should be quarantined immediately')
            actions.append('EMERGENCY_RESPONSE: Activate emergency response protocol')
            actions.append('SYSTEM_SCAN: Perform full system scan')
        
        elif threat_level == 'HIGH':
            actions.append('QUARANTINE: File should be quarantined')
            actions.append('DEEP_ANALYSIS: Perform additional analysis')
            actions.append('MONITOR_SYSTEM: Monitor system for additional threats')
        
        elif threat_level == 'MEDIUM':
            actions.append('MONITOR_CLOSELY: Monitor file behavior closely')
            actions.append('ADDITIONAL_SCAN: Perform additional scanning')
        
        else:
            actions.append('MONITOR: Continue monitoring file')
        
        # Add specific actions based on indicators
        for indicator in indicators:
            if indicator['type'] == 'signature' and indicator['severity'] == 'CRITICAL':
                actions.append('SIGNATURE_ANALYSIS: Analyze signature match details')
            
            elif indicator['type'] == 'static' and 'crypto' in indicator['description'].lower():
                actions.append('CRYPTO_ANALYSIS: Analyze cryptographic functions')
            
            elif indicator['type'] == 'dynamic' and 'encryption' in indicator['description'].lower():
                actions.append('ENCRYPTION_ANALYSIS: Analyze file encryption behavior')
        
        return list(set(actions))  # Remove duplicates
    
    def _calculate_confidence(self, individual_results: Dict, unified_score: float) -> float:
        """Calculate confidence in the unified analysis."""
        confidence_factors = []
        
        # Factor 1: Number of detection methods that agree
        agreeing_methods = 0
        total_methods = len(individual_results)
        
        for method, result in individual_results.items():
            if method == 'signature':
                if result.get('threats_found'):
                    agreeing_methods += 1
            elif method in ['static', 'dynamic']:
                if result.get('suspicious_score', 0) > 0.5:
                    agreeing_methods += 1
        
        if total_methods > 0:
            agreement_factor = agreeing_methods / total_methods
            confidence_factors.append(agreement_factor)
        
        # Factor 2: Strength of individual detections
        strength_factor = min(unified_score * 1.2, 1.0)
        confidence_factors.append(strength_factor)
        
        # Factor 3: Consistency across methods
        if len(individual_results) > 1:
            scores = []
            for method, result in individual_results.items():
                if method == 'signature':
                    scores.append(result.get('confidence_score', 0.0))
                elif method in ['static', 'dynamic']:
                    scores.append(result.get('suspicious_score', 0.0))
            
            if scores:
                score_variance = self._calculate_variance(scores)
                consistency_factor = max(0, 1.0 - score_variance)
                confidence_factors.append(consistency_factor)
        
        # Calculate final confidence
        if confidence_factors:
            return sum(confidence_factors) / len(confidence_factors)
        else:
            return 0.0
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of values."""
        if len(values) < 2:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance
    
    def analyze_directory(self, directory: str, analysis_types: List[str] = None) -> Dict[str, Any]:
        """Analyze all files in a directory."""
        if analysis_types is None:
            analysis_types = ['signature', 'static']
        
        dir_path = Path(directory)
        if not dir_path.exists():
            return {'error': 'Directory not found'}
        
        results = {
            'directory': directory,
            'timestamp': datetime.now().isoformat(),
            'total_files': 0,
            'threats_found': 0,
            'threat_files': [],
            'summary': {}
        }
        
        # Get all files in directory
        files = list(dir_path.rglob('*'))
        files = [f for f in files if f.is_file()]
        results['total_files'] = len(files)
        
        # Analyze each file
        for file_path in files:
            try:
                file_result = self.analyze_file(str(file_path), analysis_types)
                if file_result.get('unified_score', 0) > 0.5:
                    results['threats_found'] += 1
                    results['threat_files'].append({
                        'file': str(file_path),
                        'threat_level': file_result.get('threat_level'),
                        'unified_score': file_result.get('unified_score'),
                        'threat_family': file_result.get('threat_family')
                    })
            except Exception as e:
                self.logger.error(f"Error analyzing {file_path}: {e}")
        
        # Generate summary
        results['summary'] = self._generate_directory_summary(results['threat_files'])
        
        return results
    
    def _generate_directory_summary(self, threat_files: List[Dict]) -> Dict[str, Any]:
        """Generate summary of directory analysis."""
        if not threat_files:
            return {'threat_level': 'CLEAN', 'families': [], 'counts': {}}
        
        # Count threat levels
        threat_levels = {}
        families = {}
        
        for file_info in threat_files:
            level = file_info.get('threat_level', 'UNKNOWN')
            threat_levels[level] = threat_levels.get(level, 0) + 1
            
            family = file_info.get('threat_family')
            if family:
                families[family] = families.get(family, 0) + 1
        
        # Determine overall threat level
        if 'CRITICAL' in threat_levels:
            overall_level = 'CRITICAL'
        elif 'HIGH' in threat_levels:
            overall_level = 'HIGH'
        elif 'MEDIUM' in threat_levels:
            overall_level = 'MEDIUM'
        else:
            overall_level = 'LOW'
        
        return {
            'threat_level': overall_level,
            'families': list(families.keys()),
            'counts': threat_levels,
            'family_counts': families
        }
    
    def get_analysis_stats(self) -> Dict[str, Any]:
        """Get analysis statistics."""
        return {
            'unified_stats': self.analysis_stats,
            'signature_stats': self.signature_detector.get_detection_stats(),
            'static_stats': self.static_analyzer.get_analysis_stats(),
            'dynamic_stats': self.dynamic_analyzer.get_analysis_stats()
        }


class ThreatClassifier:
    """Classify threats based on analysis results."""
    
    def __init__(self):
        self.threat_categories = {
            'ransomware': {
                'indicators': ['file_encryption', 'ransom_note', 'bitcoin_payment'],
                'severity': 'CRITICAL'
            },
            'trojan': {
                'indicators': ['backdoor', 'remote_access', 'data_theft'],
                'severity': 'HIGH'
            },
            'worm': {
                'indicators': ['network_spread', 'self_replication', 'mass_infection'],
                'severity': 'HIGH'
            },
            'rootkit': {
                'indicators': ['system_hiding', 'privilege_escalation', 'persistence'],
                'severity': 'HIGH'
            },
            'adware': {
                'indicators': ['ad_display', 'browser_hijacking', 'popup_ads'],
                'severity': 'MEDIUM'
            },
            'spyware': {
                'indicators': ['data_collection', 'keylogging', 'screen_capture'],
                'severity': 'HIGH'
            }
        }
    
    def classify_threat(self, analysis_result: Dict) -> Dict[str, Any]:
        """Classify threat based on analysis result."""
        indicators = analysis_result.get('unified_indicators', [])
        threat_family = analysis_result.get('threat_family')
        
        # Check for specific threat categories
        detected_categories = []
        
        for category, info in self.threat_categories.items():
            category_indicators = info['indicators']
            matches = 0
            
            for indicator in indicators:
                description = indicator.get('description', '').lower()
                for cat_indicator in category_indicators:
                    if cat_indicator in description:
                        matches += 1
                        break
            
            if matches >= 2:  # Require at least 2 indicators
                detected_categories.append({
                    'category': category,
                    'severity': info['severity'],
                    'confidence': matches / len(category_indicators)
                })
        
        # Determine primary threat category
        primary_category = None
        if detected_categories:
            primary_category = max(detected_categories, key=lambda x: x['confidence'])
        
        return {
            'primary_category': primary_category,
            'detected_categories': detected_categories,
            'threat_family': threat_family,
            'classification_confidence': primary_category['confidence'] if primary_category else 0.0
        }


def main():
    """Test the unified threat analyzer."""
    print("=== Unified Threat Analysis System ===\n")
    
    analyzer = UnifiedThreatAnalyzer()
    
    while True:
        print("\n1. Analyze File")
        print("2. Analyze Directory")
        print("3. Show Analysis Stats")
        print("4. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            filepath = input("Enter file path: ")
            analysis_types = input("Enter analysis types (signature,static,dynamic) or press Enter for all: ")
            analysis_types = analysis_types.split(',') if analysis_types else None
            
            result = analyzer.analyze_file(filepath, analysis_types)
            
            print(f"\n=== Unified Analysis Results ===")
            print(f"File: {result['file']}")
            print(f"Unified Score: {result['unified_score']:.2f}")
            print(f"Threat Level: {result['threat_level']}")
            print(f"Threat Family: {result['threat_family'] or 'Unknown'}")
            print(f"Confidence: {result['confidence']:.2f}")
            print(f"Detection Methods: {', '.join(result['detection_methods'])}")
            
            if result['unified_indicators']:
                print(f"\nUnified Indicators ({len(result['unified_indicators'])}):")
                for indicator in result['unified_indicators']:
                    print(f"  - {indicator['description']} [{indicator['severity']}]")
            
            if result['recommended_actions']:
                print(f"\nRecommended Actions:")
                for action in result['recommended_actions']:
                    print(f"  - {action}")
        
        elif choice == "2":
            directory = input("Enter directory path: ")
            result = analyzer.analyze_directory(directory)
            
            print(f"\n=== Directory Analysis Results ===")
            print(f"Directory: {result['directory']}")
            print(f"Total Files: {result['total_files']}")
            print(f"Threats Found: {result['threats_found']}")
            
            summary = result['summary']
            print(f"Overall Threat Level: {summary['threat_level']}")
            if summary['families']:
                print(f"Threat Families: {', '.join(summary['families'])}")
        
        elif choice == "3":
            stats = analyzer.get_analysis_stats()
            print(f"\n=== Analysis Statistics ===")
            for key, value in stats['unified_stats'].items():
                print(f"{key}: {value}")
        
        elif choice == "4":
            break


if __name__ == "__main__":
    main()
