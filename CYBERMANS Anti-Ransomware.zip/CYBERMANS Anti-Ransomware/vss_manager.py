"""
Volume Shadow Copy (VSS) Manager for Anti-Ransomware Shield
Manages backup and restoration of honeypot files using Windows VSS
"""

import os
import subprocess
import json
import datetime
import shutil
from pathlib import Path
from typing import Dict, List, Optional
import win32com.client
import pythoncom
import logging
import schedule
import time
import threading

class VSSManager:
    def __init__(self, protected_paths=None, base_dir=None):
        """Initialize the VSS Manager."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        self.protected_paths = protected_paths or [str(self.base_dir / "Honeypots")]
        self.shadow_copies = []
        self.backup_history = []
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'vss_manager_{datetime.datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Load backup history
        self.history_file = self.base_dir / "Backups" / "backup_history.json"
        self.load_backup_history()
        
    def load_backup_history(self):
        """Load backup history from file."""
        if self.history_file.exists():
            with open(self.history_file, 'r') as f:
                self.backup_history = json.load(f)
        else:
            self.backup_history = []
    
    def save_backup_history(self):
        """Save backup history to file."""
        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.history_file, 'w') as f:
            json.dump(self.backup_history, f, indent=2)
    
    def get_recent_backup(self, volume: str, hours: int = 1) -> Optional[Dict]:
        """Check if a recent backup exists within the specified hours."""
        if not self.backup_history:
            return None
        
        cutoff_time = datetime.datetime.now() - datetime.timedelta(hours=hours)
        
        for backup in reversed(self.backup_history):
            try:
                backup_time = datetime.datetime.fromisoformat(backup['timestamp'])
                if backup_time > cutoff_time and backup.get('volume', '').startswith(volume):
                    # Skip shadow copy verification to avoid repeated VSS calls
                    # Just return the most recent backup from history
                    return backup
            except:
                continue
        
        return None
    
    def create_shadow_copy(self, volume="C:\\", check_existing=True):
        """Create a Volume Shadow Copy for the specified volume."""
        try:
            # Check if a recent backup already exists
            if check_existing:
                recent_backup = self.get_recent_backup(volume, hours=1)
                if recent_backup:
                    self.logger.info(f"Recent backup already exists: {recent_backup['shadow_id']}")
                    return recent_backup['shadow_id']
            # Use WMI to create shadow copy
            pythoncom.CoInitialize()
            wmi = win32com.client.Dispatch("WbemScripting.SWbemLocator")
            conn = wmi.ConnectServer(".", "root\\cimv2")
            
            # Create shadow copy
            shadow_class = conn.Get("Win32_ShadowCopy")
            result = shadow_class.Create(volume, "ClientAccessible")
            
            if result[0] == 0:
                shadow_id = result[1]
                self.logger.info(f"Successfully created shadow copy: {shadow_id}")
                
                # Get shadow copy details
                shadow_info = self.get_shadow_copy_info(shadow_id)
                
                # Record in history
                backup_entry = {
                    'timestamp': datetime.datetime.now().isoformat(),
                    'shadow_id': shadow_id,
                    'volume': volume,
                    'type': 'manual',
                    'status': 'success',
                    'details': shadow_info
                }
                
                self.backup_history.append(backup_entry)
                self.save_backup_history()
                
                return shadow_id
            else:
                self.logger.error(f"Failed to create shadow copy. Error code: {result[0]}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating shadow copy: {e}")
            return None
        finally:
            pythoncom.CoUninitialize()
    
    def create_shadow_copy_powershell(self, volume="C:", check_existing=True):
        """Alternative method using PowerShell to create shadow copy."""
        try:
            # Check if a recent backup already exists
            if check_existing:
                recent_backup = self.get_recent_backup(volume, hours=1)
                if recent_backup:
                    self.logger.info(f"Recent backup already exists: {recent_backup['shadow_id']}")
                    return recent_backup['shadow_id']
            # PowerShell command to create shadow copy
            ps_command = f'''
            $shadow = (Get-WmiObject -List Win32_ShadowCopy).Create("{volume}\\", "ClientAccessible")
            if ($shadow.ReturnValue -eq 0) {{
                Write-Output $shadow.ShadowID
            }} else {{
                Write-Output "ERROR: $($shadow.ReturnValue)"
            }}
            '''
            
            result = subprocess.run(
                ['powershell', '-Command', ps_command],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0 and not result.stdout.startswith("ERROR"):
                shadow_id = result.stdout.strip()
                self.logger.info(f"Shadow copy created via PowerShell: {shadow_id}")
                
                # Record in history
                backup_entry = {
                    'timestamp': datetime.datetime.now().isoformat(),
                    'shadow_id': shadow_id,
                    'volume': volume,
                    'type': 'powershell',
                    'status': 'success'
                }
                
                self.backup_history.append(backup_entry)
                self.save_backup_history()
                
                return shadow_id
            else:
                self.logger.error(f"Failed to create shadow copy: {result.stdout}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating shadow copy via PowerShell: {e}")
            return None
    
    def list_shadow_copies(self):
        """List all existing shadow copies."""
        try:
            # Check if running as administrator
            import ctypes
            if not ctypes.windll.shell32.IsUserAnAdmin():
                self.logger.warning("VSS operations require administrator privileges")
                return []
            
            ps_command = '''
            try {
                Get-WmiObject Win32_ShadowCopy | Select-Object ID, InstallDate, VolumeName | ConvertTo-Json
            } catch {
                Write-Output "[]"
            }
            '''
            
            result = subprocess.run(
                ['powershell', '-Command', ps_command],
                capture_output=True,
                text=True,
                timeout=10  # Add timeout to prevent hanging
            )
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    shadow_copies = json.loads(result.stdout) if result.stdout else []
                    self.shadow_copies = shadow_copies if isinstance(shadow_copies, list) else [shadow_copies]
                    self.logger.info(f"Found {len(self.shadow_copies)} shadow copies")
                    return self.shadow_copies
                except json.JSONDecodeError:
                    self.logger.warning("Failed to parse shadow copy data")
                    return []
            else:
                # Don't log error repeatedly, just return empty list
                return []
                
        except subprocess.TimeoutExpired:
            self.logger.warning("VSS query timed out")
            return []
        except Exception as e:
            # Only log error once per session
            if not hasattr(self, '_vss_error_logged'):
                self.logger.warning(f"VSS operations not available: {e}")
                self._vss_error_logged = True
            return []
    
    def get_shadow_copy_info(self, shadow_id):
        """Get detailed information about a specific shadow copy."""
        try:
            ps_command = f'''
            $shadow = Get-WmiObject Win32_ShadowCopy | Where-Object {{$_.ID -eq "{shadow_id}"}}
            if ($shadow) {{
                @{{
                    ID = $shadow.ID
                    SetID = $shadow.SetID
                    InstallDate = $shadow.InstallDate
                    VolumeName = $shadow.VolumeName
                    DeviceObject = $shadow.DeviceObject
                    State = $shadow.State
                }} | ConvertTo-Json
            }}
            '''
            
            result = subprocess.run(
                ['powershell', '-Command', ps_command],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0 and result.stdout:
                return json.loads(result.stdout)
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Error getting shadow copy info: {e}")
            return None
    
    def restore_from_shadow_copy(self, shadow_id, source_path, dest_path):
        """Restore files from a shadow copy."""
        try:
            # Get shadow copy device object
            shadow_info = self.get_shadow_copy_info(shadow_id)
            if not shadow_info:
                self.logger.error(f"Shadow copy {shadow_id} not found")
                return False
            
            device_object = shadow_info.get('DeviceObject')
            if not device_object:
                self.logger.error("Could not get device object for shadow copy")
                return False
            
            # Construct source path in shadow copy
            # Remove drive letter from source path
            relative_path = source_path.replace("C:\\", "").replace("C:", "")
            shadow_source = f"{device_object}\\{relative_path}"
            
            # Copy from shadow to destination
            ps_command = f'''
            Copy-Item -Path "{shadow_source}" -Destination "{dest_path}" -Recurse -Force
            '''
            
            result = subprocess.run(
                ['powershell', '-Command', ps_command],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                self.logger.info(f"Successfully restored from shadow copy: {source_path} -> {dest_path}")
                return True
            else:
                self.logger.error(f"Failed to restore: {result.stderr}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error restoring from shadow copy: {e}")
            return False
    
    def delete_shadow_copy(self, shadow_id):
        """Delete a specific shadow copy."""
        try:
            ps_command = f'''
            $shadow = Get-WmiObject Win32_ShadowCopy | Where-Object {{$_.ID -eq "{shadow_id}"}}
            if ($shadow) {{
                $shadow.Delete()
                Write-Output "SUCCESS"
            }} else {{
                Write-Output "NOT_FOUND"
            }}
            '''
            
            result = subprocess.run(
                ['powershell', '-Command', ps_command],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0 and "SUCCESS" in result.stdout:
                self.logger.info(f"Deleted shadow copy: {shadow_id}")
                return True
            else:
                self.logger.error(f"Failed to delete shadow copy: {result.stdout}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error deleting shadow copy: {e}")
            return False
    
    def create_file_backup(self, source_path, backup_dir=None):
        """Create a traditional file backup in addition to VSS."""
        try:
            if backup_dir is None:
                backup_dir = self.base_dir / "Backups" / "Files"
            backup_path = Path(backup_dir)
            backup_path.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            source = Path(source_path)
            
            if source.is_file():
                dest_file = backup_path / f"{source.stem}_{timestamp}{source.suffix}"
                shutil.copy2(source, dest_file)
                self.logger.info(f"File backed up: {source} -> {dest_file}")
                return str(dest_file)
            elif source.is_dir():
                dest_dir = backup_path / f"{source.name}_{timestamp}"
                shutil.copytree(source, dest_dir)
                self.logger.info(f"Directory backed up: {source} -> {dest_dir}")
                return str(dest_dir)
            else:
                self.logger.error(f"Source does not exist: {source}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating file backup: {e}")
            return None
    
    def schedule_automatic_backups(self):
        """Schedule automatic VSS backups."""
        # Schedule VSS creation every 4 hours
        schedule.every(4).hours.do(self.create_shadow_copy)
        
        # Schedule honeypot backup every 2 hours
        schedule.every(2).hours.do(self.backup_honeypots)
        
        # Schedule cleanup of old shadow copies daily
        schedule.every().day.at("02:00").do(self.cleanup_old_shadow_copies)
        
        self.logger.info("Automatic backup schedule configured")
        
        # Run scheduler in background thread
        def run_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        scheduler_thread.start()
        
        return scheduler_thread
    
    def backup_honeypots(self):
        """Backup all honeypot files."""
        for path in self.protected_paths:
            if Path(path).exists():
                backup_path = self.create_file_backup(path)
                if backup_path:
                    self.logger.info(f"Honeypots backed up from {path}")
    
    def cleanup_old_shadow_copies(self, keep_last=5):
        """Clean up old shadow copies, keeping only the most recent ones."""
        try:
            shadows = self.list_shadow_copies()
            
            if len(shadows) > keep_last:
                # Sort by install date and delete oldest
                sorted_shadows = sorted(shadows, key=lambda x: x.get('InstallDate', ''))
                to_delete = sorted_shadows[:-keep_last]
                
                for shadow in to_delete:
                    shadow_id = shadow.get('ID')
                    if shadow_id:
                        self.delete_shadow_copy(shadow_id)
                        self.logger.info(f"Cleaned up old shadow copy: {shadow_id}")
                        
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")
    
    def restore_all_honeypots(self, shadow_id=None):
        """Restore all honeypot files from the most recent shadow copy or specified one."""
        try:
            if not shadow_id:
                # Get most recent shadow copy
                shadows = self.list_shadow_copies()
                if not shadows:
                    self.logger.error("No shadow copies available for restoration")
                    return False
                
                # Sort by install date and get most recent
                sorted_shadows = sorted(shadows, key=lambda x: x.get('InstallDate', ''), reverse=True)
                shadow_id = sorted_shadows[0].get('ID')
            
            self.logger.info(f"Restoring honeypots from shadow copy: {shadow_id}")
            
            for path in self.protected_paths:
                restore_path = f"{path}_restored_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
                if self.restore_from_shadow_copy(shadow_id, path, restore_path):
                    self.logger.info(f"Restored: {path} -> {restore_path}")
                    
                    # Option to replace original with restored version
                    if Path(path).exists():
                        backup_original = f"{path}_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
                        shutil.move(path, backup_original)
                        self.logger.info(f"Original backed up to: {backup_original}")
                    
                    shutil.move(restore_path, path)
                    self.logger.info(f"Restored version moved to original location: {path}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring honeypots: {e}")
            return False
    
    def get_backup_status(self):
        """Get current backup status and statistics."""
        # Only call list_shadow_copies if we haven't done so recently
        if not hasattr(self, '_last_shadow_check') or (datetime.datetime.now() - self._last_shadow_check).seconds > 300:  # 5 minutes
            self.shadow_copies = self.list_shadow_copies()
            self._last_shadow_check = datetime.datetime.now()
        
        return {
            'total_shadow_copies': len(self.shadow_copies),
            'recent_backups': self.backup_history[-10:] if self.backup_history else [],
            'protected_paths': self.protected_paths,
            'last_backup': self.backup_history[-1] if self.backup_history else None,
            'shadow_copies': self.shadow_copies[:5]  # Show only 5 most recent
        }


if __name__ == "__main__":
    print("=== Anti-Ransomware VSS Manager ===\n")
    
    vss_manager = VSSManager()
    
    while True:
        print("\n1. Create Shadow Copy")
        print("2. List Shadow Copies")
        print("3. Restore Honeypots")
        print("4. Backup Honeypots")
        print("5. Schedule Automatic Backups")
        print("6. Cleanup Old Shadow Copies")
        print("7. Show Backup Status")
        print("8. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            shadow_id = vss_manager.create_shadow_copy()
            if shadow_id:
                print(f"✓ Shadow copy created: {shadow_id}")
        
        elif choice == "2":
            shadows = vss_manager.list_shadow_copies()
            print(f"\nFound {len(shadows)} shadow copies:")
            for shadow in shadows[:5]:
                print(f"  - ID: {shadow.get('ID')}")
                print(f"    Date: {shadow.get('InstallDate')}")
                print(f"    Volume: {shadow.get('VolumeName')}")
        
        elif choice == "3":
            if vss_manager.restore_all_honeypots():
                print("✓ Honeypots restored successfully")
        
        elif choice == "4":
            vss_manager.backup_honeypots()
            print("✓ Honeypots backed up")
        
        elif choice == "5":
            vss_manager.schedule_automatic_backups()
            print("✓ Automatic backups scheduled")
        
        elif choice == "6":
            vss_manager.cleanup_old_shadow_copies()
            print("✓ Old shadow copies cleaned up")
        
        elif choice == "7":
            status = vss_manager.get_backup_status()
            print(f"\nBackup Status:")
            print(f"  Total shadow copies: {status['total_shadow_copies']}")
            print(f"  Protected paths: {status['protected_paths']}")
            if status['last_backup']:
                print(f"  Last backup: {status['last_backup']['timestamp']}")
        
        elif choice == "8":
            break
        
        else:
            print("Invalid option")
