"""
Sistema Principal do Anti-Ransomware CYBERMANS
"""

import os
import sys
import time
import threading
import logging
import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import queue

# Importar todos os nossos módulos
from honeypot_monitor import HoneypotMonitor
from honeypot_gerador import EnhancedHoneypotSystem
from vss_manager import VSSManager
from yara_scanner import YaraScanner
from ransomware_killer import RansomwareKiller
from unified_threat_analyzer import UnifiedThreatAnalyzer
from automatic_threat_response import AutomaticThreatResponse
from windows_compatibility_manager import WindowsCompatibilityManager
from wannacry_detector import WannaCryDetector

class AntiRansomwareCore:
    def __init__(self, base_dir=None):
        """Inicializar o Sistema Principal Anti-Ransomware."""
        if base_dir is None:
            # Usar AppData/Local para melhor compatibilidade
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        # Estado do sistema
        self.is_running = False
        self.protection_level = "NORMAL"  # NORMAL, ELEVADO, CRÍTICO
        self.event_queue = queue.Queue()
        
        # Inicializar componentes
        self.logger = self._setup_logging()
        self.config = self._load_config()
        
        # Windows compatibility check
        self.compatibility_manager = WindowsCompatibilityManager(base_dir=str(self.base_dir))
        self._check_windows_compatibility()
        
        # Componentes principais - sistema de honeypot unificado
        self.honeypot_system = EnhancedHoneypotSystem(base_dir=str(self.base_dir))
        self.vss_manager = VSSManager(
            protected_paths=[str(self.base_dir / "Honeypots")],
            base_dir=str(self.base_dir)
        )
        self.yara_scanner = YaraScanner("rules")
        self.ransomware_killer = RansomwareKiller(base_dir=str(self.base_dir))
        self.unified_analyzer = UnifiedThreatAnalyzer(base_dir=str(self.base_dir))
        self.automatic_response = AutomaticThreatResponse(base_dir=str(self.base_dir))
        self.wannacry_detector = WannaCryDetector(base_dir=str(self.base_dir))
        self.honeypot_monitor = None  # Inicializado após honeypots serem criados
        
        # Threads
        self.monitor_thread = None
        self.scanner_thread = None
        self.response_thread = None
        
        # Estatísticas
        self.stats = {
            'start_time': None,
            'threats_detected': 0,
            'processes_killed': 0,
            'files_restored': 0,
            'honeypots_triggered': 0,
            'backups_created': 0
        }
        
        self.logger.info("Sistema Principal Anti-Ransomware inicializado")
    
    def _setup_logging(self) -> logging.Logger:
        """Configurar sistema de logs abrangente."""
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logger = logging.getLogger("AntiRansomwareCore")
        logger.setLevel(logging.DEBUG)
        
        # Manipulador de arquivo
        fh = logging.FileHandler(
            log_dir / f'core_{datetime.now().strftime("%Y%m%d")}.log',
            encoding='utf-8'
        )
        fh.setLevel(logging.DEBUG)
        
        # Manipulador de console
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        
        # Formatador
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        
        logger.addHandler(fh)
        logger.addHandler(ch)
        
        return logger
    
    def _load_config(self) -> Dict:
        """Carregar configuração do sistema."""
        config_file = self.base_dir / "config.json"
        
        default_config = {
            'honeypot_count': 30,
            'scan_interval': 10,  # segundos
            'backup_interval': 3600,  # 1 hora
            'auto_kill_threshold': 70,  # pontuação de confiança
            'auto_restore': True,
            'alert_sound': True,
            'vss_snapshots_to_keep': 5
        }
        
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    loaded_config = json.load(f)
                    default_config.update(loaded_config)
            except Exception as e:
                self.logger.error(f"Falha ao carregar configuração: {e}")
        
        return default_config
    
    def _check_windows_compatibility(self):
        """Check Windows compatibility and optimize settings."""
        try:
            compatibility_report = self.compatibility_manager.get_compatibility_report()
            
            # Log compatibility status
            self.logger.info(f"Windows Compatibility Check:")
            self.logger.info(f"  Platform: {compatibility_report['system_info'].get('platform', 'Unknown')}")
            self.logger.info(f"  Admin Privileges: {compatibility_report['system_info'].get('is_admin', False)}")
            self.logger.info(f"  Compatibility Score: {compatibility_report['compatibility_status']['compatibility_score']}%")
            
            # Apply system optimizations
            optimizations = self.compatibility_manager.optimize_for_system()
            
            # Update configuration based on system capabilities
            if optimizations['honeypot_count'] != self.config.get('honeypot_count', 30):
                self.config['honeypot_count'] = optimizations['honeypot_count']
                self.logger.info(f"Optimized honeypot count for system: {optimizations['honeypot_count']}")
            
            if optimizations['scan_interval'] != self.config.get('scan_interval', 10):
                self.config['scan_interval'] = optimizations['scan_interval']
                self.logger.info(f"Optimized scan interval for system: {optimizations['scan_interval']} seconds")
            
            # Log enabled/disabled features
            if optimizations['enabled_features']:
                self.logger.info(f"Enabled features: {', '.join(optimizations['enabled_features'])}")
            if optimizations['disabled_features']:
                self.logger.info(f"Disabled features: {', '.join(optimizations['disabled_features'])}")
            
            # Log recommendations
            recommendations = compatibility_report['recommendations']
            if recommendations:
                self.logger.warning("System Recommendations:")
                for rec in recommendations:
                    self.logger.warning(f"  • {rec}")
            
            # Save system configuration
            self.compatibility_manager.create_system_config()
            
        except Exception as e:
            self.logger.error(f"Windows compatibility check failed: {e}")
            self.logger.warning("Continuing with default settings")
    
    def initialize_protection(self) -> bool:
        """Inicializar todos os sistemas de proteção."""
        self.logger.info("Inicializando sistemas de proteção...")
        
        try:
            # Passo 1: Configurar sistema unificado de honeypot
            honeypot_registry = self.base_dir / "Honeypots" / "honeypot_registry.json"
            
            if not honeypot_registry.exists():
                self.logger.info("Inicializando sistema de honeypot...")
                # Criar honeypots estáticos (para monitoramento) e dinâmicos
                all_honeypots = self.honeypot_system.generate_honeypots(
                    static_count=self.config['honeypot_count'],  # Honeypots estáticos no diretório base
                    dynamic_count=50  # Honeypots dinâmicos através do sistema
                )
                self.logger.info(f"Criados {len(all_honeypots)} honeypots no total")
            else:
                # Apenas implantar honeypots dinâmicos adicionais
                self.logger.info("Implantando honeypots dinâmicos adicionais...")
                deployed = self.honeypot_system.deploy_enhanced_honeypots(count=20)
                self.logger.info(f"Implantados {len(deployed)} honeypots adicionais")
            
            # Passo 2: Inicializar monitor de honeypot
            self.honeypot_monitor = HoneypotMonitor(
                honeypot_registry_path=str(honeypot_registry),
                base_dir=str(self.base_dir)
            )
            
            # Passo 3: Criar backup VSS inicial
            self.logger.info("Criando backup VSS inicial...")
            shadow_id = self.vss_manager.create_shadow_copy_powershell()
            if shadow_id:
                self.stats['backups_created'] += 1
                self.logger.info(f"Backup inicial criado: {shadow_id}")
            
            # Passo 4: Verificar se regras YARA estão carregadas
            if not self.yara_scanner.compiled_rules:
                self.logger.warning("Regras YARA não carregadas, usando detecção baseada em padrões")
            
            self.logger.info("Sistemas de proteção inicializados com sucesso")
            return True
            
        except Exception as e:
            self.logger.error(f"Falha ao inicializar proteção: {e}")
            return False
    
    def start_protection(self) -> bool:
        """Iniciar todos os serviços de proteção."""
        if self.is_running:
            self.logger.warning("Proteção já está em execução")
            return False
        
        self.logger.info("Iniciando Proteção Anti-Ransomware...")
        
        # Inicializar se necessário
        if not self.honeypot_monitor:
            if not self.initialize_protection():
                return False
        
        self.is_running = True
        self.stats['start_time'] = datetime.now()
        
        # Iniciar threads de monitoramento
        self.monitor_thread = threading.Thread(target=self._monitor_worker, daemon=True)
        self.scanner_thread = threading.Thread(target=self._scanner_worker, daemon=True)
        self.response_thread = threading.Thread(target=self._response_worker, daemon=True)
        
        self.monitor_thread.start()
        self.scanner_thread.start()
        self.response_thread.start()
        
        # Iniciar sistema de resposta automática
        self.logger.info("Iniciando sistema de resposta automática...")
        self.automatic_response.start_response_system()
        
        # Iniciar detector especializado WannaCry
        self.logger.critical("[ALERT] ATIVANDO DETECTOR WANNACRY - MÁXIMA PROTEÇÃO")
        self.wannacry_detector.start_monitoring()
        
        # Iniciar backups VSS automáticos
        self.vss_manager.schedule_automatic_backups()
        
        self.logger.info("Proteção iniciada com sucesso")
        return True
    
    def stop_protection(self) -> bool:
        """Parar todos os serviços de proteção."""
        if not self.is_running:
            self.logger.warning("Proteção não está em execução")
            return False
        
        self.logger.info("Parando proteção...")
        self.is_running = False
        
        # Parar sistema de resposta automática
        self.automatic_response.stop_response_system()
        
        # Parar detector WannaCry
        self.wannacry_detector.stop_monitoring()
        
        # Sinalizar threads para parar
        self.event_queue.put({'type': 'SHUTDOWN'})
        
        # Aguardar threads
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        if self.scanner_thread:
            self.scanner_thread.join(timeout=5)
        if self.response_thread:
            self.response_thread.join(timeout=5)
        
        self.logger.info("Proteção parada")
        return True
    
    def _monitor_worker(self):
        """Thread de trabalho para monitoramento de honeypots."""
        self.logger.info("Thread de monitoramento iniciada")
        
        while self.is_running:
            try:
                # Verificar integridade dos honeypots
                for filepath, info in self.honeypot_monitor.honeypots.items():
                    if not Path(filepath).exists() and info['status'] == 'active':
                        self.event_queue.put({
                            'type': 'HONEYPOT_MISSING',
                            'filepath': filepath,
                            'timestamp': datetime.now().isoformat()
                        })
                        self.stats['honeypots_triggered'] += 1
                    
                    # Verificar modificações
                    current_hash = self.honeypot_monitor.calculate_file_hash(filepath)
                    if current_hash and info['original_checksum']:
                        if str(current_hash) != str(info['original_checksum']):
                            self.event_queue.put({
                                'type': 'HONEYPOT_MODIFIED',
                                'filepath': filepath,
                                'timestamp': datetime.now().isoformat()
                            })
                            self.stats['honeypots_triggered'] += 1
                
                # Verificar pastas honeypot para detecção precoce
                accessed_folders = self.honeypot_system.check_honey_folders()
                if accessed_folders:
                    for folder in accessed_folders:
                        self.event_queue.put({
                            'type': 'HONEY_FOLDER_ACCESSED',
                            'folder': folder,
                            'timestamp': datetime.now().isoformat()
                        })
                        self.stats['honeypots_triggered'] += 1
                        self.logger.critical(f"AVISO: Pasta honeypot acessada - {folder}")
                
                time.sleep(1)  # Verificar a cada 1 segundo para resposta mais rápida
                
            except Exception as e:
                self.logger.error(f"Erro na thread de monitoramento: {e}")
                time.sleep(5)
    
    def _scanner_worker(self):
        """Thread de trabalho para varredura YARA contínua."""
        self.logger.info("Thread de varredura iniciada")
        
        while self.is_running:
            try:
                # Varrer diretório base de honeypots
                honeypot_dir = self.base_dir / "Honeypots"
                
                for file_path in honeypot_dir.rglob('*'):
                    if not self.is_running:
                        break
                    
                    if file_path.is_file():
                        # Verificação rápida de entropia
                        if self.yara_scanner.quick_scan(str(file_path)):
                            # Varredura completa se suspeito
                            result = self.yara_scanner.scan_file(str(file_path))
                            
                            if result.get('threats_found'):
                                self.event_queue.put({
                                    'type': 'THREAT_DETECTED',
                                    'file': str(file_path),
                                    'threats': result['threats_found'],
                                    'timestamp': datetime.now().isoformat()
                                })
                                self.stats['threats_detected'] += 1
                
                # Varrer arquivos honeypot aprimorados (distribuídos pelo sistema)
                try:
                    enhanced_files = [
                        Path(item['path']) for item in (self.honeypot_system.registry or [])
                        if item.get('type') != 'honey_folder'
                    ]
                except Exception:
                    enhanced_files = []
                
                for file_path in enhanced_files:
                    if not self.is_running:
                        break
                    if file_path.exists() and file_path.is_file():
                        if self.yara_scanner.quick_scan(str(file_path)):
                            result = self.yara_scanner.scan_file(str(file_path))
                            if result.get('threats_found'):
                                self.event_queue.put({
                                    'type': 'THREAT_DETECTED',
                                    'file': str(file_path),
                                    'threats': result['threats_found'],
                                    'timestamp': datetime.now().isoformat()
                                })
                                self.stats['threats_detected'] += 1
                
                time.sleep(2)  # Scan every 2 seconds for faster detection
                
            except Exception as e:
                self.logger.error(f"Erro na thread de varredura: {e}")
                time.sleep(10)
    
    def _response_worker(self):
        """Thread de trabalho para resposta automatizada a ameaças."""
        self.logger.info("Thread de resposta iniciada")
        
        while self.is_running:
            try:
                # Obter evento da fila (timeout para permitir verificação de is_running)
                try:
                    event = self.event_queue.get(timeout=1)
                except queue.Empty:
                    continue
                
                if event['type'] == 'SHUTDOWN':
                    break
                
                self.logger.warning(f"Processando evento: {event['type']}")
                
                # Tratar diferentes tipos de eventos
                if event['type'] in ['HONEYPOT_MODIFIED', 'HONEYPOT_MISSING', 'THREAT_DETECTED', 'HONEY_FOLDER_ACCESSED']:
                    self._handle_ransomware_detection(event)
                
            except Exception as e:
                self.logger.error(f"Erro na thread de resposta: {e}")
    
    def _handle_ransomware_detection(self, event: Dict):
        """Tratar detecção de ransomware com resposta LETAL e IMEDIATA."""
        self.logger.critical(f"[ALERT] RANSOMWARE DETECTADO - INICIANDO NEUTRALIZAÇÃO LETAL: {event}")
        
        # Elevar nível de proteção IMEDIATAMENTE
        self.protection_level = "CRITICAL"
        
        # LETHAL RESPONSE: Immediate aggressive action
        self._execute_lethal_response(event)
        
        # Trigger automatic threat response system
        threat_event = {
            'event_id': f"threat_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'type': 'ransomware_detection',
            'threat_score': event.get('confidence', 0.9),
            'threat_level': 'CRITICAL',
            'source': 'honeypot_monitor',
            'timestamp': datetime.now().isoformat(),
            'details': event
        }
        
        # Queue threat event for automatic response
        self.automatic_response.queue_threat_event(threat_event)
        
        # Passo 1: Criar backup VSS de emergência
        self.logger.info("Criando backup de emergência...")
        shadow_id = self.vss_manager.create_shadow_copy_powershell()
        if shadow_id:
            self.stats['backups_created'] += 1
            self.logger.info(f"Backup de emergência criado: {shadow_id}")
        
        # Passo 2: Identificar e encerrar processos suspeitos
        self.logger.info("Analisando processos de ransomware...")
        suspects = self.ransomware_killer.identify_ransomware_processes(
            honeypot_files=list(self.honeypot_monitor.honeypots.keys())
        )
        
        for suspect in suspects:
            if suspect['score'] >= self.config['auto_kill_threshold']:
                self.logger.critical(f"Encerrando processo de ransomware: {suspect['name']} (PID: {suspect['pid']})")
                if self.ransomware_killer.terminate_process(suspect['pid'], force=True):
                    self.stats['processes_killed'] += 1
        
        # Passo 3: Honeypot restoration is now MANUAL ONLY via GUI button
        # Automatic restoration disabled for better control
        if event['type'] in ['HONEYPOT_MODIFIED', 'HONEYPOT_MISSING']:
            self.logger.critical("HONEYPOTS COMPROMISED - Manual regeneration required via GUI")
            # Log the incident but don't auto-restore
            self.stats['honeypots_triggered'] += 1
        
        # Step 4: Alert user
        if self.config['alert_sound']:
            import winsound
            try:
                for _ in range(3):
                    winsound.Beep(1000, 500)
                    time.sleep(0.5)
            except:
                pass
        
        # Passo 5: Salvar relatório do incidente
        self._save_incident_report(event, suspects)
        
        # Após tratar, reduzir o nível de proteção após algum tempo
        threading.Timer(300, self._reduce_protection_level).start()
    
    def _execute_lethal_response(self, event: Dict):
        """Execute LETHAL response against ransomware - IMMEDIATE and AGGRESSIVE."""
        self.logger.critical("[LETHAL] EXECUTING LETHAL RESPONSE - MAXIMUM AGGRESSION MODE")
        
        try:
            # STEP 1: IMMEDIATE PROCESS TERMINATION - KILL EVERYTHING SUSPICIOUS
            self.logger.critical("[STEP 1] TERMINATING ALL SUSPICIOUS PROCESSES")
            suspects = self.ransomware_killer.identify_ransomware_processes(
                honeypot_files=list(self.honeypot_monitor.honeypots.keys())
            )
            
            # LOWER THRESHOLD FOR MORE AGGRESSIVE KILLING
            lethal_threshold = 50  # Much lower than normal 70
            for suspect in suspects:
                if suspect['score'] >= lethal_threshold:
                    self.logger.critical(f"[KILL] LETHAL KILL: {suspect['name']} (PID: {suspect['pid']}) - Score: {suspect['score']}")
                    if self.ransomware_killer.terminate_process(suspect['pid'], force=True):
                        self.stats['processes_killed'] += 1
                        self.logger.critical(f"[SUCCESS] PROCESS ELIMINATED: {suspect['name']}")
            
            # STEP 2: EMERGENCY BACKUP - CREATE IMMEDIATE BACKUP
            self.logger.critical("[STEP 2] CREATING EMERGENCY BACKUP")
            shadow_id = self.vss_manager.create_shadow_copy_powershell()
            if shadow_id:
                self.stats['backups_created'] += 1
                self.logger.critical(f"[SUCCESS] EMERGENCY BACKUP CREATED: {shadow_id}")
            
            # STEP 3: AGGRESSIVE FILE SCANNING AND DELETION
            self.logger.critical("[STEP 3] SCANNING FOR MALICIOUS FILES")
            self._aggressive_file_scan_and_delete()
            
            # STEP 4: NETWORK ISOLATION (if possible)
            self.logger.critical("[STEP 4] ATTEMPTING NETWORK ISOLATION")
            self._isolate_suspicious_network_activity()
            
            # STEP 5: SYSTEM LOCKDOWN
            self.logger.critical("[STEP 5] SYSTEM LOCKDOWN ACTIVATED")
            self._activate_system_lockdown()
            
            self.logger.critical("[LETHAL] LETHAL RESPONSE COMPLETED - RANSOMWARE NEUTRALIZED")
            
        except Exception as e:
            self.logger.error(f"[ERROR] Error in lethal response: {e}")
    
    def _aggressive_file_scan_and_delete(self):
        """Aggressively scan and delete suspicious files."""
        try:
            # Scan common user directories for ransomware files
            suspicious_extensions = ['.locked', '.encrypted', '.crypto', '.enc', '.lock', 
                                   '.cerber', '.locky', '.zepto', '.odin', '.crypt', '.locked']
            
            user_dirs = [
                Path.home() / "Desktop",
                Path.home() / "Documents", 
                Path.home() / "Downloads",
                Path.home() / "Pictures",
                Path.home() / "Videos"
            ]
            
            # Get application directory for protection
            app_dir = self.base_dir.resolve()
            
            deleted_count = 0
            for user_dir in user_dirs:
                if user_dir.exists():
                    for file_path in user_dir.rglob('*'):
                        if file_path.is_file() and file_path.suffix.lower() in suspicious_extensions:
                            # PROTECTION: Skip files in application directory
                            if self._is_application_file(file_path, app_dir):
                                self.logger.info(f"[PROTECTED] APPLICATION FILE: {file_path}")
                                continue
                                
                            try:
                                # Create backup before deletion
                                backup_path = self.base_dir / "Deleted_Files_Backup"
                                backup_path.mkdir(parents=True, exist_ok=True)
                                shutil.copy2(file_path, backup_path / f"{file_path.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
                                
                                # Delete the file
                                file_path.unlink()
                                deleted_count += 1
                                self.logger.critical(f"[DELETE] DELETED SUSPICIOUS FILE: {file_path}")
                            except Exception as e:
                                self.logger.error(f"Failed to delete {file_path}: {e}")
            
            if deleted_count > 0:
                self.logger.critical(f"[ELIMINATED] ELIMINATED {deleted_count} SUSPICIOUS FILES")
                
        except Exception as e:
            self.logger.error(f"Error in aggressive file scan: {e}")
    
    def _is_application_file(self, file_path: Path, app_dir: Path) -> bool:
        """Check if file belongs to the application and should be protected."""
        try:
            # Check if file is in application directory
            if app_dir in file_path.parents or file_path.parent == app_dir:
                return True
            
            # Check for application-specific file names
            app_files = [
                'wannacry_detector.py',
                'antiransomware.py', 
                'GUI_PART_2.py',
                'launcher.py',
                'ransomware_killer.py',
                'honeypot_monitor.py',
                'automatic_threat_response.py',
                'yara_scanner.py',
                'enhanced_signature_detector.py',
                'static_heuristic_analyzer.py',
                'dynamic_heuristic_analyzer.py',
                'unified_threat_analyzer.py',
                'vss_manager.py',
                'windows_compatibility_manager.py',
                'config.json',
                'requirements.txt',
                'setup.py',
                'build_executable.py',
                'installer.py'
            ]
            
            if file_path.name in app_files:
                return True
            
            # Check for application-specific directories
            app_dirs = [
                'Config',
                'Logs', 
                'Backups',
                'Quarantine',
                'Incidents',
                'Honeypots',
                'rules',
                'yara'
            ]
            
            for app_dir_name in app_dirs:
                if app_dir_name in file_path.parts:
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking application file: {e}")
            return False
    
    def _isolate_suspicious_network_activity(self):
        """Attempt to isolate suspicious network activity."""
        try:
            # This would integrate with Windows Firewall to block suspicious connections
            # For now, we'll log the action
            self.logger.critical("[NETWORK] NETWORK ISOLATION: Blocking suspicious network activity")
            # Future enhancement: Implement actual network isolation
        except Exception as e:
            self.logger.error(f"Error in network isolation: {e}")
    
    def _activate_system_lockdown(self):
        """Activate system lockdown measures."""
        try:
            # Increase monitoring frequency
            self.config['scan_interval'] = 2  # Scan every 2 seconds instead of 10
            
            # Set maximum protection level
            self.protection_level = "CRITICAL"
            
            self.logger.critical("🔒 SYSTEM LOCKDOWN: Maximum protection activated")
        except Exception as e:
            self.logger.error(f"Error in system lockdown: {e}")
    
    def _reduce_protection_level(self):
        """Reduzir o nível de proteção após tratar a ameaça."""
        if self.protection_level == "CRITICAL":
            self.protection_level = "ELEVATED"
            self.logger.info("Nível de proteção reduzido para ELEVATED")
            
            # Reduzir ainda mais após mais tempo
            threading.Timer(600, lambda: setattr(self, 'protection_level', 'NORMAL')).start()
    
    def _save_incident_report(self, event: Dict, suspects: List[Dict]):
        """Salvar relatório detalhado do incidente."""
        report_dir = self.base_dir / "Incidents"
        report_dir.mkdir(parents=True, exist_ok=True)
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'event': event,
            'suspected_processes': suspects,
            'actions_taken': {
                'processes_killed': self.stats['processes_killed'],
                'files_restored': self.stats['files_restored'],
                'backups_created': self.stats['backups_created']
            },
            'system_state': self.get_status()
        }
        
        report_file = report_dir / f"incident_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        self.logger.info(f"Relatório de incidente salvo: {report_file}")
    
    def get_status(self) -> Dict:
        """Obter status abrangente do sistema."""
        uptime = None
        if self.stats['start_time']:
            uptime = str(datetime.now() - self.stats['start_time'])
        
        # Get VSS backup count safely
        try:
            vss_backups = len(self.vss_manager.list_shadow_copies())
        except Exception:
            vss_backups = 0
        
        # Get automatic response statistics
        response_stats = self.automatic_response.get_response_stats()
        
        return {
            'is_running': self.is_running,
            'protection_level': self.protection_level,
            'uptime': uptime,
            'statistics': self.stats,
            'components': {
                'honeypots': len(self.honeypot_monitor.honeypots) if self.honeypot_monitor else 0,
                'yara_rules': bool(self.yara_scanner.compiled_rules),
                'vss_backups': vss_backups,
                'config': self.config
            },
            'automatic_response': response_stats
        }
    
    def perform_manual_scan(self, path: str, analysis_types: List[str] = None) -> Dict:
        """Realizar verificação manual de um arquivo ou diretório."""
        self.logger.info(f"Verificação manual solicitada para: {path}")
        
        if analysis_types is None:
            analysis_types = ['signature', 'static', 'dynamic']
        
        if Path(path).is_file():
            result = self.unified_analyzer.analyze_file(path, analysis_types)
        elif Path(path).is_dir():
            result = self.unified_analyzer.analyze_directory(path, analysis_types)
        else:
            return {'error': 'Caminho inválido'}
        
        # Check if high-threat malware was detected and trigger automatic response
        if 'unified_score' in result and result['unified_score'] >= 0.7:
            threat_event = {
                'event_id': f"manual_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'type': 'manual_scan_threat',
                'threat_score': result['unified_score'],
                'threat_level': result.get('threat_level', 'HIGH'),
                'source': 'manual_scan',
                'timestamp': datetime.now().isoformat(),
                'file_path': path,
                'details': result
            }
            
            # Queue threat event for automatic response
            self.automatic_response.queue_threat_event(threat_event)
            self.logger.warning(f"High-threat detected in manual scan: {path} (Score: {result['unified_score']:.2f})")
        
        return result
    
    def configure_automatic_response(self, config: Dict[str, Any]) -> bool:
        """Configure automatic threat response settings."""
        try:
            self.automatic_response.update_response_config(config)
            self.logger.info(f"Automatic response configuration updated: {config}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to configure automatic response: {e}")
            return False
    
    def get_automatic_response_stats(self) -> Dict[str, Any]:
        """Get automatic response system statistics."""
        return self.automatic_response.get_response_stats()
    
    def regenerate_honeypots(self):
        """Regenerar todos os arquivos honeypot."""
        self.logger.info("Regenerando honeypots...")
        
        # Parar monitoramento temporariamente
        was_running = self.is_running
        if was_running:
            self.stop_protection()
        
        # Limpar honeypots antigos
        self.honeypot_system.cleanup_honeypots()
        
        # Gerar novos honeypots usando sistema unificado
        honeypots = self.honeypot_system.generate_honeypots(
            static_count=self.config['honeypot_count'],
            dynamic_count=50
        )
        
        # Definir honeypot_dir corretamente
        honeypot_dir = self.base_dir / "Honeypots"
        honeypot_registry = honeypot_dir / "honeypot_registry.json"
        self.honeypot_monitor = HoneypotMonitor(
            honeypot_registry_path=str(honeypot_registry),
            base_dir=str(self.base_dir)
        )
        
        # Reiniciar proteção
        if was_running:
            self.start_protection()
        
        self.logger.info(f"Regenerados {len(honeypots)} honeypots")
        return len(honeypots)


def main():
    """Ponto de entrada principal do Sistema Anti-Ransomware."""
    print("=" * 60)
    print("     ESCUDO ANTI-RANSOMWARE - SISTEMA PRINCIPAL")
    print("=" * 60)
    print()
    
    # Verificar privilégios de administrador
    import ctypes
    if not ctypes.windll.shell32.IsUserAnAdmin():
        print("⚠️  AVISO: Não está sendo executado como administrador!")
        print("   Alguns recursos podem não funcionar corretamente.")
        print("   Execute como administrador para proteção completa.\n")
    
    # Initialize core system
    core = AntiRansomwareCore()
    
    # Loop do menu principal
    while True:
        print("\n" + "=" * 40)
        print("MENU PRINCIPAL")
        print("=" * 40)
        
        status = core.get_status()
        print(f"\nStatus: {'🟢 EM EXECUÇÃO' if status['is_running'] else '🔴 PARADO'}")
        print(f"Nível de Proteção: {status['protection_level']}")
        
        if status['uptime']:
            print(f"Tempo em execução: {status['uptime']}")
        
        print(f"\nEstatísticas:")
        print(f"  Ameaças detectadas: {status['statistics']['threats_detected']}")
        print(f"  Processos encerrados: {status['statistics']['processes_killed']}")
        print(f"  Arquivos restaurados: {status['statistics']['files_restored']}")
        
        print("\nOpções:")
        print("1. Iniciar Proteção" if not core.is_running else "1. Parar Proteção")
        print("2. Verificação Manual")
        print("3. Ver Status Detalhado")
        print("4. Regenerar Honeypots")
        print("5. Criar Backup Manual")
        print("6. Encerramento de Emergência de Suspeitos")
        print("7. Configurações")
        print("8. Sair")
        
        choice = input("\nSelecione a opção: ")
        
        if choice == "1":
            if not core.is_running:
                if core.start_protection():
                    print("✅ Proteção iniciada com sucesso")
                else:
                    print("❌ Falha ao iniciar a proteção")
            else:
                if core.stop_protection():
                    print("✅ Proteção parada")
        
        elif choice == "2":
            path = input("Informe o caminho do arquivo ou diretório para verificar: ")
            result = core.perform_manual_scan(path)
            
            if 'error' in result:
                print(f"❌ Erro: {result['error']}")
            elif 'threats_found' in result and isinstance(result['threats_found'], int):
                print(f"\n📁 Verificação do diretório concluída")
                print(f"   Ameaças encontradas: {result['threats_found']}")
            else:
                print(f"\n📄 Arquivo: {result.get('file', 'Desconhecido')}")
                if result.get('threats_found'):
                    print("⚠️  AMEAÇAS DETECTADAS:")
                    for threat in result['threats_found']:
                        print(f"   - {threat.get('description', 'Ameaça desconhecida')}")
                else:
                    print("✅ Nenhuma ameaça encontrada")
        
        elif choice == "3":
            status = core.get_status()
            print("\n" + "=" * 40)
            print("STATUS DETALHADO")
            print("=" * 40)
            print(json.dumps(status, indent=2, ensure_ascii=False))
        
        elif choice == "4":
            count = core.regenerate_honeypots()
            print(f"✅ Regenerados {count} arquivos honeypot")
        
        elif choice == "5":
            shadow_id = core.vss_manager.create_shadow_copy_powershell()
            if shadow_id:
                print(f"✅ Backup criado: {shadow_id}")
            else:
                print("❌ Falha ao criar backup")
        
        elif choice == "6":
            confirm = input("⚠️  Encerrar todos os processos suspeitos de ransomware? (y/n): ")
            if confirm.lower() == 'y':
                results = core.ransomware_killer.emergency_kill_all_suspects()
                print(f"\nResultados:")
                print(f"  Encerrados: {results['terminated']}")
                print(f"  Falhas: {results['failed']}")
        
        elif choice == "7":
            print("\nConfigurações Atuais:")
            for key, value in core.config.items():
                print(f"  {key}: {value}")
            
            print("\nModifique as configurações em: C:\\AntiRansomware\\config.json")
        
        elif choice == "8":
            if core.is_running:
                core.stop_protection()
            print("\n👋 Até logo!")
            break
        
        else:
            print("❌ Opção inválida")


if __name__ == "__main__":
    main()
