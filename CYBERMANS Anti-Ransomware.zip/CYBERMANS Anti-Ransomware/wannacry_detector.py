"""
Specialized WannaCry Ransomware Detector and Neutralizer
Enhanced detection and immediate response for WannaCry and variants
"""

import os
import psutil
import time
import logging
import subprocess
import threading
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import ctypes
import sys

class WannaCryDetector:
    def __init__(self, base_dir=None):
        """Initialize WannaCry detector."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.CRITICAL,  # Only show critical alerts
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'wannacry_detector_{datetime.now().strftime("%Y%m%d")}.log', encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("WannaCryDetector")
        
        # WannaCry specific indicators
        self.wannacry_indicators = {
            'process_names': [
                'wannacry', 'wcry', 'ms17-010', 'eternalblue', 'doublepulsar',
                'notpetya', 'petya', 'wannacrypt', 'wannacrypt0r', 'wannacrypt0r 2.0'
            ],
            'file_extensions': [
                '.wcry', '.wannacry', '.locked', '.encrypted', '.crypto',
                '.enc', '.lock', '.cerber', '.locky', '.zepto', '.odin'
            ],
            'suspicious_strings': [
                'WannaCry', 'WannaCrypt', 'WannaCrypt0r', 'WannaCrypt0r 2.0',
                'WannaCry Ransomware', 'WannaCry 2.0', 'WannaCry 3.0',
                'WannaCry 4.0', 'WannaCry 5.0', 'WannaCry 6.0'
            ],
            'network_indicators': [
                'killswitch', 'kill switch', 'wannacry killswitch',
                'wannacry kill switch', 'wannacry killswitch domain'
            ]
        }
        
        self.detection_active = False
        self.detected_threats = []
        
    def start_monitoring(self):
        """Start continuous WannaCry monitoring."""
        self.detection_active = True
        self.logger.critical("[ALERT] WANNACRY DETECTOR ACTIVATED - MONITORING FOR THREATS")
        
        # Start monitoring thread
        monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        monitor_thread.start()
        
    def stop_monitoring(self):
        """Stop WannaCry monitoring."""
        self.detection_active = False
        self.logger.info("WannaCry detector stopped")
        
    def _monitor_loop(self):
        """Main monitoring loop for WannaCry detection."""
        while self.detection_active:
            try:
                # Check for WannaCry processes
                wannacry_processes = self._detect_wannacry_processes()
                if wannacry_processes:
                    self.logger.critical(f"[ALERT] WANNACRY DETECTED: {len(wannacry_processes)} processes")
                    for proc in wannacry_processes:
                        self._immediate_neutralization(proc)
                
                # Check for WannaCry files
                wannacry_files = self._detect_wannacry_files()
                if wannacry_files:
                    self.logger.critical(f"[ALERT] WANNACRY FILES DETECTED: {len(wannacry_files)} files")
                    self._delete_wannacry_files(wannacry_files)
                
                # Check for network indicators
                network_threats = self._detect_network_indicators()
                if network_threats:
                    self.logger.critical(f"[ALERT] WANNACRY NETWORK ACTIVITY: {network_threats}")
                    self._block_network_activity()
                
                time.sleep(0.5)  # Check every 500ms for maximum speed
                
            except Exception as e:
                self.logger.error(f"Error in WannaCry monitoring: {e}")
                time.sleep(1)
    
    def _detect_wannacry_processes(self) -> List[Dict]:
        """Detect WannaCry processes."""
        wannacry_processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
            try:
                proc_info = proc.info
                proc_name = proc_info['name'].lower() if proc_info['name'] else ''
                
                # Check process name
                for indicator in self.wannacry_indicators['process_names']:
                    if indicator.lower() in proc_name:
                        wannacry_processes.append({
                            'pid': proc_info['pid'],
                            'name': proc_info['name'],
                            'exe': proc_info['exe'],
                            'cmdline': proc_info['cmdline'],
                            'threat_level': 'CRITICAL',
                            'detection_method': 'process_name'
                        })
                        break
                
                # Check command line arguments
                if proc_info['cmdline']:
                    cmdline = ' '.join(proc_info['cmdline']).lower()
                    for indicator in self.wannacry_indicators['suspicious_strings']:
                        if indicator.lower() in cmdline:
                            wannacry_processes.append({
                                'pid': proc_info['pid'],
                                'name': proc_info['name'],
                                'exe': proc_info['exe'],
                                'cmdline': proc_info['cmdline'],
                                'threat_level': 'CRITICAL',
                                'detection_method': 'command_line'
                            })
                            break
                            
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
                
        return wannacry_processes
    
    def _detect_wannacry_files(self) -> List[str]:
        """Detect WannaCry files in common directories."""
        wannacry_files = []
        
        # Common user directories
        search_dirs = [
            Path.home() / "Desktop",
            Path.home() / "Documents",
            Path.home() / "Downloads",
            Path.home() / "Pictures",
            Path.home() / "Videos",
            Path.home() / "Music"
        ]
        
        for search_dir in search_dirs:
            if search_dir.exists():
                try:
                    for file_path in search_dir.rglob('*'):
                        if file_path.is_file():
                            file_name = file_path.name.lower()
                            
                            # Check file extensions
                            for ext in self.wannacry_indicators['file_extensions']:
                                if file_name.endswith(ext.lower()):
                                    wannacry_files.append(str(file_path))
                                    break
                            
                            # Check file names for WannaCry indicators
                            for indicator in self.wannacry_indicators['suspicious_strings']:
                                if indicator.lower() in file_name:
                                    wannacry_files.append(str(file_path))
                                    break
                                    
                except (PermissionError, OSError):
                    continue
                    
        return wannacry_files
    
    def _detect_network_indicators(self) -> List[str]:
        """Detect WannaCry network indicators."""
        network_threats = []
        
        try:
            # Check for suspicious network connections
            for conn in psutil.net_connections():
                if conn.status == 'ESTABLISHED':
                    # Check for suspicious ports (WannaCry uses specific ports)
                    if conn.laddr.port in [445, 139, 135, 3389, 22, 23, 21]:
                        network_threats.append(f"Suspicious port {conn.laddr.port}")
                        
        except Exception as e:
            self.logger.error(f"Error checking network indicators: {e}")
            
        return network_threats
    
    def _immediate_neutralization(self, process_info: Dict):
        """Immediately neutralize WannaCry process."""
        try:
            pid = process_info['pid']
            name = process_info['name']
            
            self.logger.critical(f"[KILL] IMMEDIATE NEUTRALIZATION: {name} (PID: {pid})")
            
            # Force kill the process
            proc = psutil.Process(pid)
            proc.kill()
            
            # Wait for termination
            try:
                proc.wait(timeout=2)
                self.logger.critical(f"[SUCCESS] WANNACRY ELIMINATED: {name}")
                
                # Log the neutralization
                self.detected_threats.append({
                    'timestamp': datetime.now().isoformat(),
                    'type': 'wannacry_process',
                    'pid': pid,
                    'name': name,
                    'action': 'terminated',
                    'success': True
                })
                
            except psutil.TimeoutExpired:
                self.logger.critical(f"[WARNING] WANNACRY RESISTANT: {name} - attempting force kill")
                # Try again with more force
                try:
                    proc.kill()
                    proc.wait(timeout=1)
                    self.logger.critical(f"[SUCCESS] WANNACRY FORCE ELIMINATED: {name}")
                except:
                    self.logger.critical(f"[ERROR] WANNACRY PERSISTENT: {name} - may require system restart")
                    
        except psutil.NoSuchProcess:
            self.logger.critical(f"[SUCCESS] WANNACRY ALREADY TERMINATED: {process_info['name']}")
        except Exception as e:
            self.logger.error(f"[ERROR] Failed to neutralize WannaCry: {e}")
    
    def _delete_wannacry_files(self, file_paths: List[str]):
        """Delete detected WannaCry files."""
        deleted_count = 0
        
        # Get application directory for protection
        app_dir = self.base_dir.resolve() if self.base_dir else Path(__file__).parent.resolve()
        
        for file_path in file_paths:
            try:
                file_path_obj = Path(file_path)
                
                # PROTECTION: Skip application files
                if self._is_application_file(file_path_obj, app_dir):
                    self.logger.info(f"[PROTECTED] APPLICATION FILE: {file_path}")
                    continue
                
                # Create backup before deletion
                backup_dir = self.base_dir / "Deleted_WannaCry_Files"
                backup_dir.mkdir(parents=True, exist_ok=True)
                
                backup_path = backup_dir / f"{file_path_obj.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
                # Copy to backup
                import shutil
                shutil.copy2(file_path, backup_path)
                
                # Delete the file
                file_path_obj.unlink()
                deleted_count += 1
                
                self.logger.critical(f"[DELETE] DELETED WANNACRY FILE: {file_path}")
                
            except Exception as e:
                self.logger.error(f"[ERROR] Failed to delete WannaCry file {file_path}: {e}")
        
        if deleted_count > 0:
            self.logger.critical(f"[ELIMINATED] ELIMINATED {deleted_count} WANNACRY FILES")
    
    def _is_application_file(self, file_path: Path, app_dir: Path) -> bool:
        """Check if file belongs to the application and should be protected."""
        try:
            # Check if file is in application directory
            if app_dir in file_path.parents or file_path.parent == app_dir:
                return True
            
            # Check for application-specific file names
            app_files = [
                'wannacry_detector.py',
                'antiransomware.py', 
                'GUI_PART_2.py',
                'launcher.py',
                'ransomware_killer.py',
                'honeypot_monitor.py',
                'automatic_threat_response.py',
                'yara_scanner.py',
                'enhanced_signature_detector.py',
                'static_heuristic_analyzer.py',
                'dynamic_heuristic_analyzer.py',
                'unified_threat_analyzer.py',
                'vss_manager.py',
                'windows_compatibility_manager.py',
                'config.json',
                'requirements.txt',
                'setup.py',
                'build_executable.py',
                'installer.py'
            ]
            
            if file_path.name in app_files:
                return True
            
            # Check for application-specific directories
            app_dirs = [
                'Config',
                'Logs', 
                'Backups',
                'Quarantine',
                'Incidents',
                'Honeypots',
                'rules',
                'yara'
            ]
            
            for app_dir_name in app_dirs:
                if app_dir_name in file_path.parts:
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking application file: {e}")
            return False
    
    def _block_network_activity(self):
        """Block suspicious network activity."""
        try:
            # This would integrate with Windows Firewall
            self.logger.critical("[NETWORK] BLOCKING WANNACRY NETWORK ACTIVITY")
            # Future enhancement: Implement actual network blocking
        except Exception as e:
            self.logger.error(f"Error blocking network activity: {e}")
    
    def get_detection_stats(self) -> Dict:
        """Get detection statistics."""
        return {
            'threats_detected': len(self.detected_threats),
            'monitoring_active': self.detection_active,
            'last_detection': self.detected_threats[-1] if self.detected_threats else None
        }

if __name__ == "__main__":
    # Test the WannaCry detector
    detector = WannaCryDetector()
    detector.start_monitoring()
    
    print("🚨 WannaCry Detector Started - Monitoring for threats...")
    print("Press Ctrl+C to stop")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        detector.stop_monitoring()
        print("WannaCry detector stopped")
