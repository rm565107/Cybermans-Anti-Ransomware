#!/usr/bin/env python3
"""
CYBERMANS Anti-Ransomware Installer
Complete installation and setup script
"""

import os
import sys
import subprocess
import ctypes
import json
import shutil
import time
from pathlib import Path
from typing import List, Dict, Any, Optional

class AntiRansomwareInstaller:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.install_dir = Path.home() / "AppData" / "Local" / "CYBERMANS_AntiRansomware"
        self.desktop = Path.home() / "Desktop"
        self.start_menu = Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        self.python_exe = sys.executable
        self.is_admin = self._is_admin()
        
    def _is_admin(self) -> bool:
        """Check if running with administrator privileges."""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    
    def _run_as_admin(self) -> bool:
        """Restart the installer with administrator privileges."""
        try:
            script_path = os.path.abspath(__file__)
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", self.python_exe, f'"{script_path}"', None, 1
            )
            return True
        except Exception as e:
            print(f"❌ Failed to restart as administrator: {e}")
            return False
    
    def _check_python_version(self) -> bool:
        """Check if Python version is compatible."""
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 8):
            print(f"❌ Python 3.8+ necessário. Versão atual: {version.major}.{version.minor}")
            return False
        print(f"✅ Versão do Python: {version.major}.{version.minor}.{version.micro}")
        return True
    
    def _install_python_dependencies(self) -> bool:
        """Install Python dependencies."""
        print("📦 Instalando dependências do Python...")
        
        try:
            # Upgrade pip
            subprocess.run([
                self.python_exe, "-m", "pip", "install", "--upgrade", "pip"
            ], check=True, capture_output=True)
            
            # Install requirements
            requirements_file = self.base_dir / "requirements.txt"
            if requirements_file.exists():
                result = subprocess.run([
                    self.python_exe, "-m", "pip", "install", "-r", str(requirements_file)
                ], capture_output=True, text=True)
                
                if result.returncode == 0:
                    print("✅ Dependências do Python instaladas com sucesso")
                    return True
                else:
                    print(f"❌ Falha ao instalar dependências do Python:")
                    print(result.stderr)
                    return False
            else:
                print("❌ requirements.txt não encontrado!")
                return False
                
        except Exception as e:
            print(f"❌ Erro ao instalar dependências do Python: {e}")
            return False
    
    def _copy_application_files(self) -> bool:
        """Copy application files to installation directory."""
        print("📁 Copiando arquivos da aplicação...")
        
        try:
            # Create installation directory
            self.install_dir.mkdir(parents=True, exist_ok=True)
            
            # Files to copy
            files_to_copy = [
                "antiransomware.py",
                "GUI_PART_2.py", 
                "automatic_threat_response.py",
                "dynamic_heuristic_analyzer.py",
                "enhanced_signature_detector.py",
                "honeypot_gerador.py",
                "honeypot_monitor.py",
                "ransomware_killer.py",
                "static_heuristic_analyzer.py",
                "unified_threat_analyzer.py",
                "vss_manager.py",
                "wannacry_detector.py",
                "windows_compatibility_manager.py",
                "yara_scanner.py",
                "launcher.py",
                "requirements.txt"
            ]
            
            # Copy main files
            for file_name in files_to_copy:
                src_file = self.base_dir / file_name
                if src_file.exists():
                    dst_file = self.install_dir / file_name
                    shutil.copy2(src_file, dst_file)
                    print(f"  ✅ Copiado {file_name}")
            
            # Copy rules directory
            rules_src = self.base_dir / "rules"
            rules_dst = self.install_dir / "rules"
            if rules_src.exists():
                if rules_dst.exists():
                    shutil.rmtree(rules_dst)
                shutil.copytree(rules_src, rules_dst)
                print("  ✅ Copiado diretório rules")
            
            # Copy yara directory
            yara_src = self.base_dir / "yara"
            yara_dst = self.install_dir / "yara"
            if yara_src.exists():
                if yara_dst.exists():
                    shutil.rmtree(yara_dst)
                shutil.copytree(yara_src, yara_dst)
                print("  ✅ Copiado diretório yara")
            
            print("✅ Arquivos da aplicação copiados com sucesso")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao copiar arquivos da aplicação: {e}")
            return False
    
    def _create_directories(self) -> bool:
        """Create necessary directories."""
        print("📁 Criando diretórios da aplicação...")
        
        try:
            directories = [
                "Logs", "Honeypots", "Backups", "Incidents", 
                "Quarantine", "Config", "Temp"
            ]
            
            for directory in directories:
                dir_path = self.install_dir / directory
                dir_path.mkdir(exist_ok=True)
                print(f"  ✅ Criado diretório {directory}")
            
            return True
        except Exception as e:
            print(f"❌ Erro ao criar diretórios: {e}")
            return False
    
    def _create_configuration(self) -> bool:
        """Create default configuration."""
        print("⚙️ Criando arquivos de configuração...")
        
        try:
            # Main configuration
            config = {
                "honeypot_count": 30,
                "scan_interval": 10,
                "backup_interval": 3600,
                "auto_kill_threshold": 70,
                "auto_restore": True,
                "alert_sound": True,
                "vss_snapshots_to_keep": 5,
                "protection_level": "NORMAL",
                "installation_path": str(self.install_dir),
                "version": "1.0.0"
            }
            
            config_file = self.install_dir / "config.json"
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print("  ✅ Criada configuração principal")
            
            # Create launcher batch file
            launcher_bat = self.install_dir / "launcher.bat"
            with open(launcher_bat, 'w') as f:
                f.write(f'''@echo off
title CYBERMANS Anti-Ransomware
cd /d "{self.install_dir}"
python launcher.py
pause''')
            
            print("  ✅ Criado arquivo batch do launcher")
            
            return True
        except Exception as e:
            print(f"❌ Erro ao criar configuração: {e}")
            return False
    
    def _create_shortcuts(self) -> bool:
        """Create desktop and start menu shortcuts."""
        print("🔗 Criando atalhos...")
        
        try:
            # Desktop shortcut
            desktop_shortcut = self.desktop / "CYBERMANS Anti-Ransomware.lnk"
            self._create_shortcut(
                str(desktop_shortcut),
                str(self.install_dir / "launcher.bat"),
                str(self.install_dir),
                "CYBERMANS Anti-Ransomware"
            )
            print("  ✅ Criado atalho da área de trabalho")
            
            # Start menu shortcut
            start_menu_shortcut = self.start_menu / "CYBERMANS Anti-Ransomware.lnk"
            self._create_shortcut(
                str(start_menu_shortcut),
                str(self.install_dir / "launcher.bat"),
                str(self.install_dir),
                "CYBERMANS Anti-Ransomware"
            )
            print("  ✅ Criado atalho do menu iniciar")
            
            return True
        except Exception as e:
            print(f"❌ Erro ao criar atalhos: {e}")
            return False
    
    def _create_shortcut(self, shortcut_path: str, target_path: str, working_dir: str, description: str):
        """Create a Windows shortcut."""
        try:
            import winshell
            from win32com.client import Dispatch
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = target_path
            shortcut.WorkingDirectory = working_dir
            shortcut.Description = description
            shortcut.save()
        except ImportError:
            # Fallback method without winshell
            pass
    
    def _create_uninstaller(self) -> bool:
        """Create an uninstaller script."""
        print("🗑️ Criando desinstalador...")
        
        try:
            uninstaller_content = f'''@echo off
title CYBERMANS Anti-Ransomware Uninstaller

echo ============================================================
echo     CYBERMANS ANTI-RANSOMWARE UNINSTALLER
echo ============================================================
echo.

echo [WARNING] This will remove CYBERMANS Anti-Ransomware and all its data.
set /p confirm="Are you sure you want to continue? (y/n): "
if /i not "%confirm%"=="y" (
    echo Uninstall cancelled.
    pause
    exit /b 0
)

echo.
echo [INFO] Removing application files...
rmdir /s /q "{self.install_dir}"

echo [INFO] Removing shortcuts...
del "{self.desktop}\\CYBERMANS Anti-Ransomware.lnk" 2>nul
del "{self.start_menu}\\CYBERMANS Anti-Ransomware.lnk" 2>nul

echo.
echo [INFO] Uninstallation complete.
pause'''

            uninstaller_file = self.install_dir / "uninstall.bat"
            with open(uninstaller_file, 'w') as f:
                f.write(uninstaller_content)
            
            print("  ✅ Criado desinstalador")
            return True
        except Exception as e:
            print(f"❌ Erro ao criar desinstalador: {e}")
            return False
    
    def _test_installation(self) -> bool:
        """Test the installation."""
        print("🧪 Testando instalação...")
        
        try:
            # Test if main files exist
            main_files = [
                "launcher.py", "GUI_PART_2.py", "antiransomware.py"
            ]
            
            for file_name in main_files:
                file_path = self.install_dir / file_name
                if not file_path.exists():
                    print(f"❌ Arquivo ausente: {file_name}")
                    return False
            
            # Test if directories exist
            required_dirs = ["Logs", "Honeypots", "Backups", "Config"]
            for dir_name in required_dirs:
                dir_path = self.install_dir / dir_name
                if not dir_path.exists():
                    print(f"❌ Diretório ausente: {dir_name}")
                    return False
            
            print("✅ Teste de instalação aprovado")
            return True
        except Exception as e:
            print(f"❌ Teste de instalação falhou: {e}")
            return False
    
    def install(self) -> bool:
        """Main installation function."""
        print("=" * 60)
        print("    INSTALADOR CYBERMANS ANTI-RANSOMWARE")
        print("=" * 60)
        print()
        
        # Check administrator privileges
        if not self.is_admin:
            print("⚠️ Não está executando como administrador!")
            print("Reiniciando com privilégios de administrador...")
            print()
            
            if not self._run_as_admin():
                print("❌ Falha ao reiniciar como administrador")
                print("Execute este instalador como administrador manualmente")
                input("Pressione Enter para sair...")
                return False
            
            sys.exit(0)
        
        print("✅ Executando com privilégios de administrador")
        print()
        
        # Check Python version
        if not self._check_python_version():
            input("Pressione Enter para sair...")
            return False
        
        # Install Python dependencies
        if not self._install_python_dependencies():
            print("❌ Falha ao instalar dependências do Python")
            input("Pressione Enter para sair...")
            return False
        
        # Copy application files
        if not self._copy_application_files():
            print("❌ Falha ao copiar arquivos da aplicação")
            input("Pressione Enter para sair...")
            return False
        
        # Create directories
        if not self._create_directories():
            print("❌ Failed to create directories")
            input("Press Enter to exit...")
            return False
        
        # Create configuration
        if not self._create_configuration():
            print("❌ Failed to create configuration")
            input("Press Enter to exit...")
            return False
        
        # Create shortcuts
        if not self._create_shortcuts():
            print("❌ Failed to create shortcuts")
            input("Press Enter to exit...")
            return False
        
        # Create uninstaller
        if not self._create_uninstaller():
            print("❌ Failed to create uninstaller")
            input("Press Enter to exit...")
            return False
        
        # Test installation
        if not self._test_installation():
            print("❌ Teste de instalação falhou")
            input("Pressione Enter para sair...")
            return False
        
        print()
        print("=" * 60)
        print("    INSTALAÇÃO CONCLUÍDA!")
        print("=" * 60)
        print()
        print("✅ CYBERMANS Anti-Ransomware foi instalado com sucesso!")
        print()
        print("📁 Local da instalação:")
        print(f"   {self.install_dir}")
        print()
        print("🔗 Atalhos criados:")
        print(f"   Área de Trabalho: {self.desktop / 'CYBERMANS Anti-Ransomware.lnk'}")
        print(f"   Menu Iniciar: {self.start_menu / 'CYBERMANS Anti-Ransomware.lnk'}")
        print()
        print("🚀 Você pode agora executar a aplicação pelo atalho da área de trabalho")
        print("   ou clicando duas vezes em launcher.bat na pasta de instalação")
        print()
        
        # Ask if user wants to launch the application
        launch = input("Gostaria de iniciar a aplicação agora? (s/n): ")
        if launch.lower() == 's':
            print("🚀 Iniciando CYBERMANS Anti-Ransomware...")
            try:
                os.chdir(self.install_dir)
                subprocess.Popen([self.python_exe, "launcher.py"])
            except Exception as e:
                print(f"❌ Falha ao iniciar aplicação: {e}")
        
        return True

def main():
    """Main entry point."""
    installer = AntiRansomwareInstaller()
    
    try:
        success = installer.install()
        if not success:
            print("❌ Instalação falhou")
        input("Pressione Enter para sair...")
    except KeyboardInterrupt:
        print("\n👋 Instalação interrompida pelo usuário")
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()
