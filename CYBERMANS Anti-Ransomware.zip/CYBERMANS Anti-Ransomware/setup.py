#!/usr/bin/env python3
"""
CYBERMANS Anti-Ransomware Setup Script
Complete setup and build automation
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def main():
    print("=" * 60)
    print("    CONFIGURAÇÃO CYBERMANS ANTI-RANSOMWARE")
    print("=" * 60)
    print()
    
    print("Escolha a opção de configuração:")
    print("1. Início Rápido (Executar do diretório atual)")
    print("2. Instalação Completa (Instalar no sistema)")
    print("3. Criar Executável (Criar .exe independente)")
    print("4. Sair")
    print()
    
    choice = input("Digite sua escolha (1-4): ").strip()
    
    if choice == "1":
        print("\n🚀 Configuração de Início Rápido")
        print("=" * 30)
        print("Isso executará a aplicação do diretório atual")
        print("As dependências serão instaladas automaticamente")
        print()
        
        # Check if running as admin
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if not is_admin:
                print("⚠️ Não está executando como administrador!")
                print("Reiniciando com privilégios de administrador...")
                ctypes.windll.shell32.ShellExecuteW(
                    None, "runas", sys.executable, f'"{__file__}"', None, 1
                )
                sys.exit(0)
        except:
            print("⚠️ Não foi possível verificar privilégios de administrador")
        
        print("✅ Executando com privilégios de administrador")
        print("🚀 Iniciando CYBERMANS Anti-Ransomware...")
        
        # Run the launcher
        try:
            from launcher import main as launcher_main
            launcher_main()
        except ImportError:
            print("❌ launcher.py não encontrado!")
            print("Certifique-se de que todos os arquivos estão no mesmo diretório")
            input("Pressione Enter para sair...")
    
    elif choice == "2":
        print("\n📦 Configuração de Instalação Completa")
        print("=" * 30)
        print("Isso instalará a aplicação no seu sistema")
        print("e criará atalhos na área de trabalho")
        print()
        
        try:
            from installer import main as installer_main
            installer_main()
        except ImportError:
            print("❌ installer.py não encontrado!")
            print("Certifique-se de que todos os arquivos estão no mesmo diretório")
            input("Pressione Enter para sair...")
    
    elif choice == "3":
        print("\n🔨 Construtor de Executável")
        print("=" * 30)
        print("Isso criará um executável independente")
        print("que pode ser distribuído sem Python")
        print()
        
        try:
            from build_executable import main as builder_main
            builder_main()
        except ImportError:
            print("❌ build_executable.py não encontrado!")
            print("Certifique-se de que todos os arquivos estão no mesmo diretório")
            input("Pressione Enter para sair...")
    
    elif choice == "4":
        print("\n👋 Até logo!")
        sys.exit(0)
    
    else:
        print("\n❌ Escolha inválida!")
        print("Execute o script novamente e escolha 1-4")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()
