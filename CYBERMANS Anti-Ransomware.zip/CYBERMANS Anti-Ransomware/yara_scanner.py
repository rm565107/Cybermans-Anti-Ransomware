"""
Python-based YARA Scanner for Anti-Ransomware Shield
Scans files using YARA rules to detect ransomware patterns
"""

import os
import sys
import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

# Try to import yara-python, provide fallback if not available
try:
    import yara
    YARA_AVAILABLE = True
except ImportError:
    YARA_AVAILABLE = False
    print("Warning: yara-python not installed. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "yara-python"])
    try:
        import yara
        YARA_AVAILABLE = True
    except:
        print("Failed to install yara-python. Some features will be limited.")

class YaraScanner:
    def __init__(self, rules_dir="rules"):
        """Initialize the YARA scanner with rules directory."""
        self.rules_dir = Path(rules_dir)
        self.compiled_rules = None
        self.scan_history = []
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger("YaraScanner")
        
        # Load YARA rules
        if YARA_AVAILABLE:
            self.load_rules()
        else:
            self.logger.warning("YARA not available, using fallback detection")
    
    def load_rules(self):
        """Load and compile all YARA rules from the rules directory."""
        if not YARA_AVAILABLE:
            return False
        
        if not self.rules_dir.exists():
            self.logger.error(f"Rules directory not found: {self.rules_dir}")
            return False
        
        # Collect all .yar files
        rule_files = list(self.rules_dir.glob("RANSOM_*.yar"))
        
        if not rule_files:
            self.logger.warning("No ransomware rules found")
            return False
        
        # Compile rules
        try:
            rules_dict = {}
            for rule_file in rule_files:
                namespace = rule_file.stem
                try:
                    rules_dict[namespace] = str(rule_file)
                    self.logger.info(f"Loaded rule: {namespace}")
                except Exception as e:
                    self.logger.error(f"Failed to load rule {rule_file}: {e}")
            
            if rules_dict:
                self.compiled_rules = yara.compile(filepaths=rules_dict)
                self.logger.info(f"Successfully compiled {len(rules_dict)} YARA rules")
                return True
        except Exception as e:
            self.logger.error(f"Failed to compile YARA rules: {e}")
            return False
        
        return False
    
    def scan_file(self, filepath: str) -> Dict[str, Any]:
        """Scan a single file for ransomware patterns."""
        result = {
            'file': filepath,
            'timestamp': datetime.now().isoformat(),
            'threats_found': [],
            'is_encrypted': False,
            'entropy': 0.0,
            'hash': None,
            'suspicious_extension': False
        }
        
        file_path = Path(filepath)
        
        if not file_path.exists():
            result['error'] = 'File not found'
            return result
        
        # Check file hash
        try:
            with open(file_path, 'rb') as f:
                result['hash'] = hashlib.sha256(f.read()).hexdigest()
        except Exception as e:
            result['error'] = f'Cannot read file: {e}'
            return result
        
        # Check for suspicious extensions (common ransomware extensions)
        suspicious_extensions = [
            '.locked', '.encrypted', '.crypto', '.enc', '.lock',
            '.cerber', '.locky', '.zepto', '.odin', '.shit', '.thor',
            '.zzzzz', '.micro', '.encrypted', '.cryptolocker', '.vault',
            '.petya', '.gwdata', '.cerber3', '.cerber2', '.crypt',
            '.WNCRY', '.WCRY', '.wncrypt', '.wncryt'
        ]
        
        if any(str(file_path).endswith(ext) for ext in suspicious_extensions):
            result['suspicious_extension'] = True
            result['threats_found'].append({
                'type': 'suspicious_extension',
                'description': f'File has ransomware-associated extension: {file_path.suffix}',
                'severity': 'HIGH'
            })
        
        # Calculate file entropy (high entropy indicates encryption)
        entropy = self.calculate_entropy(file_path)
        result['entropy'] = entropy
        
        if entropy > 7.5:  # Threshold for encrypted files
            result['is_encrypted'] = True
            result['threats_found'].append({
                'type': 'high_entropy',
                'description': f'File appears to be encrypted (entropy: {entropy:.2f})',
                'severity': 'HIGH'
            })
        
        # YARA scanning
        if YARA_AVAILABLE and self.compiled_rules:
            try:
                matches = self.compiled_rules.match(filepath=str(file_path))
                
                for match in matches:
                    threat = {
                        'type': 'yara_match',
                        'rule': match.rule,
                        'namespace': match.namespace,
                        'tags': match.tags,
                        'severity': 'CRITICAL',
                        'description': f'Matched ransomware signature: {match.rule}'
                    }
                    
                    # Extract metadata from rule
                    if hasattr(match, 'meta'):
                        threat['metadata'] = match.meta
                    
                    result['threats_found'].append(threat)
                    
            except Exception as e:
                self.logger.error(f"YARA scan error for {filepath}: {e}")
                result['scan_error'] = str(e)
        
        # Pattern-based detection (fallback when YARA is not available)
        threats = self.detect_ransomware_patterns(file_path)
        result['threats_found'].extend(threats)
        
        # Save to history
        self.scan_history.append(result)
        
        return result
    
    def calculate_entropy(self, filepath: Path) -> float:
        """Calculate Shannon entropy of a file."""
        try:
            with open(filepath, 'rb') as f:
                data = f.read(8192)  # Read first 8KB for performance
                
            if not data:
                return 0.0
            
            # Calculate frequency of each byte
            frequency = {}
            for byte in data:
                frequency[byte] = frequency.get(byte, 0) + 1
            
            # Calculate entropy
            entropy = 0.0
            data_len = len(data)
            
            for count in frequency.values():
                if count > 0:
                    probability = count / data_len
                    import math
                    entropy -= probability * math.log2(probability)
            
            return entropy
            
        except Exception as e:
            self.logger.error(f"Error calculating entropy for {filepath}: {e}")
            return 0.0
    
    def detect_ransomware_patterns(self, filepath: Path) -> List[Dict]:
        """Detect ransomware patterns without YARA."""
        threats = []
        
        try:
            # Read file content (limited to prevent memory issues)
            with open(filepath, 'rb') as f:
                content = f.read(1024 * 1024)  # Read first 1MB
            
            # Check for ransomware note patterns
            ransom_note_patterns = [
                b'Your files have been encrypted',
                b'Your files are encrypted',
                b'All your files have been encrypted',
                b'pay the ransom',
                b'bitcoin address',
                b'BTC wallet',
                b'decrypt your files',
                b'decryption key',
                b'HOW TO DECRYPT FILES',
                b'ATTENTION!',
                b'YOUR PERSONAL ID',
                b'tor browser',
                b'.onion',
                b'RECOVER YOUR FILES'
            ]
            
            for pattern in ransom_note_patterns:
                if pattern.lower() in content.lower():
                    threats.append({
                        'type': 'pattern_match',
                        'pattern': pattern.decode('utf-8', errors='ignore'),
                        'description': 'Found ransomware note pattern',
                        'severity': 'HIGH'
                    })
                    break
            
            # Check for known ransomware signatures
            ransomware_signatures = [
                b'WanaCrypt0r',
                b'WannaCry',
                b'WNCRY',
                b'Locky',
                b'Cerber',
                b'Petya',
                b'GoldenEye',
                b'BadRabbit',
                b'TeslaCrypt',
                b'CryptoLocker'
            ]
            
            for signature in ransomware_signatures:
                if signature in content:
                    threats.append({
                        'type': 'signature_match',
                        'signature': signature.decode('utf-8', errors='ignore'),
                        'description': f'Found {signature.decode("utf-8", errors="ignore")} ransomware signature',
                        'severity': 'CRITICAL'
                    })
            
        except Exception as e:
            self.logger.error(f"Error in pattern detection for {filepath}: {e}")
        
        return threats
    
    def scan_directory(self, directory: str, recursive: bool = True) -> List[Dict]:
        """Scan all files in a directory."""
        results = []
        dir_path = Path(directory)
        
        if not dir_path.exists():
            self.logger.error(f"Directory not found: {directory}")
            return results
        
        # Get all files
        if recursive:
            files = list(dir_path.rglob('*'))
        else:
            files = list(dir_path.glob('*'))
        
        # Filter to actual files only
        files = [f for f in files if f.is_file()]
        
        self.logger.info(f"Scanning {len(files)} files in {directory}")
        
        for file_path in files:
            try:
                result = self.scan_file(str(file_path))
                if result.get('threats_found'):
                    results.append(result)
                    self.logger.warning(f"Threat found in {file_path}")
            except Exception as e:
                self.logger.error(f"Error scanning {file_path}: {e}")
        
        return results
    
    def quick_scan(self, filepath: str) -> bool:
        """Quick scan to check if file is likely ransomware or encrypted."""
        file_path = Path(filepath)
        
        # Quick checks
        if any(str(file_path).endswith(ext) for ext in ['.locked', '.encrypted', '.crypto']):
            return True
        
        # Quick entropy check
        entropy = self.calculate_entropy(file_path)
        if entropy > 7.8:
            return True
        
        return False
    
    def get_scan_summary(self) -> Dict:
        """Get summary of all scans performed."""
        total_scans = len(self.scan_history)
        threats_found = sum(1 for scan in self.scan_history if scan.get('threats_found'))
        encrypted_files = sum(1 for scan in self.scan_history if scan.get('is_encrypted'))
        
        return {
            'total_scans': total_scans,
            'threats_found': threats_found,
            'encrypted_files': encrypted_files,
            'last_scan': self.scan_history[-1] if self.scan_history else None
        }


def main():
    """Test the YARA scanner."""
    print("=== Anti-Ransomware YARA Scanner ===\n")
    
    scanner = YaraScanner()
    
    while True:
        print("\n1. Scan File")
        print("2. Scan Directory")
        print("3. Quick Scan")
        print("4. Show Summary")
        print("5. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            filepath = input("Enter file path: ")
            result = scanner.scan_file(filepath)
            
            print(f"\n=== Scan Results ===")
            print(f"File: {result['file']}")
            print(f"Entropy: {result['entropy']:.2f}")
            print(f"Encrypted: {result['is_encrypted']}")
            
            if result['threats_found']:
                print(f"\n⚠️ THREATS FOUND:")
                for threat in result['threats_found']:
                    print(f"  - {threat['description']} [{threat['severity']}]")
            else:
                print("✓ No threats found")
        
        elif choice == "2":
            directory = input("Enter directory path: ")
            results = scanner.scan_directory(directory)
            
            print(f"\n=== Directory Scan Results ===")
            print(f"Threats found in {len(results)} files")
            
            for result in results[:5]:  # Show first 5
                print(f"\n{result['file']}:")
                for threat in result['threats_found']:
                    print(f"  - {threat['description']}")
        
        elif choice == "3":
            filepath = input("Enter file path for quick scan: ")
            is_threat = scanner.quick_scan(filepath)
            print(f"\nQuick scan result: {'⚠️ THREAT DETECTED' if is_threat else '✓ SAFE'}")
        
        elif choice == "4":
            summary = scanner.get_scan_summary()
            print(f"\n=== Scan Summary ===")
            print(f"Total scans: {summary['total_scans']}")
            print(f"Threats found: {summary['threats_found']}")
            print(f"Encrypted files: {summary['encrypted_files']}")
        
        elif choice == "5":
            break


if __name__ == "__main__":
    main()
