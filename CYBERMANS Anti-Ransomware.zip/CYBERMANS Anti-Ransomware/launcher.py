#!/usr/bin/env python3
"""
CYBERMANS Anti-Ransomware Launcher
Automatically installs dependencies and runs with administrator privileges
"""

import os
import sys
import subprocess
import ctypes
import json
import time
import shutil
from pathlib import Path
from typing import List, Dict, Any

class AntiRansomwareLauncher:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.requirements_file = self.base_dir / "requirements.txt"
        self.python_exe = sys.executable
        self.is_admin = self._is_admin()
        
    def _is_admin(self) -> bool:
        """Check if running with administrator privileges."""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    
    def _run_as_admin(self) -> bool:
        """Restart the script with administrator privileges."""
        try:
            # Get the current script path
            script_path = os.path.abspath(__file__)
            
            # Use ShellExecute to run as admin
            ctypes.windll.shell32.ShellExecuteW(
                None, 
                "runas", 
                self.python_exe, 
                f'"{script_path}"', 
                None, 
                1
            )
            return True
        except Exception as e:
            print(f"❌ Failed to restart as administrator: {e}")
            return False
    
    def _check_python_version(self) -> bool:
        """Check if Python version is compatible."""
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 8):
            print(f"❌ Python 3.8+ necessário. Versão atual: {version.major}.{version.minor}")
            return False
        print(f"✅ Versão do Python: {version.major}.{version.minor}.{version.micro}")
        return True
    
    def _install_requirements(self) -> bool:
        """Install requirements from requirements.txt."""
        if not self.requirements_file.exists():
            print("❌ requirements.txt não encontrado!")
            return False
        
        print("📦 Instalando dependências...")
        print("Isso pode levar alguns minutos na primeira execução...")
        
        try:
            # Upgrade pip first
            subprocess.run([
                self.python_exe, "-m", "pip", "install", "--upgrade", "pip"
            ], check=True, capture_output=True)
            
            # Install requirements
            result = subprocess.run([
                self.python_exe, "-m", "pip", "install", "-r", str(self.requirements_file)
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Dependências instaladas com sucesso")
                return True
            else:
                print(f"❌ Falha ao instalar dependências:")
                print(result.stderr)
                return False
                
        except subprocess.CalledProcessError as e:
            print(f"❌ Erro ao instalar dependências: {e}")
            return False
        except Exception as e:
            print(f"❌ Erro inesperado: {e}")
            return False
    
    def _check_dependencies(self) -> bool:
        """Check if all required dependencies are available."""
        required_modules = [
            'tkinter', 'ttkbootstrap', 'PIL', 'watchdog', 'psutil', 
            'numpy', 'schedule', 'yara', 'pefile', 'requests', 
            'win10toast', 'colorama', 'python-dateutil'
        ]
        
        missing_modules = []
        
        for module in required_modules:
            try:
                if module == 'PIL':
                    import PIL
                elif module == 'yara':
                    import yara
                else:
                    __import__(module)
            except ImportError:
                missing_modules.append(module)
        
        if missing_modules:
            print(f"❌ Dependências ausentes: {', '.join(missing_modules)}")
            return False
        
        print("✅ Todas as dependências estão disponíveis")
        return True
    
    def _create_shortcut(self) -> bool:
        """Create a desktop shortcut for easy access."""
        try:
            import winshell
            from win32com.client import Dispatch
            
            desktop = winshell.desktop()
            path = os.path.join(desktop, "CYBERMANS Anti-Ransomware.lnk")
            target = os.path.join(self.base_dir, "launcher.bat")
            wDir = str(self.base_dir)
            icon = os.path.join(self.base_dir, "icon.ico") if os.path.exists(os.path.join(self.base_dir, "icon.ico")) else ""
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(path)
            shortcut.Targetpath = target
            shortcut.WorkingDirectory = wDir
            if icon:
                shortcut.IconLocation = icon
            shortcut.save()
            
            print("✅ Atalho da área de trabalho criado")
            return True
        except Exception as e:
            print(f"⚠️ Não foi possível criar atalho: {e}")
            return False
    
    def _setup_environment(self) -> bool:
        """Set up the environment for the application."""
        try:
            # Create necessary directories
            directories = [
                "Logs", "Honeypots", "Backups", "Incidents", 
                "Quarantine", "Config"
            ]
            
            for directory in directories:
                dir_path = self.base_dir / directory
                dir_path.mkdir(exist_ok=True)
            
            # Create default configuration if it doesn't exist
            config_file = self.base_dir / "config.json"
            if not config_file.exists():
                default_config = {
                    "honeypot_count": 30,
                    "scan_interval": 10,
                    "backup_interval": 3600,
                    "auto_kill_threshold": 70,
                    "auto_restore": True,
                    "alert_sound": True,
                    "vss_snapshots_to_keep": 5,
                    "protection_level": "NORMAL"
                }
                
                with open(config_file, 'w') as f:
                    json.dump(default_config, f, indent=2)
                
                print("✅ Configuração padrão criada")
            
            return True
        except Exception as e:
            print(f"❌ Erro ao configurar ambiente: {e}")
            return False
    
    def _launch_application(self) -> bool:
        """Launch the main application."""
        try:
            print("🚀 Iniciando CYBERMANS Anti-Ransomware...")
            
            # Import and run the GUI
            sys.path.insert(0, str(self.base_dir))
            from GUI_PART_2 import main as gui_main
            
            # Run the GUI
            gui_main()
            return True
            
        except ImportError as e:
            print(f"❌ Falha ao importar GUI: {e}")
            print("Certifique-se de que GUI_PART_2.py está no mesmo diretório")
            return False
        except Exception as e:
            print(f"❌ Erro ao iniciar aplicação: {e}")
            return False
    
    def run(self) -> bool:
        """Main launcher function."""
        print("=" * 60)
        print("    INICIADOR CYBERMANS ANTI-RANSOMWARE")
        print("=" * 60)
        print()
        
        # Check if running as administrator
        if not self.is_admin:
            print("⚠️ Não está executando como administrador!")
            print("Reiniciando com privilégios de administrador...")
            print()
            
            if not self._run_as_admin():
                print("❌ Falha ao reiniciar como administrador")
                print("Execute este aplicativo como administrador manualmente")
                input("Pressione Enter para sair...")
                return False
            
            # Exit current instance (admin instance will start)
            sys.exit(0)
        
        print("✅ Executando com privilégios de administrador")
        print()
        
        # Check Python version
        if not self._check_python_version():
            input("Pressione Enter para sair...")
            return False
        
        # Check if dependencies are installed
        if not self._check_dependencies():
            print("Instalando dependências ausentes...")
            if not self._install_requirements():
                print("❌ Falha ao instalar dependências")
                input("Pressione Enter para sair...")
                return False
        
        # Set up environment
        if not self._setup_environment():
            print("❌ Falha ao configurar ambiente")
            input("Pressione Enter para sair...")
            return False
        
        # Create desktop shortcut
        self._create_shortcut()
        
        print()
        print("✅ Todos os sistemas prontos!")
        print("Iniciando CYBERMANS Anti-Ransomware...")
        print()
        
        # Launch the application
        return self._launch_application()

def main():
    """Main entry point."""
    launcher = AntiRansomwareLauncher()
    
    try:
        success = launcher.run()
        if not success:
            print("❌ Aplicação falhou ao iniciar")
            input("Pressione Enter para sair...")
    except KeyboardInterrupt:
        print("\n👋 Aplicação interrompida pelo usuário")
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()
