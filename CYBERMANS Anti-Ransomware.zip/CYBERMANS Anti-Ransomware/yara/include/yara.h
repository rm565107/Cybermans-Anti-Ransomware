#ifndef YARA_H
#define YARA_H
#include "yara/rules.h"
#include "yara/compiler.h"

#define ERROR_SUCCESS 0
#define CALLBACK_MSG_RULE_MATCHING 1
#define CALLBACK_MSG_RULE_NOT_MATCHING 2
#define CALLBACK_MSG_SCAN_FINISHED 3
#define CALLBACK_MSG_TOO_MANY_MATCHES 4
#define CALLBACK_MSG_CONSOLE_LOG 5
#define CALLBACK_CONTINUE 0
#define SCAN_FLAGS_REPORT_RULES_MATCHING 1
#define META_TYPE_STRING 1

int yr_initialize(void);
int yr_finalize(void);
int yr_compiler_create(YR_COMPILER** compiler);
void yr_compiler_destroy(YR_COMPILER* compiler);
int yr_compiler_add_file(YR_COMPILER* compiler, FILE* file, const char* namespace, const char* file_name);
int yr_compiler_get_rules(YR_COMPILER* compiler, YR_RULES** rules);
void yr_rules_destroy(YR_RULES* rules);
int yr_rules_scan_file(YR_RULES* rules, const char* filename, int flags, void* callback, void* user_data, int timeout);
#define yr_rule_metas_foreach(rule, meta) for()
#endif
