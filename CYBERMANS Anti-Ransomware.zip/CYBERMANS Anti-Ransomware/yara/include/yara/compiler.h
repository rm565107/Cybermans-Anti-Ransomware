#ifndef YR_COMPILER_H
#define YR_COMPILER_H
typedef void YR_COMPILER;
#endif
