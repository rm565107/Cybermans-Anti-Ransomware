#ifndef YR_RULES_H
#define YR_RULES_H
typedef void YR_RULES;
typedef void YR_RULE;
typedef void YR_META;
typedef void YR_SCAN_CONTEXT;
#endif
