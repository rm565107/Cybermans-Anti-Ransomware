"""
Enhanced Signature-Based Detection System for Anti-Ransomware
Advanced pattern matching, threat intelligence, and signature analysis
"""

import os
import sys
import json
import hashlib
import re
import struct
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import requests
import time

# Import existing YARA scanner
from yara_scanner import YaraScanner

class EnhancedSignatureDetector:
    def __init__(self, base_dir=None):
        """Initialize the enhanced signature detection system."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Initialize components
        self.yara_scanner = YaraScanner("rules")
        self.threat_intelligence = ThreatIntelligence()
        self.pattern_matcher = AdvancedPatternMatcher()
        self.file_analyzer = FileStructureAnalyzer()
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'signature_detector_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("EnhancedSignatureDetector")
        
        # Detection statistics
        self.detection_stats = {
            'total_scans': 0,
            'threats_detected': 0,
            'yara_matches': 0,
            'pattern_matches': 0,
            'ti_matches': 0,
            'file_structure_matches': 0
        }
        
        # Load known ransomware families
        self.ransomware_families = self._load_ransomware_families()
        
    def _load_ransomware_families(self) -> Dict[str, Dict]:
        """Load known ransomware family signatures and characteristics."""
        families = {
            'WannaCry': {
                'extensions': ['.WNCRY', '.WCRY', '.wncrypt', '.wncryt'],
                'patterns': [b'WanaCrypt0r', b'WannaCry', b'WNCRY'],
                'file_hashes': [],  # Will be populated from TI
                'behavioral_indicators': ['mass_file_encryption', 'network_spread', 'kill_switch'],
                'severity': 'CRITICAL'
            },
            'Locky': {
                'extensions': ['.locky', '.zepto', '.odin', '.shit', '.thor'],
                'patterns': [b'Locky', b'Zepto', b'Odin'],
                'file_hashes': [],
                'behavioral_indicators': ['email_attachment', 'javascript_dropper', 'tor_communication'],
                'severity': 'HIGH'
            },
            'Cerber': {
                'extensions': ['.cerber', '.cerber2', '.cerber3'],
                'patterns': [b'Cerber', b'CERBER'],
                'file_hashes': [],
                'behavioral_indicators': ['audio_ransom_note', 'tor_communication', 'file_encryption'],
                'severity': 'HIGH'
            },
            'Petya': {
                'extensions': ['.petya', '.petya2'],
                'patterns': [b'Petya', b'PETYA'],
                'file_hashes': [],
                'behavioral_indicators': ['mbr_encryption', 'boot_sector_modification', 'network_spread'],
                'severity': 'CRITICAL'
            },
            'TeslaCrypt': {
                'extensions': ['.teslacrypt', '.vvv', '.ccc', '.zzz', '.aaa'],
                'patterns': [b'TeslaCrypt', b'TESLACRYPT'],
                'file_hashes': [],
                'behavioral_indicators': ['file_encryption', 'bitcoin_payment', 'tor_communication'],
                'severity': 'HIGH'
            },
            'CryptoLocker': {
                'extensions': ['.cryptolocker', '.encrypted'],
                'patterns': [b'CryptoLocker', b'CRYPTOLOCKER'],
                'file_hashes': [],
                'behavioral_indicators': ['email_attachment', 'file_encryption', 'bitcoin_payment'],
                'severity': 'HIGH'
            }
        }
        return families
    
    def comprehensive_scan(self, filepath: str) -> Dict[str, Any]:
        """Perform comprehensive signature-based detection on a file."""
        self.detection_stats['total_scans'] += 1
        
        result = {
            'file': filepath,
            'timestamp': datetime.now().isoformat(),
            'detection_methods': [],
            'threats_found': [],
            'confidence_score': 0.0,
            'threat_family': None,
            'severity': 'LOW',
            'recommended_action': 'MONITOR'
        }
        
        file_path = Path(filepath)
        if not file_path.exists():
            result['error'] = 'File not found'
            return result
        
        try:
            # Method 1: YARA rule scanning
            yara_result = self._yara_scan(file_path)
            if yara_result['threats_found']:
                result['detection_methods'].append('YARA')
                result['threats_found'].extend(yara_result['threats_found'])
                result['confidence_score'] += 0.4
                self.detection_stats['yara_matches'] += 1
            
            # Method 2: Advanced pattern matching
            pattern_result = self._pattern_scan(file_path)
            if pattern_result['threats_found']:
                result['detection_methods'].append('PATTERN')
                result['threats_found'].extend(pattern_result['threats_found'])
                result['confidence_score'] += 0.3
                self.detection_stats['pattern_matches'] += 1
            
            # Method 3: File structure analysis
            structure_result = self._file_structure_scan(file_path)
            if structure_result['threats_found']:
                result['detection_methods'].append('FILE_STRUCTURE')
                result['threats_found'].extend(structure_result['threats_found'])
                result['confidence_score'] += 0.2
                self.detection_stats['file_structure_matches'] += 1
            
            # Method 4: Threat intelligence lookup
            ti_result = self._threat_intelligence_scan(file_path)
            if ti_result['threats_found']:
                result['detection_methods'].append('THREAT_INTELLIGENCE')
                result['threats_found'].extend(ti_result['threats_found'])
                result['confidence_score'] += 0.4
                self.detection_stats['ti_matches'] += 1
            
            # Method 5: Ransomware family identification
            family_result = self._identify_ransomware_family(file_path)
            if family_result:
                result['threat_family'] = family_result['family']
                result['severity'] = family_result['severity']
                result['confidence_score'] += 0.3
                result['threats_found'].append({
                    'type': 'family_identification',
                    'family': family_result['family'],
                    'description': f'Identified as {family_result["family"]} ransomware family',
                    'severity': family_result['severity']
                })
            
            # Calculate final confidence and determine action
            result['confidence_score'] = min(result['confidence_score'], 1.0)
            result['recommended_action'] = self._determine_action(result['confidence_score'], result['severity'])
            
            if result['threats_found']:
                self.detection_stats['threats_detected'] += 1
            
        except Exception as e:
            self.logger.error(f"Error in comprehensive scan: {e}")
            result['error'] = str(e)
        
        return result
    
    def _yara_scan(self, file_path: Path) -> Dict[str, Any]:
        """Perform YARA rule scanning."""
        try:
            yara_result = self.yara_scanner.scan_file(str(file_path))
            return {
                'threats_found': yara_result.get('threats_found', []),
                'method': 'YARA'
            }
        except Exception as e:
            self.logger.error(f"YARA scan error: {e}")
            return {'threats_found': [], 'method': 'YARA', 'error': str(e)}
    
    def _pattern_scan(self, file_path: Path) -> Dict[str, Any]:
        """Perform advanced pattern matching."""
        threats = []
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read(1024 * 1024)  # Read first 1MB
            
            # Check against known ransomware families
            for family_name, family_info in self.ransomware_families.items():
                for pattern in family_info['patterns']:
                    if pattern in content:
                        threats.append({
                            'type': 'pattern_match',
                            'family': family_name,
                            'pattern': pattern.decode('utf-8', errors='ignore'),
                            'description': f'Found {family_name} ransomware pattern',
                            'severity': family_info['severity']
                        })
            
            # Check for ransom note patterns
            ransom_patterns = [
                (b'Your files have been encrypted', 'ransom_note'),
                (b'All your files have been encrypted', 'ransom_note'),
                (b'pay the ransom', 'payment_demand'),
                (b'bitcoin address', 'bitcoin_payment'),
                (b'decrypt your files', 'decryption_offer'),
                (b'tor browser', 'tor_communication'),
                (b'.onion', 'tor_communication'),
                (b'RECOVER YOUR FILES', 'ransom_note'),
                (b'ATTENTION!', 'ransom_note')
            ]
            
            for pattern, pattern_type in ransom_patterns:
                if pattern.lower() in content.lower():
                    threats.append({
                        'type': pattern_type,
                        'pattern': pattern.decode('utf-8', errors='ignore'),
                        'description': f'Found {pattern_type} pattern',
                        'severity': 'HIGH'
                    })
            
            # Check for encryption indicators
            if self._detect_encryption_patterns(content):
                threats.append({
                    'type': 'encryption_indicator',
                    'description': 'File shows signs of encryption',
                    'severity': 'MEDIUM'
                })
            
        except Exception as e:
            self.logger.error(f"Pattern scan error: {e}")
        
        return {'threats_found': threats, 'method': 'PATTERN'}
    
    def _file_structure_scan(self, file_path: Path) -> Dict[str, Any]:
        """Analyze file structure for ransomware indicators."""
        threats = []
        
        try:
            # Check file extension
            extension = file_path.suffix.lower()
            for family_name, family_info in self.ransomware_families.items():
                if extension in family_info['extensions']:
                    threats.append({
                        'type': 'extension_match',
                        'family': family_name,
                        'extension': extension,
                        'description': f'File extension matches {family_name} ransomware',
                        'severity': family_info['severity']
                    })
            
            # Check file size (very small or very large files can be suspicious)
            file_size = file_path.stat().st_size
            if file_size < 1024:  # Less than 1KB
                threats.append({
                    'type': 'suspicious_size',
                    'description': 'File is unusually small',
                    'severity': 'LOW'
                })
            elif file_size > 100 * 1024 * 1024:  # More than 100MB
                threats.append({
                    'type': 'suspicious_size',
                    'description': 'File is unusually large',
                    'severity': 'LOW'
                })
            
            # Check for PE header (executable files)
            if self._is_pe_file(file_path):
                threats.append({
                    'type': 'executable_file',
                    'description': 'File is an executable',
                    'severity': 'MEDIUM'
                })
            
            # Check for packed/obfuscated content
            if self._detect_packing(file_path):
                threats.append({
                    'type': 'packed_file',
                    'description': 'File appears to be packed/obfuscated',
                    'severity': 'MEDIUM'
                })
            
        except Exception as e:
            self.logger.error(f"File structure scan error: {e}")
        
        return {'threats_found': threats, 'method': 'FILE_STRUCTURE'}
    
    def _threat_intelligence_scan(self, file_path: Path) -> Dict[str, Any]:
        """Check file against threat intelligence databases."""
        threats = []
        
        try:
            # Calculate file hash
            file_hash = self._calculate_file_hash(file_path)
            
            # Check against local threat intelligence
            if self.threat_intelligence.is_known_malware(file_hash):
                threats.append({
                    'type': 'known_malware',
                    'hash': file_hash,
                    'description': 'File hash matches known malware',
                    'severity': 'CRITICAL'
                })
            
            # Check against ransomware-specific hashes
            if self.threat_intelligence.is_ransomware_hash(file_hash):
                threats.append({
                    'type': 'known_ransomware',
                    'hash': file_hash,
                    'description': 'File hash matches known ransomware',
                    'severity': 'CRITICAL'
                })
            
        except Exception as e:
            self.logger.error(f"Threat intelligence scan error: {e}")
        
        return {'threats_found': threats, 'method': 'THREAT_INTELLIGENCE'}
    
    def _identify_ransomware_family(self, file_path: Path) -> Optional[Dict]:
        """Identify the specific ransomware family."""
        try:
            with open(file_path, 'rb') as f:
                content = f.read(1024 * 1024)  # Read first 1MB
            
            extension = file_path.suffix.lower()
            
            for family_name, family_info in self.ransomware_families.items():
                # Check extension match
                if extension in family_info['extensions']:
                    return {
                        'family': family_name,
                        'severity': family_info['severity'],
                        'confidence': 0.8
                    }
                
                # Check pattern match
                for pattern in family_info['patterns']:
                    if pattern in content:
                        return {
                            'family': family_name,
                            'severity': family_info['severity'],
                            'confidence': 0.9
                        }
            
        except Exception as e:
            self.logger.error(f"Family identification error: {e}")
        
        return None
    
    def _detect_encryption_patterns(self, content: bytes) -> bool:
        """Detect patterns that indicate file encryption."""
        # Check for high entropy (encrypted data has high entropy)
        if len(content) < 1024:
            return False
        
        # Calculate entropy of first 1KB
        entropy = self._calculate_entropy(content[:1024])
        if entropy > 7.5:
            return True
        
        # Check for common encryption patterns
        encryption_indicators = [
            b'\x00' * 16,  # Null padding
            b'\xFF' * 16,  # All ones padding
            b'PK\x03\x04',  # ZIP file header (common in ransomware)
            b'Rar!\x1a\x07\x00',  # RAR file header
        ]
        
        for indicator in encryption_indicators:
            if indicator in content:
                return True
        
        return False
    
    def _is_pe_file(self, file_path: Path) -> bool:
        """Check if file is a PE (Portable Executable) file."""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(2)
                return header == b'MZ'  # PE files start with MZ
        except:
            return False
    
    def _detect_packing(self, file_path: Path) -> bool:
        """Detect if file is packed/obfuscated."""
        try:
            with open(file_path, 'rb') as f:
                content = f.read(8192)  # Read first 8KB
            
            # Check for common packer signatures
            packer_signatures = [
                b'UPX!',  # UPX packer
                b'PECompact',  # PECompact
                b'FSG!',  # FSG packer
                b'MEW',  # MEW packer
                b'ASPack',  # ASPack
            ]
            
            for signature in packer_signatures:
                if signature in content:
                    return True
            
            # Check for suspicious entropy patterns
            entropy = self._calculate_entropy(content)
            if entropy > 7.8:  # Very high entropy suggests packing
                return True
            
        except:
            pass
        
        return False
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA256 hash of file."""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, 'rb') as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except:
            return ""
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        
        import math
        frequency = {}
        for byte in data:
            frequency[byte] = frequency.get(byte, 0) + 1
        
        entropy = 0.0
        data_len = len(data)
        for freq in frequency.values():
            if freq > 0:
                probability = freq / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _determine_action(self, confidence: float, severity: str) -> str:
        """Determine recommended action based on confidence and severity."""
        if confidence >= 0.8 and severity in ['CRITICAL', 'HIGH']:
            return 'IMMEDIATE_QUARANTINE'
        elif confidence >= 0.6:
            return 'QUARANTINE'
        elif confidence >= 0.4:
            return 'MONITOR_CLOSELY'
        else:
            return 'MONITOR'
    
    def get_detection_stats(self) -> Dict[str, Any]:
        """Get detection statistics."""
        return {
            'statistics': self.detection_stats,
            'ransomware_families': len(self.ransomware_families),
            'yara_rules_loaded': bool(self.yara_scanner.compiled_rules),
            'threat_intelligence_active': self.threat_intelligence.is_active()
        }


class ThreatIntelligence:
    """Threat intelligence integration for signature detection."""
    
    def __init__(self):
        self.malware_hashes = set()
        self.ransomware_hashes = set()
        self.last_update = None
        self.update_interval = 3600  # 1 hour
        
    def is_known_malware(self, file_hash: str) -> bool:
        """Check if hash is known malware."""
        self._update_if_needed()
        return file_hash.lower() in self.malware_hashes
    
    def is_ransomware_hash(self, file_hash: str) -> bool:
        """Check if hash is known ransomware."""
        self._update_if_needed()
        return file_hash.lower() in self.ransomware_hashes
    
    def is_active(self) -> bool:
        """Check if threat intelligence is active."""
        return len(self.malware_hashes) > 0 or len(self.ransomware_hashes) > 0
    
    def _update_if_needed(self):
        """Update threat intelligence if needed."""
        if (self.last_update is None or 
            time.time() - self.last_update > self.update_interval):
            self._update_threat_intelligence()
    
    def _update_threat_intelligence(self):
        """Update threat intelligence from various sources."""
        try:
            # This would typically connect to threat intelligence APIs
            # For now, we'll use a local database approach
            self._load_local_threat_intelligence()
            self.last_update = time.time()
        except Exception as e:
            logging.error(f"Failed to update threat intelligence: {e}")
    
    def _load_local_threat_intelligence(self):
        """Load threat intelligence from local sources."""
        # In a real implementation, this would load from:
        # - VirusTotal API
        # - MISP instances
        # - Commercial threat feeds
        # - Open source intelligence
        
        # For demonstration, we'll add some known ransomware hashes
        known_ransomware_hashes = [
            # These are example hashes - in reality, you'd load from actual sources
            "a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
            "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
        ]
        
        self.ransomware_hashes.update(known_ransomware_hashes)


class AdvancedPatternMatcher:
    """Advanced pattern matching for ransomware detection."""
    
    def __init__(self):
        self.patterns = self._load_patterns()
    
    def _load_patterns(self) -> List[Dict]:
        """Load advanced patterns for detection."""
        return [
            {
                'name': 'ransom_note_html',
                'pattern': rb'<html.*?Your files have been encrypted.*?</html>',
                'severity': 'HIGH',
                'type': 'ransom_note'
            },
            {
                'name': 'bitcoin_address',
                'pattern': rb'[13][a-km-zA-HJ-NP-Z1-9]{25,34}',
                'severity': 'MEDIUM',
                'type': 'bitcoin_address'
            },
            {
                'name': 'tor_domain',
                'pattern': rb'[a-z2-7]{16}\.onion',
                'severity': 'HIGH',
                'type': 'tor_domain'
            },
            {
                'name': 'encryption_key',
                'pattern': rb'[A-Za-z0-9+/]{40,}={0,2}',
                'severity': 'MEDIUM',
                'type': 'encryption_key'
            }
        ]
    
    def match_patterns(self, content: bytes) -> List[Dict]:
        """Match content against known patterns."""
        matches = []
        
        for pattern_info in self.patterns:
            try:
                pattern = re.compile(pattern_info['pattern'], re.IGNORECASE | re.DOTALL)
                if pattern.search(content):
                    matches.append({
                        'pattern_name': pattern_info['name'],
                        'type': pattern_info['type'],
                        'severity': pattern_info['severity'],
                        'description': f'Matched {pattern_info["name"]} pattern'
                    })
            except Exception as e:
                logging.error(f"Pattern matching error: {e}")
        
        return matches


class FileStructureAnalyzer:
    """Analyze file structure for ransomware indicators."""
    
    def __init__(self):
        self.suspicious_extensions = self._load_suspicious_extensions()
        self.file_signatures = self._load_file_signatures()
    
    def _load_suspicious_extensions(self) -> List[str]:
        """Load list of suspicious file extensions."""
        return [
            '.locked', '.encrypted', '.crypto', '.enc', '.lock',
            '.cerber', '.locky', '.zepto', '.odin', '.shit', '.thor',
            '.zzzzz', '.micro', '.cryptolocker', '.vault', '.petya',
            '.gwdata', '.cerber3', '.cerber2', '.crypt', '.WNCRY',
            '.WCRY', '.wncrypt', '.wncryt', '.teslacrypt', '.vvv',
            '.ccc', '.zzz', '.aaa', '.encrypted', '.crypto'
        ]
    
    def _load_file_signatures(self) -> Dict[bytes, str]:
        """Load file signatures for identification."""
        return {
            b'\x50\x4B\x03\x04': 'ZIP',
            b'\x50\x4B\x05\x06': 'ZIP',
            b'\x50\x4B\x07\x08': 'ZIP',
            b'Rar!\x1a\x07\x00': 'RAR',
            b'Rar!\x1a\x07\x01': 'RAR',
            b'\x7f\x45\x4c\x46': 'ELF',
            b'MZ': 'PE',
            b'\x89PNG\r\n\x1a\n': 'PNG',
            b'\xFF\xD8\xFF': 'JPEG',
            b'GIF87a': 'GIF',
            b'GIF89a': 'GIF'
        }
    
    def analyze_file(self, file_path: Path) -> Dict[str, Any]:
        """Analyze file structure for indicators."""
        analysis = {
            'suspicious_extension': False,
            'file_type': 'unknown',
            'entropy': 0.0,
            'size': 0,
            'indicators': []
        }
        
        try:
            # Check extension
            extension = file_path.suffix.lower()
            if extension in self.suspicious_extensions:
                analysis['suspicious_extension'] = True
                analysis['indicators'].append(f'Suspicious extension: {extension}')
            
            # Get file size
            analysis['size'] = file_path.stat().st_size
            
            # Analyze file content
            with open(file_path, 'rb') as f:
                header = f.read(1024)
                
                # Check file signature
                for signature, file_type in self.file_signatures.items():
                    if header.startswith(signature):
                        analysis['file_type'] = file_type
                        break
                
                # Calculate entropy
                analysis['entropy'] = self._calculate_entropy(header)
                
                # Check for encryption indicators
                if analysis['entropy'] > 7.5:
                    analysis['indicators'].append('High entropy suggests encryption')
                
                # Check for packed content
                if self._detect_packing(header):
                    analysis['indicators'].append('File appears to be packed')
        
        except Exception as e:
            logging.error(f"File structure analysis error: {e}")
        
        return analysis
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy."""
        if not data:
            return 0.0
        
        import math
        frequency = {}
        for byte in data:
            frequency[byte] = frequency.get(byte, 0) + 1
        
        entropy = 0.0
        data_len = len(data)
        for freq in frequency.values():
            if freq > 0:
                probability = freq / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _detect_packing(self, header: bytes) -> bool:
        """Detect if file is packed."""
        # Simple entropy-based packing detection
        entropy = self._calculate_entropy(header)
        return entropy > 7.8


def main():
    """Test the enhanced signature detector."""
    print("=== Enhanced Signature-Based Detection System ===\n")
    
    detector = EnhancedSignatureDetector()
    
    while True:
        print("\n1. Scan File")
        print("2. Scan Directory")
        print("3. Show Detection Stats")
        print("4. Update Threat Intelligence")
        print("5. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            filepath = input("Enter file path: ")
            result = detector.comprehensive_scan(filepath)
            
            print(f"\n=== Detection Results ===")
            print(f"File: {result['file']}")
            print(f"Confidence: {result['confidence_score']:.2f}")
            print(f"Severity: {result['severity']}")
            print(f"Action: {result['recommended_action']}")
            
            if result.get('threat_family'):
                print(f"Family: {result['threat_family']}")
            
            if result['threats_found']:
                print(f"\nThreats Found ({len(result['threats_found'])}):")
                for threat in result['threats_found']:
                    print(f"  - {threat['description']} [{threat['severity']}]")
            else:
                print("\n✓ No threats detected")
        
        elif choice == "2":
            directory = input("Enter directory path: ")
            # Directory scanning would be implemented here
            print("Directory scanning not implemented in this demo")
        
        elif choice == "3":
            stats = detector.get_detection_stats()
            print(f"\n=== Detection Statistics ===")
            for key, value in stats['statistics'].items():
                print(f"{key}: {value}")
        
        elif choice == "4":
            print("Updating threat intelligence...")
            detector.threat_intelligence._update_threat_intelligence()
            print("✓ Threat intelligence updated")
        
        elif choice == "5":
            break


if __name__ == "__main__":
    main()
