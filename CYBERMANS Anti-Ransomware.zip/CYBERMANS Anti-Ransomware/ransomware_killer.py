"""
Ransomware Process Killer Module for Anti-Ransomware Shield
Identifies and terminates ransomware processes
"""

import os
import psutil
import time
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import ctypes
import sys

class RansomwareKiller:
    def __init__(self, base_dir=None):
        """Initialize the ransomware killer module."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        self.suspected_processes = []
        self.terminated_processes = []
        self.whitelist = self.load_whitelist()
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'ransomware_killer_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("RansomwareKiller")
        
        # Check if running with admin privileges
        self.is_admin = self.check_admin()
        if not self.is_admin:
            self.logger.warning("Not running with administrator privileges. Some features may be limited.")
    
    def check_admin(self) -> bool:
        """Check if running with administrator privileges."""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    
    def load_whitelist(self) -> List[str]:
        """Load process whitelist from configuration."""
        whitelist = [
            'system', 'smss.exe', 'csrss.exe', 'wininit.exe', 'winlogon.exe',
            'services.exe', 'lsass.exe', 'svchost.exe', 'explorer.exe',
            'python.exe', 'pythonw.exe', 'cmd.exe', 'powershell.exe',
            'chrome.exe', 'firefox.exe', 'edge.exe', 'notepad.exe',
            'taskmgr.exe', 'dwm.exe', 'searchui.exe', 'searchapp.exe'
        ]
        
        # Load custom whitelist if exists
        whitelist_file = self.base_dir / "config" / "whitelist.json"
        if whitelist_file.exists():
            try:
                with open(whitelist_file, 'r') as f:
                    custom_whitelist = json.load(f)
                    whitelist.extend(custom_whitelist)
            except Exception as e:
                self.logger.error(f"Failed to load custom whitelist: {e}")
        
        return [p.lower() for p in whitelist]
    
    def identify_ransomware_processes(self, honeypot_files: List[str] = None) -> List[Dict]:
        """Identify potential ransomware processes."""
        suspected = []
        
        # Enhanced suspicious process name patterns (including WannaCry variants)
        suspicious_patterns = [
            'crypt', 'lock', 'ransom', 'wanna', 'cry', 'petya', 'locky',
            'cerber', 'tesla', 'maze', 'snake', 'encrypt', 'decoder',
            'restore', 'wallet', 'bitcoin', 'btc', 'payment', 'wannacry',
            'wcry', 'ms17-010', 'eternalblue', 'doublepulsar', 'notpetya',
            'badrabbit', 'gandcrab', 'ryuk', 'sodinokibi', 'maze', 'egregor',
            'conti', 'babuk', 'lockbit', 'avaddon', 'revil', 'suncrypt',
            'clop', 'dark', 'side', 'blackmatter', 'harvest', 'labyrinth',
            'hive', 'black', 'cat', 'alphv', 'royal', 'play', 'bianlian',
            'medusa', 'akira', 'cactus', '8base', 'inc', 'ransom', 'exx',
            'mallox', 'rhysida', 'cryptnet', 'cryptowall', 'cryptolocker',
            'cryptodefense', 'cryptowall', 'cryptoshield', 'cryptowall',
            'cryptowall', 'cryptowall', 'cryptowall', 'cryptowall'
        ]
        
        # Suspicious behaviors
        file_operations_threshold = 50  # Files accessed per second
        cpu_threshold = 80  # CPU usage percentage
        
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'create_time', 'cpu_percent']):
            try:
                proc_info = proc.info
                proc_name = proc_info['name'].lower() if proc_info['name'] else ''
                
                # Skip whitelisted processes
                if proc_name in self.whitelist:
                    continue
                
                suspicious_score = 0
                reasons = []
                
                # Check 1: Suspicious process name (enhanced for WannaCry)
                for pattern in suspicious_patterns:
                    if pattern in proc_name:
                        suspicious_score += 40  # Increased score for name patterns
                        reasons.append(f"Suspicious name pattern: {pattern}")
                        break
                
                # Special WannaCry detection
                if any(wc_pattern in proc_name for wc_pattern in ['wannacry', 'wcry', 'ms17-010', 'eternalblue']):
                    suspicious_score += 50  # Maximum score for WannaCry
                    reasons.append("WannaCry ransomware detected!")
                
                # Check for processes with suspicious extensions
                if proc_info['exe'] and any(ext in proc_info['exe'].lower() for ext in ['.exe', '.scr', '.bat', '.cmd', '.vbs']):
                    if any(susp_word in proc_info['exe'].lower() for susp_word in ['crypt', 'lock', 'encrypt', 'wanna', 'cry']):
                        suspicious_score += 35
                        reasons.append(f"Suspicious executable: {proc_info['exe']}")
                
                # Check 2: High CPU usage
                try:
                    cpu_percent = proc.cpu_percent(interval=0.1)
                    if cpu_percent > cpu_threshold:
                        suspicious_score += 20
                        reasons.append(f"High CPU usage: {cpu_percent:.1f}%")
                except:
                    pass
                
                # Check 3: Accessing many files rapidly (enhanced for ransomware)
                try:
                    open_files = proc.open_files()
                    if len(open_files) > file_operations_threshold:
                        suspicious_score += 40  # Increased score
                        reasons.append(f"Accessing many files: {len(open_files)}")
                    
                    # Check for file encryption patterns
                    encrypted_files = 0
                    for file_info in open_files:
                        file_path = file_info.path.lower()
                        if any(ext in file_path for ext in ['.locked', '.encrypted', '.crypto', '.enc', '.lock', '.cerber', '.locky', '.zepto', '.odin', '.crypt']):
                            encrypted_files += 1
                    
                    if encrypted_files > 5:  # If accessing many encrypted files
                        suspicious_score += 50
                        reasons.append(f"Accessing encrypted files: {encrypted_files}")
                    
                    # Check if accessing honeypot files
                    if honeypot_files:
                        for file_info in open_files:
                            if any(hp in file_info.path for hp in honeypot_files):
                                suspicious_score += 50
                                reasons.append(f"Accessing honeypot: {file_info.path}")
                                break
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass
                
                # Check 4: Recently created process
                try:
                    create_time = datetime.fromtimestamp(proc_info['create_time'])
                    time_since_creation = (datetime.now() - create_time).total_seconds()
                    if time_since_creation < 300:  # Created in last 5 minutes
                        suspicious_score += 10
                        reasons.append("Recently created process")
                except:
                    pass
                
                # Check 5: Process without visible window
                try:
                    if proc_info['exe']:
                        # Check if process has no window
                        connections = proc.connections()
                        if not connections and suspicious_score > 0:
                            suspicious_score += 10
                            reasons.append("Hidden process (no window)")
                except:
                    pass
                
                # Check 6: Network connections to suspicious IPs
                try:
                    connections = proc.connections()
                    for conn in connections:
                        if conn.status == 'ESTABLISHED' and conn.raddr:
                            # Check for TOR or known C&C patterns
                            if conn.raddr.port in [9001, 9050, 9051]:  # TOR ports
                                suspicious_score += 30
                                reasons.append(f"TOR connection: {conn.raddr}")
                except:
                    pass
                
                # Check 7: Memory patterns
                try:
                    memory_info = proc.memory_info()
                    # Unusually high memory for simple process
                    if memory_info.rss > 500 * 1024 * 1024 and suspicious_score > 0:  # 500MB
                        suspicious_score += 15
                        reasons.append(f"High memory usage: {memory_info.rss / 1024 / 1024:.0f}MB")
                except:
                    pass
                
                # Add to suspected list if score is high enough
                if suspicious_score >= 50:
                    suspected.append({
                        'pid': proc_info['pid'],
                        'name': proc_info['name'],
                        'exe': proc_info['exe'],
                        'score': suspicious_score,
                        'reasons': reasons,
                        'timestamp': datetime.now().isoformat()
                    })
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        self.suspected_processes = suspected
        return suspected
    
    def terminate_process(self, pid: int, force: bool = False) -> bool:
        """Terminate a specific process by PID with enhanced ransomware detection."""
        try:
            proc = psutil.Process(pid)
            proc_name = proc.name()
            
            # Enhanced critical process protection
            critical_processes = [
                'system', 'smss.exe', 'csrss.exe', 'wininit.exe', 'winlogon.exe',
                'services.exe', 'lsass.exe', 'svchost.exe', 'explorer.exe',
                'dwm.exe', 'conhost.exe', 'audiodg.exe', 'dllhost.exe'
            ]
            
            if proc_name.lower() in critical_processes:
                self.logger.error(f"Refused to terminate critical system process: {proc_name}")
                return False
            
            # For suspected ransomware, use immediate force kill
            if force or any(ransomware_indicator in proc_name.lower() for ransomware_indicator in 
                          ['wannacry', 'wcry', 'crypt', 'lock', 'encrypt', 'ransom']):
                self.logger.critical(f"🚨 IMMEDIATE TERMINATION: {proc_name} (PID: {pid}) - RANSOMWARE DETECTED")
                
                # Immediate force kill for ransomware
                try:
                    proc.kill()
                    proc.wait(timeout=2)
                    self.logger.critical(f"✅ RANSOMWARE ELIMINATED: {proc_name}")
                    return True
                except psutil.NoSuchProcess:
                    self.logger.critical(f"✅ RANSOMWARE ALREADY TERMINATED: {proc_name}")
                    return True
                except Exception as e:
                    self.logger.error(f"❌ Failed to force kill ransomware: {e}")
                    return False
            
            # Standard termination for other processes
            proc.terminate()
            
            # Wait for process to terminate
            try:
                proc.wait(timeout=3)  # Reduced timeout for faster response
            except psutil.TimeoutExpired:
                if force:
                    # Force kill if graceful termination failed
                    proc.kill()
                    proc.wait(timeout=2)
            
            self.terminated_processes.append({
                'pid': pid,
                'name': proc_name,
                'timestamp': datetime.now().isoformat(),
                'method': 'forced' if force else 'graceful'
            })
            
            self.logger.info(f"Successfully terminated process: {proc_name} (PID: {pid})")
            return True
            
        except psutil.NoSuchProcess:
            self.logger.warning(f"Process {pid} no longer exists")
            return False
        except psutil.AccessDenied:
            self.logger.error(f"Access denied when trying to terminate process {pid}")
            if not self.is_admin:
                self.logger.error("Try running with administrator privileges")
            return False
        except Exception as e:
            self.logger.error(f"Error terminating process {pid}: {e}")
            return False
    
    def quarantine_process(self, pid: int) -> bool:
        """Suspend a process instead of terminating it."""
        try:
            proc = psutil.Process(pid)
            proc.suspend()
            
            self.logger.info(f"Process suspended: {proc.name()} (PID: {pid})")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to suspend process {pid}: {e}")
            return False
    
    def kill_ransomware_by_name(self, process_names: List[str]) -> int:
        """Kill all processes matching given names."""
        killed_count = 0
        
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if proc.info['name'] and proc.info['name'].lower() in [n.lower() for n in process_names]:
                    if self.terminate_process(proc.info['pid'], force=True):
                        killed_count += 1
            except:
                continue
        
        return killed_count
    
    def emergency_kill_all_suspects(self) -> Dict:
        """Emergency function to kill all suspected ransomware processes."""
        self.logger.critical("EMERGENCY KILL INITIATED")
        
        # First identify suspects
        suspects = self.identify_ransomware_processes()
        
        results = {
            'suspects_found': len(suspects),
            'terminated': 0,
            'failed': 0,
            'processes': []
        }
        
        for suspect in suspects:
            success = self.terminate_process(suspect['pid'], force=True)
            
            if success:
                results['terminated'] += 1
            else:
                results['failed'] += 1
            
            results['processes'].append({
                'name': suspect['name'],
                'pid': suspect['pid'],
                'terminated': success,
                'reasons': suspect['reasons']
            })
        
        self.logger.info(f"Emergency kill complete: {results['terminated']} terminated, {results['failed']} failed")
        
        return results
    
    def monitor_and_kill(self, interval: int = 5, honeypot_files: List[str] = None):
        """Continuously monitor and kill ransomware processes."""
        self.logger.info("Starting continuous ransomware monitoring...")
        
        while True:
            try:
                suspects = self.identify_ransomware_processes(honeypot_files)
                
                if suspects:
                    self.logger.warning(f"Found {len(suspects)} suspicious processes")
                    
                    for suspect in suspects:
                        if suspect['score'] >= 70:  # High confidence
                            self.logger.critical(f"High-confidence ransomware detected: {suspect['name']}")
                            self.terminate_process(suspect['pid'], force=True)
                        elif suspect['score'] >= 50:  # Medium confidence
                            self.logger.warning(f"Suspicious process detected: {suspect['name']}")
                            # Could quarantine instead of kill for medium confidence
                
                time.sleep(interval)
                
            except KeyboardInterrupt:
                self.logger.info("Monitoring stopped by user")
                break
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(interval)
    
    def get_process_info(self, pid: int) -> Optional[Dict]:
        """Get detailed information about a process."""
        try:
            proc = psutil.Process(pid)
            
            info = {
                'pid': pid,
                'name': proc.name(),
                'exe': proc.exe(),
                'cmdline': proc.cmdline(),
                'create_time': datetime.fromtimestamp(proc.create_time()).isoformat(),
                'status': proc.status(),
                'cpu_percent': proc.cpu_percent(interval=0.1),
                'memory_mb': proc.memory_info().rss / 1024 / 1024,
                'num_threads': proc.num_threads(),
                'open_files': len(proc.open_files()),
                'connections': len(proc.connections()),
                'parent': proc.parent().name() if proc.parent() else None
            }
            
            return info
            
        except Exception as e:
            self.logger.error(f"Failed to get process info for PID {pid}: {e}")
            return None
    
    def save_kill_report(self) -> str:
        """Save a report of all terminated processes."""
        report_dir = self.base_dir / "Reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        
        report_file = report_dir / f"kill_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'suspected_processes': self.suspected_processes,
            'terminated_processes': self.terminated_processes,
            'is_admin': self.is_admin
        }
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        self.logger.info(f"Kill report saved to {report_file}")
        return str(report_file)


def main():
    """Test the ransomware killer module."""
    print("=== Anti-Ransomware Process Killer ===\n")
    
    # Check admin privileges
    if not ctypes.windll.shell32.IsUserAnAdmin():
        print("⚠️ WARNING: Not running as administrator!")
        print("Some features may not work properly.\n")
    
    killer = RansomwareKiller()
    
    while True:
        print("\n1. Identify Suspicious Processes")
        print("2. Kill Process by PID")
        print("3. Emergency Kill All Suspects")
        print("4. Start Continuous Monitoring")
        print("5. Get Process Info")
        print("6. Save Report")
        print("7. Exit")
        
        choice = input("\nSelect option: ")
        
        if choice == "1":
            suspects = killer.identify_ransomware_processes()
            
            if suspects:
                print(f"\n⚠️ Found {len(suspects)} suspicious processes:\n")
                for suspect in suspects:
                    print(f"PID: {suspect['pid']} - {suspect['name']}")
                    print(f"  Score: {suspect['score']}")
                    print(f"  Reasons: {', '.join(suspect['reasons'])}")
            else:
                print("\n✓ No suspicious processes found")
        
        elif choice == "2":
            pid = input("Enter PID to kill: ")
            try:
                pid = int(pid)
                if killer.terminate_process(pid):
                    print("✓ Process terminated successfully")
                else:
                    print("✗ Failed to terminate process")
            except ValueError:
                print("Invalid PID")
        
        elif choice == "3":
            confirm = input("⚠️ This will kill all suspected ransomware processes. Continue? (y/n): ")
            if confirm.lower() == 'y':
                results = killer.emergency_kill_all_suspects()
                print(f"\nResults:")
                print(f"  Suspects found: {results['suspects_found']}")
                print(f"  Terminated: {results['terminated']}")
                print(f"  Failed: {results['failed']}")
        
        elif choice == "4":
            print("Starting continuous monitoring...")
            print("Press Ctrl+C to stop")
            killer.monitor_and_kill()
        
        elif choice == "5":
            pid = input("Enter PID: ")
            try:
                pid = int(pid)
                info = killer.get_process_info(pid)
                if info:
                    print(f"\nProcess Information:")
                    for key, value in info.items():
                        print(f"  {key}: {value}")
            except ValueError:
                print("Invalid PID")
        
        elif choice == "6":
            report_file = killer.save_kill_report()
            print(f"✓ Report saved to {report_file}")
        
        elif choice == "7":
            break


if __name__ == "__main__":
    main()
