"""
Sistema de Honeypot Aprimorado para o Escudo Anti-Ransomware
Recursos: Posicionamento dinâmico, arquivos realistas e detecção proativa
"""

import os
import sys
import json
import random
import shutil
import hashlib
import time
from pathlib import Path
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Tuple, Optional
import win32file
import win32con
import win32api
import win32security
import ctypes
from ctypes import wintypes

# Para geração de documentos realistas
try:
    from docx import Document
    from openpyxl import Workbook
    OFFICE_LIBS = True
except ImportError:
    OFFICE_LIBS = False
    # Only show warning if not in GUI mode
    if 'GUI_PART_2' not in sys.modules:
        print("Nota: Instale python-docx e openpyxl para arquivos Office realistas")

class EnhancedHoneypotSystem:
    def __init__(self, base_dir=None):
        """Inicializar o sistema de honeypot aprimorado."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        self.honeypot_dir = self.base_dir / "Honeypots"
        self.honeypot_dir.mkdir(parents=True, exist_ok=True)
        
        # Para compatibilidade com honeypot_monitor
        self.static_honeypot_dir = self.honeypot_dir
        
        # Registro de honeypots
        self.registry = []
        self.registry_file = self.honeypot_dir / "enhanced_registry.json"
        
        # Configurar logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'honeypot_enhanced_{datetime.now().strftime("%Y%m%d")}.log', encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("EnhancedHoneypot")
        
        # Nomes atrativos para honeypots
        self.attractive_names = {
            'financial': [
                'Financial_Records_2024', 'Tax_Returns', 'Bank_Statements',
                'Credit_Card_Info', 'Investment_Portfolio', 'Salary_Information',
                'Budget_2024', 'Accounting', 'Invoices', 'Payroll'
            ],
            'personal': [
                'Passwords', 'Personal_Photos', 'Private_Documents',
                'Medical_Records', 'Insurance_Info', 'Social_Security',
                'Passport_Scan', 'Driver_License', 'Birth_Certificates'
            ],
            'business': [
                'Confidential', 'Customer_Database', 'Employee_Records',
                'Contracts', 'Business_Plan', 'Trade_Secrets', 'Patents',
                'Legal_Documents', 'Board_Minutes', 'Strategic_Plans'
            ],
            'crypto': [
                'Bitcoin_Wallet', 'Crypto_Keys', 'Wallet_Backup',
                'Private_Keys', 'Seed_Phrases', 'Mining_Config',
                'Exchange_Passwords', 'Blockchain_Backup'
            ]
        }
        
        # Manipuladores de pastas honeypot para monitoramento
        self.honey_folders = {}
        
    def find_high_activity_directories(self) -> List[Path]:
        """Encontrar diretórios com alta atividade do usuário."""
        high_activity_dirs = []
        
        # Começar com diretórios comuns do usuário
        user_dirs = [
            Path.home() / "Desktop",
            Path.home() / "Documents",
            Path.home() / "Downloads",
            Path.home() / "Pictures",
            Path.home() / "Videos",
            Path.home() / "OneDrive" if (Path.home() / "OneDrive").exists() else None,
            Path.home() / "Dropbox" if (Path.home() / "Dropbox").exists() else None,
            Path.home() / "Google Drive" if (Path.home() / "Google Drive").exists() else None,
        ]
        
        # Adicionar diretórios com modificações recentes
        for user_dir in user_dirs:
            if user_dir and user_dir.exists():
                try:
                    # Verificar subdiretórios por atividade recente
                    for subdir in user_dir.iterdir():
                        if subdir.is_dir() and not subdir.name.startswith('.'):
                            # Verificar se o diretório tem arquivos recentes
                            recent_files = self._count_recent_files(subdir)
                            if recent_files > 0:
                                high_activity_dirs.append(subdir)
                    
                    # Também adicionar o diretório principal
                    high_activity_dirs.append(user_dir)
                    
                except Exception as e:
                    self.logger.debug(f"Erro ao escanear {user_dir}: {e}")
        
        # Remover duplicatas e ordenar por profundidade (mais profundo = mais específico)
        high_activity_dirs = list(set(high_activity_dirs))
        high_activity_dirs.sort(key=lambda p: len(p.parts), reverse=True)
        
        return high_activity_dirs[:50]  # Limitar aos 50 principais diretórios
    
    def _count_recent_files(self, directory: Path, days=30) -> int:
        """Contar arquivos modificados nos últimos N dias."""
        count = 0
        cutoff_time = time.time() - (days * 86400)
        
        try:
            for file in directory.glob('*'):
                if file.is_file():
                    if file.stat().st_mtime > cutoff_time:
                        count += 1
                    if count > 5:  # Sair antecipadamente se encontrar o suficiente
                        break
        except:
            pass
        
        return count
    
    def create_realistic_docx(self, filepath: Path, title: str) -> bool:
        """Criar um documento Word realista."""
        if not OFFICE_LIBS:
            return self.create_realistic_text(filepath, title)
        
        try:
            doc = Document()
            
            # Adicionar título
            doc.add_heading(title, 0)
            
            # Adicionar conteúdo que pareça metadados
            doc.add_paragraph(f'Created: {datetime.now().strftime("%B %d, %Y")}')
            doc.add_paragraph(f'Classification: Confidential')
            doc.add_paragraph('')
            
            # Adicionar conteúdo realista baseado no título
            if 'financial' in title.lower() or 'bank' in title.lower():
                doc.add_heading('Account Summary', 1)
                doc.add_paragraph('Account Number: ****-****-****-4532')
                doc.add_paragraph('Balance: $45,234.67')
                doc.add_paragraph('Last Transaction: ' + datetime.now().strftime("%Y-%m-%d"))
                
            elif 'password' in title.lower():
                doc.add_heading('Important Accounts', 1)
                doc.add_paragraph('Banking: ********')
                doc.add_paragraph('Email: ********')
                doc.add_paragraph('Social: ********')
                
            elif 'medical' in title.lower():
                doc.add_heading('Medical Information', 1)
                doc.add_paragraph('Patient ID: MED-2024-78234')
                doc.add_paragraph('Insurance: Active')
                doc.add_paragraph('Last Visit: ' + (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"))
            
            else:
                # Conteúdo genérico de aparência importante
                doc.add_heading('Executive Summary', 1)
                doc.add_paragraph('This document contains sensitive information.')
                doc.add_paragraph('Unauthorized access is strictly prohibited.')
            
            # Adicionar alguns parágrafos de conteúdo tipo lorem ipsum
            for i in range(3):
                doc.add_paragraph(self._generate_realistic_paragraph())
            
            # Salvar o documento
            doc.save(str(filepath))
            
            # Manipular timestamps do arquivo para parecer usado
            self._manipulate_file_times(filepath)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Falha ao criar DOCX: {e}")
            return False
    
    def create_realistic_xlsx(self, filepath: Path, title: str) -> bool:
        """Criar uma planilha Excel realista."""
        if not OFFICE_LIBS:
            return self.create_realistic_csv(filepath, title)
        
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Data"
            
            # Adicionar cabeçalhos baseados no título
            if 'financial' in title.lower():
                headers = ['Date', 'Description', 'Amount', 'Balance', 'Category']
                ws.append(headers)
                
                # Add some data rows
                balance = 50000
                for i in range(20):
                    date = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                    amount = random.uniform(-500, 1000)
                    balance += amount
                    ws.append([
                        date,
                        f"Transaction {i+1}",
                        f"${amount:.2f}",
                        f"${balance:.2f}",
                        random.choice(['Income', 'Expense', 'Transfer'])
                    ])
            
            elif 'customer' in title.lower() or 'database' in title.lower():
                headers = ['ID', 'Name', 'Email', 'Phone', 'Registration Date', 'Status']
                ws.append(headers)
                
                # Add some data rows
                for i in range(50):
                    ws.append([
                        f"CUST{1000+i}",
                        f"Customer {i+1}",
                        f"customer{i+1}@example.com",
                        f"555-{random.randint(1000, 9999)}",
                        (datetime.now() - timedelta(days=random.randint(1, 365))).strftime("%Y-%m-%d"),
                        random.choice(['Active', 'Inactive', 'Premium'])
                    ])
            
            else:
                # Generic data
                headers = ['ID', 'Name', 'Value', 'Status', 'Date']
                ws.append(headers)
                for i in range(30):
                    ws.append([
                        i+1,
                        f"Item {i+1}",
                        random.randint(100, 10000),
                        random.choice(['Active', 'Pending', 'Complete']),
                        datetime.now().strftime("%Y-%m-%d")
                    ])
            
            # Save the workbook
            wb.save(str(filepath))
            
            # Manipulate file times
            self._manipulate_file_times(filepath)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create XLSX: {e}")
            return False
    
    def create_realistic_text(self, filepath: Path, title: str) -> bool:
        """Criar um arquivo de texto realista."""
        try:
            content = f"{title}\n{'=' * len(title)}\n\n"
            content += f"Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            content += f"Last Modified: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            
            # Adicionar conteúdo baseado no tipo
            if 'password' in title.lower():
                content += "Website Passwords:\n"
                content += "-" * 20 + "\n"
                sites = ['Banking', 'Email', 'Social Media', 'Shopping', 'Work VPN']
                for site in sites:
                    content += f"{site}: {'*' * random.randint(8, 16)}\n"
            
            elif 'key' in title.lower() or 'wallet' in title.lower():
                content += "Wallet Backup Information\n"
                content += "-" * 30 + "\n"
                content += f"Address: {''.join(random.choices('0123456789abcdef', k=40))}\n"
                content += f"Private Key: {''.join(random.choices('0123456789abcdef', k=64))}\n"
            
            else:
                # Add realistic paragraphs
                for _ in range(5):
                    content += self._generate_realistic_paragraph() + "\n\n"
            
            # Gravar arquivo
            filepath.write_text(content, encoding='utf-8')
            
            # Manipular timestamps do arquivo
            self._manipulate_file_times(filepath)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Falha ao criar arquivo de texto: {e}")
            return False
    
    def create_realistic_csv(self, filepath: Path, title: str) -> bool:
        """Criar um arquivo CSV realista."""
        try:
            headers = "ID,Name,Email,Phone,Address,Date,Amount,Status\n"
            content = headers
            
            for i in range(100):
                content += f"{i+1},"
                content += f"Person {i+1},"
                content += f"email{i+1}@example.com,"
                content += f"555-{random.randint(1000,9999)},"
                content += f"{random.randint(1,999)} Main St,"
                content += f"{datetime.now().strftime('%Y-%m-%d')},"
                content += f"${random.uniform(100, 10000):.2f},"
                content += f"{random.choice(['Active', 'Pending', 'Complete'])}\n"
            
            filepath.write_text(content, encoding='utf-8')
            
            # Manipulate file times
            self._manipulate_file_times(filepath)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Falha ao criar CSV: {e}")
            return False
    
    def _generate_realistic_paragraph(self) -> str:
        """Gerar um parágrafo com aparência realista."""
        sentences = [
            "Estas informações são classificadas como confidenciais e não devem ser compartilhadas.",
            "Os dados aqui contidos são proprietários e sensíveis.",
            "O acesso a este documento é restrito apenas a pessoal autorizado.",
            "Revisões e atualizações regulares são realizadas para garantir a precisão.",
            "Todas as transações financeiras são registradas e monitoradas.",
            "Protocolos de segurança devem ser seguidos ao lidar com estas informações.",
            "A conformidade com requisitos regulatórios é obrigatória.",
            "Qualquer acesso não autorizado será reportado às autoridades.",
        ]
        
        paragraph = ""
        for _ in range(random.randint(3, 6)):
            paragraph += random.choice(sentences) + " "
        
        return paragraph.strip()
    
    def _manipulate_file_times(self, filepath: Path):
        """Manipular timestamps do arquivo para parecer recentemente usado."""
        try:
            # Fazer o arquivo parecer ter sido criado dias/semanas atrás
            creation_time = time.time() - random.randint(86400, 86400 * 60)  # 1-60 dias atrás
            
            # Fazer parecer acessado recentemente
            access_time = time.time() - random.randint(3600, 86400 * 3)  # 1 hora a 3 dias atrás
            
            # Fazer parecer modificado recentemente
            modify_time = time.time() - random.randint(3600, 86400 * 7)  # 1 hora a 7 dias atrás
            
            # Definir os tempos (Windows)
            handle = win32file.CreateFile(
                str(filepath),
                win32con.GENERIC_WRITE,
                win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE | win32con.FILE_SHARE_DELETE,
                None,
                win32con.OPEN_EXISTING,
                0,
                None
            )
            
            win32file.SetFileTime(
                handle,
                win32api.Time(creation_time),
                win32api.Time(access_time),
                win32api.Time(modify_time)
            )
            
            handle.Close()
            
        except Exception as e:
            self.logger.debug(f"Falha ao manipular timestamps do arquivo: {e}")
    
    def create_honey_folder(self, parent_dir: Path, name: str) -> Optional[Path]:
        """Criar uma pasta honeypot (isca) com monitoramento."""
        try:
            honey_folder = parent_dir / f"__{name}__"
            honey_folder.mkdir(exist_ok=True)
            
            # Criar alguns arquivos honeypot dentro
            for i in range(3):
                filename = f"{name}_{i+1}"
                ext = random.choice(['.docx', '.xlsx', '.txt', '.pdf'])
                filepath = honey_folder / f"{filename}{ext}"
                
                if ext == '.docx':
                    self.create_realistic_docx(filepath, name)
                elif ext == '.xlsx':
                    self.create_realistic_xlsx(filepath, name)
                else:
                    self.create_realistic_text(filepath, name)
            
            # Configurar manipulador de monitoramento para detecção precoce
            self._setup_folder_monitoring(honey_folder)
            
            self.logger.info(f"Pasta honeypot criada: {honey_folder}")
            return honey_folder
            
        except Exception as e:
            self.logger.error(f"Falha ao criar pasta honeypot: {e}")
            return None
    
    def _setup_folder_monitoring(self, folder_path: Path):
        """Configurar monitoramento de baixo nível para acesso à pasta."""
        try:
            # Abrir handle do diretório para monitoramento
            handle = win32file.CreateFile(
                str(folder_path),
                win32con.FILE_LIST_DIRECTORY,
                win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE | win32con.FILE_SHARE_DELETE,
                None,
                win32con.OPEN_EXISTING,
                win32con.FILE_FLAG_BACKUP_SEMANTICS,
                None
            )
            
            self.honey_folders[str(folder_path)] = handle
            self.logger.info(f"Monitoramento configurado para: {folder_path}")
            
        except Exception as e:
            self.logger.error(f"Falha ao configurar monitoramento da pasta: {e}")
    
    def deploy_enhanced_honeypots(self, count=200) -> List[Dict]:
        """Implantar honeypots aprimorados em todo o sistema."""
        deployed = []
        
        # Obter diretórios de alta atividade
        activity_dirs = self.find_high_activity_directories()
        
        if not activity_dirs:
            self.logger.warning("Nenhum diretório de alta atividade encontrado, usando padrões")
            activity_dirs = [
                Path.home() / "Desktop",
                Path.home() / "Documents",
                Path.home() / "Downloads"
            ]
        
        self.logger.info(f"Implantando honeypots em {len(activity_dirs)} diretórios")
        
        # Implantar pastas honeypot (sistema de alerta precoce)
        honey_folder_count = min(10, len(activity_dirs))
        for i in range(honey_folder_count):
            target_dir = activity_dirs[i % len(activity_dirs)]
            name = random.choice(self.attractive_names['financial'] + self.attractive_names['crypto'])
            
            honey_folder = self.create_honey_folder(target_dir, name)
            if honey_folder:
                deployed.append({
                    'path': str(honey_folder),
                    'type': 'honey_folder',
                    'parent': str(target_dir),
                    'created': datetime.now().isoformat()
                })
        
        # Implantar arquivos honeypot regulares
        files_per_dir = max(1, count // len(activity_dirs))
        
        for target_dir in activity_dirs:
            for _ in range(files_per_dir):
                if len(deployed) >= count:
                    break
                
                # Escolher nome atrativo e extensão
                category = random.choice(list(self.attractive_names.keys()))
                base_name = random.choice(self.attractive_names[category])
                
                # Criar variações para evitar duplicatas exatas
                name_variation = f"{base_name}_{datetime.now().year}"
                if random.random() > 0.5:
                    name_variation = f"{base_name}_BACKUP"
                
                # Escolher tipo de arquivo
                file_type = random.choice(['docx', 'xlsx', 'txt', 'csv'])
                filepath = target_dir / f"{name_variation}.{file_type}"
                
                # Pular se o arquivo já existir
                if filepath.exists():
                    continue
                
                # Criar o arquivo honeypot
                success = False
                if file_type == 'docx':
                    success = self.create_realistic_docx(filepath, base_name)
                elif file_type == 'xlsx':
                    success = self.create_realistic_xlsx(filepath, base_name)
                elif file_type == 'csv':
                    success = self.create_realistic_csv(filepath, base_name)
                else:
                    success = self.create_realistic_text(filepath, base_name)
                
                if success:
                    # Calcular hash para monitoramento de integridade
                    file_hash = self._calculate_hash(filepath)
                    
                    deployed.append({
                        'path': str(filepath),
                        'type': file_type,
                        'category': category,
                        'parent': str(target_dir),
                        'created': datetime.now().isoformat(),
                        'hash': file_hash,
                        'size': filepath.stat().st_size
                    })
                    
                    self.logger.info(f"Honeypot implantado: {filepath}")
        
        # Salvar registro
        self.registry = deployed
        self.save_registry()
        
        self.logger.info(f"{len(deployed)} honeypots implantados com sucesso")
        return deployed
    
    def _calculate_hash(self, filepath: Path) -> str:
        """Calcular hash SHA256 do arquivo."""
        sha256 = hashlib.sha256()
        try:
            with open(filepath, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except:
            return ""
    
    def save_registry(self):
        """Salvar registro de honeypots em arquivo."""
        try:
            with open(self.registry_file, 'w') as f:
                json.dump(self.registry, f, indent=2)
            self.logger.info(f"Registro salvo: {len(self.registry)} honeypots")
        except Exception as e:
            self.logger.error(f"Falha ao salvar registro: {e}")
    
    def check_honey_folders(self) -> List[str]:
        """Verificar se alguma pasta honeypot foi acessada."""
        accessed = []
        
        for folder_path, handle in self.honey_folders.items():
            try:
                # Verificar quaisquer mudanças no sistema de arquivos
                results = win32file.ReadDirectoryChangesW(
                    handle,
                    1024,
                    False,  # Don't watch subtree
                    win32con.FILE_NOTIFY_CHANGE_FILE_NAME |
                    win32con.FILE_NOTIFY_CHANGE_DIR_NAME |
                    win32con.FILE_NOTIFY_CHANGE_LAST_ACCESS,
                    None,
                    None
                )
                
                if results:
                    accessed.append(folder_path)
                    self.logger.critical(f"PASTA HONEYPOT ACESSADA: {folder_path}")
                    
            except Exception as e:
                # No changes or error - both are fine
                pass
        
        return accessed
    
    def create_static_honeypot_structure(self):
        """Criar a estrutura de diretórios base para honeypots estáticos."""
        directories = [
            'Documents\\Financial',
            'Documents\\Personal',
            'Documents\\Work',
            'Pictures\\Family',
            'Pictures\\Vacation',
            'Databases',
            'Backups',
            'Projects'
        ]
        
        for dir_path in directories:
            full_path = self.static_honeypot_dir / dir_path
            full_path.mkdir(parents=True, exist_ok=True)
            self.logger.debug(f"Diretório criado: {full_path}")
    
    def create_static_honeypots(self, count=30):
        """Criar honeypots estáticos no diretório base (compatibilidade)."""
        self.create_static_honeypot_structure()
        
        static_registry = []
        financial_terms = ['invoice', 'payment', 'salary', 'budget', 'tax_return']
        personal_terms = ['passport', 'ssn', 'identity', 'medical_records', 'private']
        
        for i in range(count):
            # Choose random directory within static structure
            dirs = list(self.static_honeypot_dir.rglob('*/'))
            if not dirs:
                dirs = [self.static_honeypot_dir]
            target_dir = random.choice(dirs)
            
            # Choose file type and name
            file_type = random.choice(['txt', 'docx', 'xlsx', 'csv'])
            
            if random.random() > 0.5:
                name_base = random.choice(financial_terms + personal_terms)
            else:
                name_base = f"document_{random.randint(1000, 9999)}"
            
            filepath = target_dir / f"{name_base}.{file_type}"
            
            # Skip if file already exists
            if filepath.exists():
                continue
            
            # Create the honeypot file
            success = False
            if file_type == 'docx':
                success = self.create_realistic_docx(filepath, name_base)
            elif file_type == 'xlsx':
                success = self.create_realistic_xlsx(filepath, name_base)
            elif file_type == 'csv':
                success = self.create_realistic_csv(filepath, name_base)
            else:
                success = self.create_realistic_text(filepath, name_base)
            
            if success:
                # Calcular hash para monitoramento de integridade
                file_hash = self._calculate_hash(filepath)
                
                static_registry.append({
                    'path': str(filepath),
                    'type': file_type,
                    'checksum': file_hash,
                    'created': datetime.now().isoformat(),
                    'status': 'active'
                })
                
                self.logger.info(f"Honeypot estático criado: {filepath}")
        
        # Salvar registro de honeypots estáticos para compatibilidade com honeypot_monitor
        registry_file = self.static_honeypot_dir / 'honeypot_registry.json'
        with open(registry_file, 'w') as f:
            json.dump(static_registry, f, indent=2)
        
        self.logger.info(f"Criados {len(static_registry)} honeypots estáticos")
        return static_registry
    
    def generate_honeypots(self, count=30, static_count=30, dynamic_count=50):
        """Geração unificada de honeypots - estáticos e dinâmicos."""
        all_honeypots = []
        
        # Passo 1: Criar honeypots estáticos no diretório base
        self.logger.info("Criando honeypots estáticos...")
        static_honeypots = self.create_static_honeypots(static_count)
        all_honeypots.extend(static_honeypots)
        
        # Passo 2: Implantar honeypots dinâmicos pelo sistema
        self.logger.info("Implantando honeypots dinâmicos...")
        dynamic_honeypots = self.deploy_enhanced_honeypots(dynamic_count)
        all_honeypots.extend(dynamic_honeypots)
        
        self.logger.info(f"Total de honeypots criados: {len(all_honeypots)}")
        self.logger.info(f"  Estáticos: {len(static_honeypots)}")
        self.logger.info(f"  Dinâmicos: {len(dynamic_honeypots)}")
        
        return all_honeypots
    
    def cleanup_honeypots(self):
        """Remover todos os honeypots (para testes ou desinstalação)."""
        removed = 0
        for item in self.registry:
            try:
                path = Path(item['path'])
                if path.exists():
                    if path.is_dir():
                        shutil.rmtree(path)
                    else:
                        path.unlink()
                    removed += 1
            except Exception as e:
                self.logger.error(f"Failed to remove {item['path']}: {e}")
        
        # Close monitoring handles
        for handle in self.honey_folders.values():
            try:
                handle.Close()
            except:
                pass
        
        self.honey_folders.clear()
        self.registry.clear()
        self.save_registry()
        
        self.logger.info(f"Removidos {removed} honeypots")
        return removed


def main():
    """Testar o sistema de honeypot aprimorado."""
    print("=== Sistema de Honeypot Aprimorado ===\n")
    
    system = EnhancedHoneypotSystem()
    
    while True:
        print("\n1. Implantar Honeypots Aprimorados")
        print("2. Verificar Pastas Honeypot (Alerta Precoce)")
        print("3. Mostrar Estatísticas de Implantação")
        print("4. Remover Todos os Honeypots")
        print("5. Sair")
        
        choice = input("\nSelecione a opção: ")
        
        if choice == "1":
            count = input("Número de honeypots a implantar (padrão 200): ")
            count = int(count) if count else 200
            
            print(f"\nImplantando {count} honeypots aprimorados...")
            deployed = system.deploy_enhanced_honeypots(count)
            
            print(f"\n✓ Implantados {len(deployed)} honeypots")
            print(f"  Pastas honeypot: {sum(1 for d in deployed if d['type'] == 'honey_folder')}")
            print(f"  Arquivos: {sum(1 for d in deployed if d['type'] != 'honey_folder')}")
            
            # Mostrar distribuição
            dirs = set(d['parent'] for d in deployed)
            print(f"  Em {len(dirs)} diretórios")
        
        elif choice == "2":
            print("\nVerificando pastas honeypot...")
            accessed = system.check_honey_folders()
            
            if accessed:
                print(f"⚠️ ALERTA: {len(accessed)} pastas honeypot acessadas!")
                for folder in accessed:
                    print(f"  - {folder}")
            else:
                print("✓ Nenhuma pasta honeypot acessada")
        
        elif choice == "3":
            if system.registry:
                print(f"\nHoneypots Implantados: {len(system.registry)}")
                
                # Agrupar por tipo
                types = {}
                for item in system.registry:
                    t = item['type']
                    types[t] = types.get(t, 0) + 1
                
                print("\nPor Tipo:")
                for t, count in types.items():
                    print(f"  {t}: {count}")
                
                # Agrupar por diretório pai
                parents = {}
                for item in system.registry:
                    p = Path(item['parent']).name
                    parents[p] = parents.get(p, 0) + 1
                
                print("\nPrincipais Diretórios:")
                for p, count in sorted(parents.items(), key=lambda x: x[1], reverse=True)[:5]:
                    print(f"  {p}: {count}")
            else:
                print("\nNenhum honeypot implantado")
        
        elif choice == "4":
            confirm = input("Remover todos os honeypots? (y/n): ")
            if confirm.lower() == 'y':
                removed = system.cleanup_honeypots()
                print(f"✓ Removidos {removed} honeypots")
        
        elif choice == "5":
            break


if __name__ == "__main__":
    main()
