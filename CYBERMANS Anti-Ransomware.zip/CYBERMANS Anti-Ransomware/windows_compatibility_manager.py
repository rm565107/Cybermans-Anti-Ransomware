"""
Windows Compatibility Manager for Anti-Ransomware Application
Ensures universal compatibility with Windows 10 and 11
"""

import os
import sys
import platform
import subprocess
import ctypes
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
import json
import shutil

class WindowsCompatibilityManager:
    def __init__(self, base_dir=None):
        """Initialize Windows compatibility manager."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'compatibility_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("WindowsCompatibility")
        
        # System information
        self.system_info = self._get_system_info()
        self.compatibility_status = self._check_compatibility()
        
    def _get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information."""
        try:
            system_info = {
                'platform': platform.platform(),
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'python_version': sys.version,
                'architecture': platform.architecture(),
                'windows_version': self._get_windows_version(),
                'is_admin': self._check_admin_privileges(),
                'available_features': self._check_available_features()
            }
            return system_info
        except Exception as e:
            self.logger.error(f"Error getting system info: {e}")
            return {}
    
    def _get_windows_version(self) -> str:
        """Get Windows version information."""
        try:
            # Get Windows version using WMI
            result = subprocess.run(
                ['powershell', '-Command', 'Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, Version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.strip()
            else:
                # Fallback method
                return f"Windows {platform.release()}"
        except Exception:
            return f"Windows {platform.release()}"
    
    def _check_admin_privileges(self) -> bool:
        """Check if running with administrator privileges."""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            return False
    
    def _check_available_features(self) -> Dict[str, bool]:
        """Check which Windows features are available."""
        features = {
            'vss_service': False,
            'powershell': False,
            'wmi': False,
            'firewall': False,
            'task_scheduler': False,
            'registry_access': False,
            'file_monitoring': False,
            'process_management': False
        }
        
        try:
            # Check VSS service
            result = subprocess.run(
                ['sc', 'query', 'VSS'],
                capture_output=True,
                text=True,
                timeout=5
            )
            features['vss_service'] = result.returncode == 0
            
            # Check PowerShell
            result = subprocess.run(
                ['powershell', '-Command', 'Get-Host'],
                capture_output=True,
                text=True,
                timeout=5
            )
            features['powershell'] = result.returncode == 0
            
            # Check WMI
            result = subprocess.run(
                ['powershell', '-Command', 'Get-WmiObject -Class Win32_ComputerSystem'],
                capture_output=True,
                text=True,
                timeout=5
            )
            features['wmi'] = result.returncode == 0
            
            # Check Firewall
            result = subprocess.run(
                ['netsh', 'advfirewall', 'show', 'allprofiles'],
                capture_output=True,
                text=True,
                timeout=5
            )
            features['firewall'] = result.returncode == 0
            
            # Check Task Scheduler
            result = subprocess.run(
                ['schtasks', '/query'],
                capture_output=True,
                text=True,
                timeout=5
            )
            features['task_scheduler'] = result.returncode == 0
            
            # Check Registry access
            try:
                import winreg
                features['registry_access'] = True
            except ImportError:
                features['registry_access'] = False
            
            # Check file monitoring
            try:
                import watchdog
                features['file_monitoring'] = True
            except ImportError:
                features['file_monitoring'] = False
            
            # Check process management
            try:
                import psutil
                features['process_management'] = True
            except ImportError:
                features['process_management'] = False
                
        except Exception as e:
            self.logger.error(f"Error checking features: {e}")
        
        return features
    
    def _check_compatibility(self) -> Dict[str, Any]:
        """Check overall compatibility status."""
        compatibility = {
            'windows_version_supported': False,
            'admin_privileges': False,
            'required_features': {},
            'optional_features': {},
            'compatibility_score': 0,
            'recommendations': []
        }
        
        # Check Windows version
        windows_version = self.system_info.get('release', '')
        if windows_version in ['10', '11']:
            compatibility['windows_version_supported'] = True
        else:
            compatibility['recommendations'].append("Windows 10 or 11 required for full functionality")
        
        # Check admin privileges
        compatibility['admin_privileges'] = self.system_info.get('is_admin', False)
        if not compatibility['admin_privileges']:
            compatibility['recommendations'].append("Run as administrator for full protection capabilities")
        
        # Check required features
        required_features = ['powershell', 'wmi', 'process_management', 'file_monitoring']
        for feature in required_features:
            available = self.system_info.get('available_features', {}).get(feature, False)
            compatibility['required_features'][feature] = available
            if not available:
                compatibility['recommendations'].append(f"Install required dependency for {feature}")
        
        # Check optional features
        optional_features = ['vss_service', 'firewall', 'task_scheduler', 'registry_access']
        for feature in optional_features:
            available = self.system_info.get('available_features', {}).get(feature, False)
            compatibility['optional_features'][feature] = available
        
        # Calculate compatibility score
        required_count = sum(1 for v in compatibility['required_features'].values() if v)
        optional_count = sum(1 for v in compatibility['optional_features'].values() if v)
        total_features = len(required_features) + len(optional_features)
        
        compatibility['compatibility_score'] = int(((required_count + optional_count) / total_features) * 100)
        
        return compatibility
    
    def get_compatibility_report(self) -> Dict[str, Any]:
        """Get comprehensive compatibility report."""
        return {
            'system_info': self.system_info,
            'compatibility_status': self.compatibility_status,
            'recommendations': self._get_recommendations(),
            'installation_guide': self._get_installation_guide()
        }
    
    def _get_recommendations(self) -> List[str]:
        """Get system-specific recommendations."""
        recommendations = []
        
        # Windows version recommendations
        if not self.compatibility_status['windows_version_supported']:
            recommendations.append("Upgrade to Windows 10 or 11 for full compatibility")
        
        # Admin privileges recommendations
        if not self.compatibility_status['admin_privileges']:
            recommendations.append("Run the application as administrator for maximum protection")
        
        # Feature-specific recommendations
        if not self.system_info.get('available_features', {}).get('vss_service', False):
            recommendations.append("Enable Volume Shadow Copy Service for backup functionality")
        
        if not self.system_info.get('available_features', {}).get('firewall', False):
            recommendations.append("Enable Windows Firewall for network protection")
        
        # Performance recommendations
        recommendations.append("Ensure sufficient disk space for honeypots and backups")
        recommendations.append("Close unnecessary applications for optimal performance")
        recommendations.append("Keep Windows updated for security patches")
        
        return recommendations
    
    def _get_installation_guide(self) -> Dict[str, Any]:
        """Get installation guide for the current system."""
        guide = {
            'python_requirements': self._get_python_requirements(),
            'system_requirements': self._get_system_requirements(),
            'installation_steps': self._get_installation_steps(),
            'troubleshooting': self._get_troubleshooting_guide()
        }
        return guide
    
    def _get_python_requirements(self) -> List[str]:
        """Get Python requirements for current system."""
        requirements = [
            "Python 3.8 or higher",
            "pip (Python package installer)",
            "All dependencies from requirements.txt"
        ]
        
        # Check if specific packages are available
        try:
            import psutil
            requirements.append("✅ psutil (process management)")
        except ImportError:
            requirements.append("❌ psutil (install with: pip install psutil)")
        
        try:
            import watchdog
            requirements.append("✅ watchdog (file monitoring)")
        except ImportError:
            requirements.append("❌ watchdog (install with: pip install watchdog)")
        
        try:
            import ttkbootstrap
            requirements.append("✅ ttkbootstrap (GUI framework)")
        except ImportError:
            requirements.append("❌ ttkbootstrap (install with: pip install ttkbootstrap)")
        
        return requirements
    
    def _get_system_requirements(self) -> List[str]:
        """Get system requirements."""
        return [
            "Windows 10 (version 1903 or later) or Windows 11",
            "Minimum 4GB RAM (8GB recommended)",
            "Minimum 2GB free disk space (10GB recommended)",
            "Administrator privileges (for full functionality)",
            "Internet connection (for updates and threat intelligence)",
            "Antivirus software compatibility (may need exclusions)"
        ]
    
    def _get_installation_steps(self) -> List[str]:
        """Get installation steps for current system."""
        steps = [
            "1. Download and install Python 3.8+ from python.org",
            "2. Open Command Prompt as Administrator",
            "3. Navigate to the application directory",
            "4. Install dependencies: pip install -r requirements.txt",
            "5. Run the application: python GUI_PART_2.py",
            "6. Configure settings as needed",
            "7. Start protection"
        ]
        
        # Add system-specific steps
        if not self.compatibility_status['admin_privileges']:
            steps.insert(2, "2.5. Right-click Command Prompt and 'Run as administrator'")
        
        if not self.system_info.get('available_features', {}).get('vss_service', False):
            steps.append("8. Enable Volume Shadow Copy Service in Windows Services")
        
        return steps
    
    def _get_troubleshooting_guide(self) -> Dict[str, List[str]]:
        """Get troubleshooting guide for common issues."""
        return {
            "Import Errors": [
                "Ensure all dependencies are installed: pip install -r requirements.txt",
                "Check Python version: python --version",
                "Verify Python path in system environment variables"
            ],
            "Permission Errors": [
                "Run as administrator",
                "Check antivirus exclusions",
                "Verify file permissions"
            ],
            "VSS Errors": [
                "Enable Volume Shadow Copy Service",
                "Check disk space",
                "Run as administrator"
            ],
            "GUI Issues": [
                "Install ttkbootstrap: pip install ttkbootstrap",
                "Check display settings",
                "Update graphics drivers"
            ],
            "Performance Issues": [
                "Close unnecessary applications",
                "Check available disk space",
                "Update Windows to latest version"
            ]
        }
    
    def optimize_for_system(self) -> Dict[str, Any]:
        """Optimize application settings for current system."""
        optimizations = {
            'honeypot_count': 20,  # Default
            'scan_interval': 5,    # Default
            'monitoring_frequency': 2,  # Default
            'backup_frequency': 3600,  # Default
            'enabled_features': [],
            'disabled_features': []
        }
        
        # Adjust based on system capabilities
        if self.system_info.get('available_features', {}).get('vss_service', False):
            optimizations['enabled_features'].append('vss_backups')
        else:
            optimizations['disabled_features'].append('vss_backups')
            optimizations['enabled_features'].append('file_backups')
        
        if self.system_info.get('available_features', {}).get('firewall', False):
            optimizations['enabled_features'].append('network_isolation')
        else:
            optimizations['disabled_features'].append('network_isolation')
        
        # Adjust performance based on system
        if self.system_info.get('architecture', [None])[0] == '64bit':
            optimizations['honeypot_count'] = 30
            optimizations['scan_interval'] = 3
        else:
            optimizations['honeypot_count'] = 15
            optimizations['scan_interval'] = 8
        
        return optimizations
    
    def create_system_config(self) -> Dict[str, Any]:
        """Create optimized configuration for current system."""
        config = {
            'system_info': self.system_info,
            'compatibility': self.compatibility_status,
            'optimizations': self.optimize_for_system(),
            'recommendations': self._get_recommendations(),
            'installation_guide': self._get_installation_guide()
        }
        
        # Save configuration
        config_file = self.base_dir / "system_config.json"
        try:
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            self.logger.info(f"System configuration saved to {config_file}")
        except Exception as e:
            self.logger.error(f"Failed to save system configuration: {e}")
        
        return config


def main():
    """Test Windows compatibility manager."""
    print("🔍 WINDOWS COMPATIBILITY MANAGER TEST")
    print("=" * 50)
    
    manager = WindowsCompatibilityManager()
    
    # Get compatibility report
    report = manager.get_compatibility_report()
    
    print(f"\n📊 SYSTEM INFORMATION:")
    print(f"Platform: {report['system_info'].get('platform', 'Unknown')}")
    print(f"Windows Version: {report['system_info'].get('windows_version', 'Unknown')}")
    print(f"Admin Privileges: {report['system_info'].get('is_admin', False)}")
    print(f"Architecture: {report['system_info'].get('architecture', 'Unknown')}")
    
    print(f"\n✅ COMPATIBILITY STATUS:")
    print(f"Windows Version Supported: {report['compatibility_status']['windows_version_supported']}")
    print(f"Admin Privileges: {report['compatibility_status']['admin_privileges']}")
    print(f"Compatibility Score: {report['compatibility_status']['compatibility_score']}%")
    
    print(f"\n🔧 AVAILABLE FEATURES:")
    features = report['system_info'].get('available_features', {})
    for feature, available in features.items():
        status = "✅" if available else "❌"
        print(f"  {status} {feature}")
    
    print(f"\n💡 RECOMMENDATIONS:")
    for recommendation in report['recommendations']:
        print(f"  • {recommendation}")
    
    print(f"\n🎯 OPTIMIZATIONS:")
    optimizations = manager.optimize_for_system()
    print(f"  Honeypot Count: {optimizations['honeypot_count']}")
    print(f"  Scan Interval: {optimizations['scan_interval']} seconds")
    print(f"  Enabled Features: {', '.join(optimizations['enabled_features'])}")
    print(f"  Disabled Features: {', '.join(optimizations['disabled_features'])}")
    
    print(f"\n✅ Windows Compatibility Manager test completed!")


if __name__ == "__main__":
    main()
