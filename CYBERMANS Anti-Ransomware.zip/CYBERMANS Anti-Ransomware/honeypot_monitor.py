"""
Honeypot Monitoring System for Anti-Ransomware Shield
Monitors honeypot files for ransomware activity and triggers alerts
"""

import os
import json
import time
import hashlib
import threading
import logging
from pathlib import Path
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import psutil
import winsound

class HoneypotMonitor(FileSystemEventHandler):
    def __init__(self, honeypot_registry_path=None, base_dir=None):
        """Initialize the honeypot monitoring system."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        if honeypot_registry_path is None:
            honeypot_registry_path = self.base_dir / "Honeypots" / "honeypot_registry.json"
        self.honeypot_registry_path = Path(honeypot_registry_path)
        self.honeypots = {}
        self.alerts = []
        self.monitoring = False
        self.suspected_processes = []
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'honeypot_monitor_{datetime.now().strftime("%Y%m%d")}.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Load honeypot registry
        self.load_honeypot_registry()
        
    def load_honeypot_registry(self):
        """Load the honeypot file registry."""
        if self.honeypot_registry_path.exists():
            with open(self.honeypot_registry_path, 'r') as f:
                registry = json.load(f)
                for item in registry:
                    self.honeypots[item['path']] = {
                        'type': item['type'],
                        'original_checksum': item['checksum'],
                        'created': item['created'],
                        'status': 'active'
                    }
            self.logger.info(f"Loaded {len(self.honeypots)} honeypot files for monitoring")
        else:
            self.logger.warning("No honeypot registry found. Please generate honeypots first.")
    
    def calculate_file_hash(self, filepath):
        """Calculate SHA256 hash of a file."""
        try:
            # Check if file exists first
            if not Path(filepath).exists():
                self.logger.warning(f"File does not exist: {filepath}")
                return None
            
            sha256_hash = hashlib.sha256()
            with open(filepath, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except FileNotFoundError:
            self.logger.warning(f"File not found during hash calculation: {filepath}")
            return None
        except PermissionError:
            self.logger.warning(f"Permission denied accessing file: {filepath}")
            return None
        except Exception as e:
            self.logger.error(f"Error calculating hash for {filepath}: {e}")
            return None
    
    def on_modified(self, event):
        """Handle file modification events."""
        if not event.is_directory and event.src_path in self.honeypots:
            self.detect_ransomware_activity(event.src_path, "modified")
    
    def on_deleted(self, event):
        """Handle file deletion events."""
        if not event.is_directory and event.src_path in self.honeypots:
            self.detect_ransomware_activity(event.src_path, "deleted")
    
    def on_moved(self, event):
        """Handle file move/rename events."""
        if not event.is_directory and event.src_path in self.honeypots:
            self.detect_ransomware_activity(event.src_path, "moved", event.dest_path)
    
    def detect_ransomware_activity(self, filepath, action, new_path=None):
        """Detect and respond to potential ransomware activity."""
        alert = {
            'timestamp': datetime.now().isoformat(),
            'honeypot': filepath,
            'action': action,
            'new_path': new_path
        }
        
        # Check for encryption indicators
        if action == "modified":
            # Check if file extension changed (common ransomware behavior)
            original_ext = Path(filepath).suffix
            if Path(filepath).exists():
                current_ext = Path(filepath).suffix
                if original_ext != current_ext:
                    alert['encryption_suspected'] = True
                    alert['new_extension'] = current_ext
                
                # Check if file content appears encrypted
                if self.is_file_encrypted(filepath):
                    alert['encryption_confirmed'] = True
        
        # Find suspicious processes
        suspicious_procs = self.find_suspicious_processes()
        if suspicious_procs:
            alert['suspicious_processes'] = suspicious_procs
        
        # Log alert
        self.alerts.append(alert)
        self.logger.critical(f"RANSOMWARE ALERT: {json.dumps(alert, indent=2)}")
        
        # Trigger immediate response
        self.trigger_ransomware_response(alert)
    
    def is_file_encrypted(self, filepath):
        """Check if a file appears to be encrypted based on entropy."""
        try:
            with open(filepath, 'rb') as f:
                data = f.read(1024)  # Read first 1KB
                if not data:
                    return False
                
                # Calculate entropy
                entropy = self.calculate_entropy(data)
                
                # High entropy (>7.5) usually indicates encryption
                return entropy > 7.5
        except Exception as e:
            self.logger.error(f"Error checking encryption for {filepath}: {e}")
            return False
    
    def calculate_entropy(self, data):
        """Calculate Shannon entropy of data."""
        import math
        if not data:
            return 0
        
        frequency = {}
        for byte in data:
            frequency[byte] = frequency.get(byte, 0) + 1
        
        entropy = 0
        data_len = len(data)
        for freq in frequency.values():
            if freq > 0:
                probability = freq / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def find_suspicious_processes(self):
        """Find processes that might be ransomware."""
        suspicious = []
        suspicious_names = ['encrypt', 'crypt', 'lock', 'ransom', 'wanna', 'cry', 'petya']
        
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'create_time']):
            try:
                proc_info = proc.info
                proc_name = proc_info['name'].lower()
                
                # Check for suspicious process names
                if any(sus in proc_name for sus in suspicious_names):
                    suspicious.append({
                        'pid': proc_info['pid'],
                        'name': proc_info['name'],
                        'exe': proc_info['exe'],
                        'start_time': datetime.fromtimestamp(proc_info['create_time']).isoformat()
                    })
                
                # Check for processes accessing multiple honeypots
                try:
                    open_files = proc.open_files()
                    honeypot_access = [f.path for f in open_files if f.path in self.honeypots]
                    if len(honeypot_access) > 2:  # Multiple honeypot access
                        suspicious.append({
                            'pid': proc_info['pid'],
                            'name': proc_info['name'],
                            'exe': proc_info['exe'],
                            'honeypot_access': honeypot_access
                        })
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass
                    
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                pass
        
        return suspicious
    
    def trigger_ransomware_response(self, alert):
        """Trigger immediate response to ransomware detection."""
        self.logger.critical("INITIATING RANSOMWARE RESPONSE PROTOCOL")
        
        # 1. Sound alarm
        threading.Thread(target=self.sound_alarm).start()
        
        # 2. Create VSS snapshot immediately
        threading.Thread(target=self.create_emergency_snapshot).start()
        
        # 3. Try to kill suspicious processes
        if 'suspicious_processes' in alert:
            for proc in alert['suspicious_processes']:
                self.terminate_process(proc['pid'])
        
        # 4. Save alert details
        self.save_alert_details(alert)
        
        # 5. Notify user
        self.show_ransomware_alert(alert)
    
    def sound_alarm(self):
        """Sound an audio alarm."""
        try:
            for _ in range(3):
                winsound.Beep(1000, 500)  # 1000 Hz for 500ms
                time.sleep(0.5)
        except Exception as e:
            self.logger.error(f"Failed to sound alarm: {e}")
    
    def create_emergency_snapshot(self):
        """Create an emergency VSS snapshot."""
        try:
            import subprocess
            result = subprocess.run(
                ['powershell', '-Command', 
                 'wmic shadowcopy call create Volume="C:\\"'],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                self.logger.info("Emergency VSS snapshot created successfully")
            else:
                self.logger.error(f"Failed to create VSS snapshot: {result.stderr}")
        except Exception as e:
            self.logger.error(f"Error creating emergency snapshot: {e}")
    
    def terminate_process(self, pid):
        """Attempt to terminate a suspicious process."""
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            self.logger.info(f"Terminated suspicious process: PID {pid}")
        except Exception as e:
            self.logger.error(f"Failed to terminate process {pid}: {e}")
    
    def save_alert_details(self, alert):
        """Save alert details to file."""
        alert_dir = self.base_dir / "Alerts"
        alert_dir.mkdir(parents=True, exist_ok=True)
        
        alert_file = alert_dir / f"ransomware_alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(alert_file, 'w') as f:
            json.dump(alert, f, indent=2)
        
        self.logger.info(f"Alert details saved to {alert_file}")
    
    def show_ransomware_alert(self, alert):
        """Display ransomware alert to user."""
        import tkinter as tk
        from tkinter import messagebox
        
        root = tk.Tk()
        root.withdraw()
        
        message = f"""
RANSOMWARE DETECTED!

Time: {alert['timestamp']}
Affected honeypot: {alert['honeypot']}
Action: {alert['action']}

Suspicious processes have been terminated.
Emergency backup created.

Please run a full system scan immediately!
        """
        
        messagebox.showerror("RANSOMWARE ALERT", message)
        root.destroy()
    
    def start_monitoring(self):
        """Start monitoring honeypot files."""
        self.monitoring = True
        observer = Observer()
        
        # Monitor all honeypot directories
        monitored_dirs = set()
        for honeypot_path in self.honeypots.keys():
            parent_dir = str(Path(honeypot_path).parent)
            if parent_dir not in monitored_dirs:
                observer.schedule(self, parent_dir, recursive=True)
                monitored_dirs.add(parent_dir)
                self.logger.info(f"Monitoring directory: {parent_dir}")
        
        observer.start()
        self.logger.info("Honeypot monitoring started")
        
        try:
            while self.monitoring:
                time.sleep(1)
                # Periodic integrity check
                if int(time.time()) % 300 == 0:  # Every 5 minutes
                    self.perform_integrity_check()
        except KeyboardInterrupt:
            observer.stop()
            self.logger.info("Monitoring stopped by user")
        
        observer.join()
    
    def perform_integrity_check(self):
        """Perform periodic integrity check on honeypot files."""
        self.logger.info("Performing integrity check...")
        
        for filepath, info in self.honeypots.items():
            if Path(filepath).exists():
                current_hash = self.calculate_file_hash(filepath)
                if current_hash and info['original_checksum']:
                    if str(current_hash) != str(info['original_checksum']):
                        self.logger.warning(f"Integrity check failed for {filepath}")
                        self.detect_ransomware_activity(filepath, "integrity_violation")
            else:
                if info['status'] == 'active':
                    self.logger.warning(f"Honeypot file missing: {filepath}")
                    self.detect_ransomware_activity(filepath, "deleted")
                    info['status'] = 'missing'
    
    def get_monitoring_status(self):
        """Get current monitoring status and statistics."""
        return {
            'monitoring': self.monitoring,
            'total_honeypots': len(self.honeypots),
            'active_honeypots': sum(1 for h in self.honeypots.values() if h['status'] == 'active'),
            'alerts_count': len(self.alerts),
            'last_check': datetime.now().isoformat()
        }


if __name__ == "__main__":
    print("=== Anti-Ransomware Honeypot Monitor ===\n")
    
    monitor = HoneypotMonitor()
    
    print(f"[*] Loaded {len(monitor.honeypots)} honeypot files")
    print("[*] Starting monitoring...")
    print("[*] Press Ctrl+C to stop\n")
    
    try:
        monitor.start_monitoring()
    except KeyboardInterrupt:
        print("\n[*] Monitoring stopped")
        print(f"[*] Total alerts: {len(monitor.alerts)}")
