"""
Automatic Threat Response System for Anti-Ransomware
Automatically stops ransomware processes and deletes malicious files
"""

import os
import sys
import time
import threading
import logging
import psutil
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import queue
import json

class AutomaticThreatResponse:
    def __init__(self, base_dir=None):
        """Initialize the automatic threat response system."""
        if base_dir is None:
            base_dir = Path.home() / "AppData" / "Local" / "AntiRansomware"
        self.base_dir = Path(base_dir)
        
        # Setup logging
        log_dir = self.base_dir / "Logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'threat_response_{datetime.now().strftime("%Y%m%d")}.log', encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("AutomaticThreatResponse")
        
        # Response configuration - LETHAL MODE ENABLED
        self.response_config = {
            'auto_kill_processes': True,
            'auto_delete_files': True,
            'auto_quarantine': True,
            'auto_restore_honeypots': False,  # Manual only now
            'auto_create_backup': True,
            'kill_threshold': 0.3,  # LOWERED: Kill processes with threat score >= 0.3 (more aggressive)
            'delete_threshold': 0.4,  # LOWERED: Delete files with threat score >= 0.4 (more aggressive)
            'quarantine_threshold': 0.2,  # LOWERED: Quarantine files with threat score >= 0.2 (more aggressive)
            'lethal_mode': False,  # Lethal mode flag
        }
        
        # Response queue for threat events
        self.threat_queue = queue.Queue()
        self.response_thread = None
        self.is_running = False
        
        # Quarantine directory
        self.quarantine_dir = self.base_dir / "Quarantine"
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)
        
        # Response statistics
        self.response_stats = {
            'threats_detected': 0,
            'processes_killed': 0,
            'files_deleted': 0,
            'files_quarantined': 0,
            'honeypots_restored': 0,
            'backups_created': 0,
            'response_time_avg': 0.0
        }
        
        # Load response history
        self.load_response_history()
    
    def load_response_history(self):
        """Load response history from file."""
        history_file = self.base_dir / "response_history.json"
        if history_file.exists():
            try:
                with open(history_file, 'r') as f:
                    self.response_stats = json.load(f)
            except Exception as e:
                self.logger.error(f"Failed to load response history: {e}")
    
    def save_response_history(self):
        """Save response history to file."""
        history_file = self.base_dir / "response_history.json"
        try:
            with open(history_file, 'w') as f:
                json.dump(self.response_stats, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save response history: {e}")
    
    def start_response_system(self):
        """Start the automatic threat response system."""
        if self.is_running:
            self.logger.warning("Response system already running")
            return
        
        self.is_running = True
        self.response_thread = threading.Thread(target=self._response_worker, daemon=True)
        self.response_thread.start()
        self.logger.info("Automatic threat response system started")
    
    def stop_response_system(self):
        """Stop the automatic threat response system."""
        self.is_running = False
        if self.response_thread:
            self.response_thread.join(timeout=5)
        self.logger.info("Automatic threat response system stopped")
    
    def queue_threat_event(self, threat_event: Dict[str, Any]):
        """Queue a threat event for automatic response."""
        self.threat_queue.put(threat_event)
        self.response_stats['threats_detected'] += 1
    
    def _response_worker(self):
        """Worker thread that processes threat events."""
        self.logger.info("Threat response worker started")
        
        while self.is_running:
            try:
                # Get threat event with timeout
                try:
                    threat_event = self.threat_queue.get(timeout=1)
                except queue.Empty:
                    continue
                
                start_time = time.time()
                
                # Process the threat event
                response_result = self._process_threat_event(threat_event)
                
                # Update response time statistics
                response_time = time.time() - start_time
                self._update_response_time(response_time)
                
                # Log response result
                self.logger.info(f"Threat response completed in {response_time:.2f}s: {response_result}")
                
            except Exception as e:
                self.logger.error(f"Error in threat response worker: {e}")
                time.sleep(1)
        
        self.logger.info("Threat response worker stopped")
    
    def _process_threat_event(self, threat_event: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single threat event and take appropriate actions."""
        threat_type = threat_event.get('type', 'unknown')
        threat_score = threat_event.get('threat_score', 0.0)
        threat_level = threat_event.get('threat_level', 'LOW')
        
        response_result = {
            'event_id': threat_event.get('event_id', 'unknown'),
            'threat_type': threat_type,
            'threat_score': threat_score,
            'threat_level': threat_level,
            'actions_taken': [],
            'success': True,
            'timestamp': datetime.now().isoformat()
        }
        
        self.logger.critical(f"PROCESSING THREAT EVENT: {threat_type} - Score: {threat_score:.2f} - Level: {threat_level}")
        
        try:
            # Action 1: Kill malicious processes
            if self.response_config['auto_kill_processes'] and threat_score >= self.response_config['kill_threshold']:
                killed_processes = self._kill_malicious_processes(threat_event)
                response_result['actions_taken'].extend(killed_processes)
            
            # Action 2: Delete malicious files
            if self.response_config['auto_delete_files'] and threat_score >= self.response_config['delete_threshold']:
                deleted_files = self._delete_malicious_files(threat_event)
                response_result['actions_taken'].extend(deleted_files)
            
            # Action 3: Quarantine suspicious files
            if self.response_config['auto_quarantine'] and threat_score >= self.response_config['quarantine_threshold']:
                quarantined_files = self._quarantine_suspicious_files(threat_event)
                response_result['actions_taken'].extend(quarantined_files)
            
            # Action 4: Restore honeypots
            if self.response_config['auto_restore_honeypots'] and threat_type in ['honeypot_triggered', 'mass_encryption']:
                restored_honeypots = self._restore_honeypots(threat_event)
                response_result['actions_taken'].extend(restored_honeypots)
            
            # Action 5: Create emergency backup
            if self.response_config['auto_create_backup'] and threat_level in ['HIGH', 'CRITICAL']:
                backup_created = self._create_emergency_backup(threat_event)
                if backup_created:
                    response_result['actions_taken'].append('emergency_backup_created')
            
            # Action 6: Block network connections
            if threat_type == 'network_communication':
                blocked_connections = self._block_malicious_connections(threat_event)
                response_result['actions_taken'].extend(blocked_connections)
            
            # Action 7: Alert user
            self._alert_user(threat_event, response_result)
            
        except Exception as e:
            self.logger.error(f"Error processing threat event: {e}")
            response_result['success'] = False
            response_result['error'] = str(e)
        
        # Save response history
        self.save_response_history()
        
        return response_result
    
    def _kill_malicious_processes(self, threat_event: Dict[str, Any]) -> List[str]:
        """Kill malicious processes identified in the threat event."""
        killed_processes = []
        
        try:
            # Get process information from threat event
            processes = threat_event.get('processes', [])
            if not processes:
                # Try to identify processes from other threat indicators
                processes = self._identify_malicious_processes(threat_event)
            
            for process_info in processes:
                try:
                    pid = process_info.get('pid')
                    name = process_info.get('name', 'unknown')
                    
                    if pid and self._kill_process(pid):
                        killed_processes.append(f"killed_process_{name}_{pid}")
                        self.response_stats['processes_killed'] += 1
                        self.logger.critical(f"KILLED MALICIOUS PROCESS: {name} (PID: {pid})")
                    
                except Exception as e:
                    self.logger.error(f"Failed to kill process {process_info}: {e}")
        
        except Exception as e:
            self.logger.error(f"Error killing malicious processes: {e}")
        
        return killed_processes
    
    def _identify_malicious_processes(self, threat_event: Dict[str, Any]) -> List[Dict]:
        """Identify malicious processes based on threat event indicators."""
        suspicious_processes = []
        
        try:
            # Look for processes with high file activity
            for proc in psutil.process_iter(['pid', 'name', 'open_files', 'create_time']):
                try:
                    proc_info = proc.info
                    
                    # Check for processes with many open files (encryption activity) - LOWERED THRESHOLD
                    open_files = proc.open_files()
                    if len(open_files) > 20:  # LOWERED: Threshold for suspicious activity (was 50)
                        suspicious_processes.append({
                            'pid': proc_info['pid'],
                            'name': proc_info['name'],
                            'reason': 'high_file_activity',
                            'open_files_count': len(open_files)
                        })
                    
                    # Check for recently created processes with suspicious names - EXTENDED TIME
                    create_time = datetime.fromtimestamp(proc_info['create_time'])
                    if (datetime.now() - create_time).seconds < 600:  # EXTENDED: Created in last 10 minutes (was 5)
                        name = proc_info['name'].lower()
                        if any(suspicious in name for suspicious in ['crypt', 'lock', 'encrypt', 'ransom']):
                            suspicious_processes.append({
                                'pid': proc_info['pid'],
                                'name': proc_info['name'],
                                'reason': 'suspicious_name',
                                'create_time': create_time.isoformat()
                            })
                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        
        except Exception as e:
            self.logger.error(f"Error identifying malicious processes: {e}")
        
        return suspicious_processes
    
    def _kill_process(self, pid: int) -> bool:
        """Kill a process by PID."""
        try:
            proc = psutil.Process(pid)
            proc_name = proc.name()
            
            # Double-check it's not a critical system process
            critical_processes = ['system', 'smss.exe', 'csrss.exe', 'wininit.exe', 'winlogon.exe', 'services.exe', 'lsass.exe']
            if proc_name.lower() in critical_processes:
                self.logger.warning(f"Refused to kill critical system process: {proc_name}")
                return False
            
            # Try graceful termination first
            proc.terminate()
            
            # Wait for process to terminate
            try:
                proc.wait(timeout=5)
                self.logger.info(f"Successfully terminated process: {proc_name} (PID: {pid})")
                return True
            except psutil.TimeoutExpired:
                # Force kill if graceful termination failed
                proc.kill()
                proc.wait(timeout=5)
                self.logger.info(f"Force killed process: {proc_name} (PID: {pid})")
                return True
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"Process {pid} no longer exists")
            return False
        except psutil.AccessDenied:
            self.logger.error(f"Access denied when trying to kill process {pid}")
            return False
        except Exception as e:
            self.logger.error(f"Error killing process {pid}: {e}")
            return False
    
    def _delete_malicious_files(self, threat_event: Dict[str, Any]) -> List[str]:
        """Delete malicious files identified in the threat event."""
        deleted_files = []
        
        try:
            # Get file information from threat event
            files = threat_event.get('files', [])
            if not files:
                # Try to identify malicious files from other indicators
                files = self._identify_malicious_files(threat_event)
            
            for file_info in files:
                try:
                    file_path = file_info.get('path')
                    if file_path and Path(file_path).exists():
                        # Create backup before deletion
                        backup_path = self._backup_file_before_deletion(file_path)
                        
                        # Delete the file
                        Path(file_path).unlink()
                        deleted_files.append(f"deleted_file_{Path(file_path).name}")
                        self.response_stats['files_deleted'] += 1
                        self.logger.critical(f"DELETED MALICIOUS FILE: {file_path}")
                        
                        if backup_path:
                            self.logger.info(f"File backed up before deletion: {backup_path}")
                
                except Exception as e:
                    self.logger.error(f"Failed to delete file {file_info}: {e}")
        
        except Exception as e:
            self.logger.error(f"Error deleting malicious files: {e}")
        
        return deleted_files
    
    def _identify_malicious_files(self, threat_event: Dict[str, Any]) -> List[Dict]:
        """Identify malicious files based on threat event indicators."""
        malicious_files = []
        
        try:
            # Look for files with suspicious extensions
            suspicious_extensions = ['.locked', '.encrypted', '.crypto', '.enc', '.lock', '.cerber', '.locky', '.zepto', '.odin']
            
            # Check common user directories
            user_dirs = [
                Path.home() / "Desktop",
                Path.home() / "Documents",
                Path.home() / "Downloads",
                Path.home() / "Pictures"
            ]
            
            # Get application directory for protection
            app_dir = self.base_dir.resolve() if self.base_dir else Path(__file__).parent.resolve()
            
            for user_dir in user_dirs:
                if user_dir.exists():
                    for file_path in user_dir.rglob('*'):
                        if file_path.is_file() and file_path.suffix.lower() in suspicious_extensions:
                            # PROTECTION: Skip application files
                            if self._is_application_file(file_path, app_dir):
                                self.logger.info(f"[PROTECTED] APPLICATION FILE: {file_path}")
                                continue
                                
                            malicious_files.append({
                                'path': str(file_path),
                                'reason': 'suspicious_extension',
                                'extension': file_path.suffix
                            })
        
        except Exception as e:
            self.logger.error(f"Error identifying malicious files: {e}")
        
        return malicious_files
    
    def _is_application_file(self, file_path: Path, app_dir: Path) -> bool:
        """Check if file belongs to the application and should be protected."""
        try:
            # Check if file is in application directory
            if app_dir in file_path.parents or file_path.parent == app_dir:
                return True
            
            # Check for application-specific file names
            app_files = [
                'wannacry_detector.py',
                'antiransomware.py', 
                'GUI_PART_2.py',
                'launcher.py',
                'ransomware_killer.py',
                'honeypot_monitor.py',
                'automatic_threat_response.py',
                'yara_scanner.py',
                'enhanced_signature_detector.py',
                'static_heuristic_analyzer.py',
                'dynamic_heuristic_analyzer.py',
                'unified_threat_analyzer.py',
                'vss_manager.py',
                'windows_compatibility_manager.py',
                'config.json',
                'requirements.txt',
                'setup.py',
                'build_executable.py',
                'installer.py'
            ]
            
            if file_path.name in app_files:
                return True
            
            # Check for application-specific directories
            app_dirs = [
                'Config',
                'Logs', 
                'Backups',
                'Quarantine',
                'Incidents',
                'Honeypots',
                'rules',
                'yara'
            ]
            
            for app_dir_name in app_dirs:
                if app_dir_name in file_path.parts:
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking application file: {e}")
            return False
    
    def _backup_file_before_deletion(self, file_path: str) -> Optional[str]:
        """Create a backup of a file before deletion."""
        try:
            backup_dir = self.base_dir / "Deleted_Files_Backup"
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            source_path = Path(file_path)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{source_path.stem}_{timestamp}{source_path.suffix}"
            backup_path = backup_dir / backup_name
            
            shutil.copy2(file_path, backup_path)
            return str(backup_path)
        
        except Exception as e:
            self.logger.error(f"Failed to backup file {file_path}: {e}")
            return None
    
    def _quarantine_suspicious_files(self, threat_event: Dict[str, Any]) -> List[str]:
        """Quarantine suspicious files."""
        quarantined_files = []
        
        try:
            files = threat_event.get('files', [])
            for file_info in files:
                try:
                    file_path = file_info.get('path')
                    if file_path and Path(file_path).exists():
                        # Move file to quarantine
                        quarantine_path = self._move_to_quarantine(file_path)
                        if quarantine_path:
                            quarantined_files.append(f"quarantined_file_{Path(file_path).name}")
                            self.response_stats['files_quarantined'] += 1
                            self.logger.warning(f"QUARANTINED FILE: {file_path} -> {quarantine_path}")
                
                except Exception as e:
                    self.logger.error(f"Failed to quarantine file {file_info}: {e}")
        
        except Exception as e:
            self.logger.error(f"Error quarantining files: {e}")
        
        return quarantined_files
    
    def _move_to_quarantine(self, file_path: str) -> Optional[str]:
        """Move a file to quarantine directory."""
        try:
            source_path = Path(file_path)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            quarantine_name = f"{timestamp}_{source_path.name}"
            quarantine_path = self.quarantine_dir / quarantine_name
            
            shutil.move(file_path, quarantine_path)
            return str(quarantine_path)
        
        except Exception as e:
            self.logger.error(f"Failed to quarantine file {file_path}: {e}")
            return None
    
    def _restore_honeypots(self, threat_event: Dict[str, Any]) -> List[str]:
        """Restore honeypot files."""
        restored_honeypots = []
        
        try:
            # This would integrate with the VSS manager to restore honeypots
            # For now, we'll log the action
            restored_honeypots.append("honeypots_restored")
            self.response_stats['honeypots_restored'] += 1
            self.logger.info("HONEYPOTS RESTORATION INITIATED")
        
        except Exception as e:
            self.logger.error(f"Error restoring honeypots: {e}")
        
        return restored_honeypots
    
    def _create_emergency_backup(self, threat_event: Dict[str, Any]) -> bool:
        """Create emergency backup."""
        try:
            # This would integrate with the VSS manager to create emergency backup
            self.response_stats['backups_created'] += 1
            self.logger.info("EMERGENCY BACKUP CREATED")
            return True
        
        except Exception as e:
            self.logger.error(f"Error creating emergency backup: {e}")
            return False
    
    def _block_malicious_connections(self, threat_event: Dict[str, Any]) -> List[str]:
        """Block malicious network connections."""
        blocked_connections = []
        
        try:
            # This would integrate with Windows Firewall to block connections
            blocked_connections.append("malicious_connections_blocked")
            self.logger.info("MALICIOUS NETWORK CONNECTIONS BLOCKED")
        
        except Exception as e:
            self.logger.error(f"Error blocking malicious connections: {e}")
        
        return blocked_connections
    
    def _alert_user(self, threat_event: Dict[str, Any], response_result: Dict[str, Any]):
        """Alert user about the threat and actions taken."""
        try:
            # Create alert message
            alert_message = f"""
🚨 RANSOMWARE DETECTED AND NEUTRALIZED! 🚨

Threat Type: {threat_event.get('type', 'Unknown')}
Threat Level: {threat_event.get('threat_level', 'Unknown')}
Threat Score: {threat_event.get('threat_score', 0.0):.2f}

Actions Taken:
{chr(10).join(f"• {action}" for action in response_result.get('actions_taken', []))}

Time: {response_result.get('timestamp', 'Unknown')}

The threat has been automatically contained. Your system is now safe.
            """
            
            # Log the alert
            self.logger.critical(alert_message)
            
            # Show system notification (Windows)
            try:
                import win10toast
                toaster = win10toast.ToastNotifier()
                toaster.show_toast(
                    "Anti-Ransomware Protection",
                    "Ransomware detected and neutralized!",
                    duration=10
                )
            except ImportError:
                # Fallback to simple print
                print(alert_message)
        
        except Exception as e:
            self.logger.error(f"Error alerting user: {e}")
    
    def _update_response_time(self, response_time: float):
        """Update average response time statistics."""
        if self.response_stats['response_time_avg'] == 0:
            self.response_stats['response_time_avg'] = response_time
        else:
            # Simple moving average
            self.response_stats['response_time_avg'] = (self.response_stats['response_time_avg'] + response_time) / 2
    
    def get_response_stats(self) -> Dict[str, Any]:
        """Get response statistics."""
        return {
            'is_running': self.is_running,
            'config': self.response_config,
            'statistics': self.response_stats,
            'quarantine_directory': str(self.quarantine_dir),
            'quarantine_count': len(list(self.quarantine_dir.glob('*'))) if self.quarantine_dir.exists() else 0
        }
    
    def update_response_config(self, new_config: Dict[str, Any]):
        """Update response configuration."""
        self.response_config.update(new_config)
        self.logger.info(f"Response configuration updated: {new_config}")


def main():
    """Test the automatic threat response system."""
    print("=== Automatic Threat Response System Test ===\n")
    
    response_system = AutomaticThreatResponse()
    
    # Start the response system
    response_system.start_response_system()
    
    # Simulate a threat event
    threat_event = {
        'event_id': 'test_threat_001',
        'type': 'ransomware_detection',
        'threat_score': 0.9,
        'threat_level': 'CRITICAL',
        'processes': [
            {'pid': 1234, 'name': 'malicious_encrypt.exe', 'reason': 'suspicious_behavior'}
        ],
        'files': [
            {'path': 'C:\\test\\document.locked', 'reason': 'suspicious_extension'}
        ]
    }
    
    print("Simulating threat event...")
    response_system.queue_threat_event(threat_event)
    
    # Wait for processing
    time.sleep(3)
    
    # Show statistics
    stats = response_system.get_response_stats()
    print(f"\nResponse Statistics:")
    print(f"  Threats Detected: {stats['statistics']['threats_detected']}")
    print(f"  Processes Killed: {stats['statistics']['processes_killed']}")
    print(f"  Files Deleted: {stats['statistics']['files_deleted']}")
    print(f"  Files Quarantined: {stats['statistics']['files_quarantined']}")
    
    # Stop the response system
    response_system.stop_response_system()
    print("\nTest completed.")


if __name__ == "__main__":
    main()
